import Stripe from 'stripe';
import dotenv from 'dotenv';
dotenv.config();

let stripeClient: Stripe | null = null;

export function getStripeClient(): Stripe | null {
  const secretKey = process.env.STRIPE_SECRET_KEY;
  if (!secretKey || secretKey.trim().length === 0) {
    return null;
  }
  if (!stripeClient) {
    stripeClient = new Stripe(secretKey, {
      apiVersion: '2025-02-24.acacia' as any,
    });
  }
  return stripeClient;
}

export const PLAN_CONFIGS = {
  starter: {
    id: 'starter',
    name: 'Starter Plan',
    price: 5,
    credits: 100,
    priceId: process.env.STRIPE_PRICE_STARTER || '',
  },
  pro: {
    id: 'pro',
    name: 'Pro Plan',
    price: 12,
    credits: 300,
    priceId: process.env.STRIPE_PRICE_PRO || '',
  },
  business: {
    id: 'business',
    name: 'Business Plan',
    price: 25,
    credits: 800,
    priceId: process.env.STRIPE_PRICE_BUSINESS || '',
  },
};

export async function createCheckoutSession(params: {
  userId: string;
  userEmail: string;
  planId: 'starter' | 'pro' | 'business';
  appUrl: string;
}) {
  const stripe = getStripeClient();
  if (!stripe) {
    return {
      configured: false,
      message: 'Stripe payments are not configured yet. Add STRIPE_SECRET_KEY in the Secrets panel to activate paid subscriptions.',
    };
  }

  const plan = PLAN_CONFIGS[params.planId];
  if (!plan) {
    throw new Error('Invalid plan selection.');
  }

  const session = await stripe.checkout.sessions.create({
    payment_method_types: ['card'],
    mode: 'subscription',
    customer_email: params.userEmail,
    client_reference_id: params.userId,
    metadata: {
      userId: params.userId,
      planId: params.planId,
      creditsToAdd: plan.credits.toString(),
    },
    line_items: [
      {
        price_data: {
          currency: 'usd',
          product_data: {
            name: `VideoForge AI - ${plan.name}`,
            description: `${plan.credits} monthly AI video generation credits, 1080p rendering, and priority queue`,
          },
          unit_amount: plan.price * 100,
          recurring: {
            interval: 'month',
          },
        },
        quantity: 1,
      },
    ],
    success_url: `${params.appUrl}/?checkout_status=success&session_id={CHECKOUT_SESSION_ID}`,
    cancel_url: `${params.appUrl}/?checkout_status=cancelled`,
  });

  return {
    configured: true,
    url: session.url,
    sessionId: session.id,
  };
}
