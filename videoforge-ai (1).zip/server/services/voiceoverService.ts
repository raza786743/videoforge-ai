export interface CaptionCue {
  id: string;
  start: number; // seconds
  end: number;   // seconds
  text: string;
}

export interface VoiceoverOptions {
  voice: 'male' | 'female' | 'energetic' | 'calm' | 'documentary' | 'storytelling';
  language: string; // 'en', 'es', 'fr', 'de', 'ja', 'pt', 'hi', etc.
  speed?: number; // 0.8 to 1.3
}

export interface VoiceoverResult {
  audioUrl?: string;
  durationSeconds: number;
  captions: CaptionCue[];
  voice: string;
  language: string;
}

/**
 * Generate timed captions based on spoken text and pace
 */
export function generateCaptionsFromText(text: string, estimatedDuration: number = 10): CaptionCue[] {
  if (!text || text.trim().length === 0) return [];

  // Split into natural phrases or chunks of 4-7 words
  const words = text.trim().split(/\s+/);
  if (words.length === 0) return [];

  const chunks: string[] = [];
  let currentChunk: string[] = [];

  for (const word of words) {
    currentChunk.push(word);
    // Break on punctuation or when chunk reaches 5-7 words
    if (word.match(/[.,!?;:]$/) || currentChunk.length >= 6) {
      chunks.push(currentChunk.join(' '));
      currentChunk = [];
    }
  }
  if (currentChunk.length > 0) {
    chunks.push(currentChunk.join(' '));
  }

  const chunkCount = chunks.length;
  const cueDuration = estimatedDuration / Math.max(1, chunkCount);

  return chunks.map((chunk, index) => {
    const start = Number((index * cueDuration).toFixed(2));
    const end = Number(Math.min(estimatedDuration, (index + 1) * cueDuration).toFixed(2));
    return {
      id: `cue_${index + 1}`,
      start,
      end,
      text: chunk,
    };
  });
}

/**
 * Voiceover service
 */
export async function createVoiceover(text: string, options: VoiceoverOptions): Promise<VoiceoverResult> {
  const wordCount = text.trim().split(/\s+/).length;
  // Average speaking rate: ~2.5 words per second
  const speed = options.speed || 1.0;
  const estimatedSeconds = Math.max(3, Math.round((wordCount / 2.5) / speed));

  const captions = generateCaptionsFromText(text, estimatedSeconds);

  return {
    durationSeconds: estimatedSeconds,
    captions,
    voice: options.voice,
    language: options.language,
  };
}
