import dotenv from 'dotenv';
dotenv.config();

export interface VideoJobParams {
  userId: string;
  userEmail?: string;
  prompt: string;
  style: string;
  duration: number; // 5, 10, 15, 30
  aspectRatio: '9:16' | '16:9' | '1:1';
  imageUrl?: string;
  voiceover?: {
    enabled: boolean;
    voice: string;
    language: string;
    text: string;
  };
  captions?: {
    enabled: boolean;
    style: string;
  };
  backgroundMusic?: string;
  isFreePlan?: boolean;
}

export interface VideoJob {
  id: string;
  userId: string;
  prompt: string;
  style: string;
  duration: number;
  aspectRatio: '9:16' | '16:9' | '1:1';
  imageUrl?: string;
  status: 'queued' | 'processing' | 'completed' | 'failed';
  progress: number;
  videoUrl?: string;
  thumbnailUrl?: string;
  creditsUsed: number;
  provider: string;
  providerJobId?: string;
  error?: string;
  createdAt: number;
  updatedAt: number;
}

export interface VideoProviderAdapter {
  id: string;
  name: string;
  isConfigured(): boolean;
  generateVideo(params: VideoJobParams): Promise<{ providerJobId: string; status: 'queued' | 'processing' | 'completed'; videoUrl?: string; thumbnailUrl?: string }>;
  getVideoStatus(providerJobId: string): Promise<{ status: 'queued' | 'processing' | 'completed' | 'failed'; progress: number; videoUrl?: string; thumbnailUrl?: string; error?: string }>;
  downloadVideo?(url: string): Promise<{ buffer: Buffer; contentType: string }>;
}

// In-memory job cache for active queue polling
const activeJobs = new Map<string, VideoJob>();

/**
 * Google Veo / Gemini Video Generation Adapter
 * Integrates with Google's video generation models via GenAI SDK / REST endpoints
 */
class GoogleVeoProvider implements VideoProviderAdapter {
  id = 'google-veo';
  name = 'Google Veo Video Engine';

  isConfigured(): boolean {
    return Boolean(process.env.GEMINI_API_KEY && process.env.GEMINI_API_KEY.trim().length > 0);
  }

  async generateVideo(params: VideoJobParams): Promise<{ providerJobId: string; status: 'queued' | 'processing' | 'completed'; videoUrl?: string; thumbnailUrl?: string }> {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      throw new Error('Video generation service is not configured yet. Add the required API key in Secrets.');
    }

    const providerJobId = 'veo_' + Date.now() + '_' + Math.random().toString(36).substring(2, 9);
    
    // Try Google Video / Veo generation endpoint
    try {
      const response = await fetch(`https://generativelanguage.googleapis.com/v1beta/models/veo-2.0-generate-uhd:predictVideo?key=${apiKey}`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          prompt: { text: `${params.style} style video: ${params.prompt}. High production quality.` },
          video_duration_seconds: Math.min(params.duration, 10),
          aspect_ratio: params.aspectRatio,
        }),
      });

      if (response.ok) {
        const data = await response.json();
        const operationName = data.name || providerJobId;
        return {
          providerJobId: operationName,
          status: 'processing',
        };
      } else {
        const errorData = await response.json().catch(() => ({}));
        // If Veo 2.0 endpoint returned specific quota or access restriction, try standard video model or report
        const errorMsg = (errorData as any)?.error?.message || `Google Video API status: ${response.statusText}`;
        console.warn('Veo endpoint response:', errorMsg);
        
        // If the model is not provisioned or requires special allowlist, return clear status
        return {
          providerJobId,
          status: 'processing',
        };
      }
    } catch (err: any) {
      console.warn('Google Veo initial request error:', err.message);
      return {
        providerJobId,
        status: 'processing',
      };
    }
  }

  async getVideoStatus(providerJobId: string): Promise<{ status: 'queued' | 'processing' | 'completed' | 'failed'; progress: number; videoUrl?: string; thumbnailUrl?: string; error?: string }> {
    const apiKey = process.env.GEMINI_API_KEY;
    if (!apiKey) {
      return {
        status: 'failed',
        progress: 0,
        error: 'Video generation service is not configured yet. Add the required API key in Secrets.',
      };
    }

    // Check Google operation if providerJobId looks like an operation name
    if (providerJobId.startsWith('operations/') || providerJobId.includes('/operations/')) {
      try {
        const resp = await fetch(`https://generativelanguage.googleapis.com/v1beta/${providerJobId}?key=${apiKey}`);
        if (resp.ok) {
          const data = await resp.json();
          if (data.done) {
            if (data.error) {
              return { status: 'failed', progress: 0, error: data.error.message || 'Generation failed at provider.' };
            }
            const videoUri = data.response?.video?.uri || data.response?.outputUri;
            if (videoUri) {
              return { status: 'completed', progress: 100, videoUrl: videoUri };
            }
          } else {
            const metadata = data.metadata || {};
            const percent = metadata.progressPercent || 45;
            return { status: 'processing', progress: percent };
          }
        }
      } catch (err: any) {
        console.error('Operation polling error:', err);
      }
    }

    // If job was initiated without direct long-running operation response or API key doesn't have Veo preview,
    // verify if a generic video provider key exists
    return {
      status: 'failed',
      progress: 0,
      error: 'Google Video API operation could not be resolved. Please verify GEMINI_API_KEY permissions or supply VIDEO_API_KEY.',
    };
  }
}

/**
 * Compatible External Video Provider (Runway, Luma Dream Machine, Replicate, Fal, or Custom Webhook)
 * Configured via VIDEO_API_KEY and optional VIDEO_API_URL
 */
class ExternalVideoProvider implements VideoProviderAdapter {
  id = 'external-video-api';
  name = 'High-Definition Video Engine';

  isConfigured(): boolean {
    return Boolean(process.env.VIDEO_API_KEY && process.env.VIDEO_API_KEY.trim().length > 0);
  }

  async generateVideo(params: VideoJobParams): Promise<{ providerJobId: string; status: 'queued' | 'processing' | 'completed'; videoUrl?: string; thumbnailUrl?: string }> {
    const apiKey = process.env.VIDEO_API_KEY;
    if (!apiKey) {
      throw new Error('Video generation service is not configured yet. Add the required API key in Secrets.');
    }

    const apiUrl = process.env.VIDEO_API_URL || 'https://api.replicate.com/v1/predictions';

    // Submit request to external video provider
    const response = await fetch(apiUrl, {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${apiKey}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        version: process.env.VIDEO_MODEL_VERSION || 'luma/ray-2',
        input: {
          prompt: `${params.style} style: ${params.prompt}`,
          aspect_ratio: params.aspectRatio,
          duration: params.duration,
          image: params.imageUrl || undefined,
        },
      }),
    });

    if (!response.ok) {
      const errText = await response.text();
      let parsedMessage = errText;
      try {
        const jsonErr = JSON.parse(errText);
        parsedMessage = jsonErr.detail || jsonErr.error || errText;
      } catch {}
      throw new Error(`Video Provider API Error (${response.status}): ${parsedMessage}`);
    }

    const data = await response.json();
    return {
      providerJobId: data.id || ('ext_' + Date.now()),
      status: data.status === 'succeeded' ? 'completed' : 'processing',
      videoUrl: data.output ? (Array.isArray(data.output) ? data.output[0] : data.output) : undefined,
    };
  }

  async getVideoStatus(providerJobId: string): Promise<{ status: 'queued' | 'processing' | 'completed' | 'failed'; progress: number; videoUrl?: string; thumbnailUrl?: string; error?: string }> {
    const apiKey = process.env.VIDEO_API_KEY;
    if (!apiKey) {
      return { status: 'failed', progress: 0, error: 'Video generation service is not configured yet. Add the required API key in Secrets.' };
    }

    const apiUrl = (process.env.VIDEO_API_URL || 'https://api.replicate.com/v1/predictions') + `/${providerJobId}`;

    const response = await fetch(apiUrl, {
      headers: {
        'Authorization': `Bearer ${apiKey}`,
        'Content-Type': 'application/json',
      },
    });

    if (!response.ok) {
      return { status: 'failed', progress: 0, error: `Provider status check failed (${response.status}): ${response.statusText}` };
    }

    const data = await response.json();
    if (data.status === 'succeeded') {
      const videoUrl = Array.isArray(data.output) ? data.output[0] : data.output;
      return {
        status: 'completed',
        progress: 100,
        videoUrl,
      };
    } else if (data.status === 'failed' || data.status === 'canceled') {
      return {
        status: 'failed',
        progress: 0,
        error: data.error || 'Video generation failed at provider.',
      };
    } else {
      return {
        status: 'processing',
        progress: data.status === 'starting' ? 25 : 65,
      };
    }
  }
}

/**
 * Service Manager & Job Queue
 */
export class VideoGeneratorService {
  private providers: VideoProviderAdapter[];

  constructor() {
    this.providers = [
      new ExternalVideoProvider(),
      new GoogleVeoProvider(),
    ];
  }

  getAvailableProviders(): { id: string; name: string; configured: boolean }[] {
    return this.providers.map(p => ({
      id: p.id,
      name: p.name,
      configured: p.isConfigured(),
    }));
  }

  getActiveProvider(): VideoProviderAdapter | null {
    // 1. Check external provider first if configured
    const external = this.providers.find(p => p.id === 'external-video-api');
    if (external && external.isConfigured()) {
      return external;
    }
    // 2. Check Google provider if Gemini API key is set
    const google = this.providers.find(p => p.id === 'google-veo');
    if (google && google.isConfigured()) {
      return google;
    }
    return null;
  }

  /**
   * Submit generation job
   */
  async submitJob(params: VideoJobParams, jobId: string): Promise<VideoJob> {
    const provider = this.getActiveProvider();

    const creditCost = this.calculateCreditCost(params.duration);

    const newJob: VideoJob = {
      id: jobId,
      userId: params.userId,
      prompt: params.prompt,
      style: params.style,
      duration: params.duration,
      aspectRatio: params.aspectRatio,
      imageUrl: params.imageUrl,
      status: 'queued',
      progress: 5,
      creditsUsed: creditCost,
      provider: provider ? provider.name : 'None',
      createdAt: Date.now(),
      updatedAt: Date.now(),
    };

    if (!provider) {
      newJob.status = 'failed';
      newJob.progress = 0;
      newJob.error = 'Video generation service is not configured yet. Add the required API key in Secrets.';
      activeJobs.set(jobId, newJob);
      return newJob;
    }

    try {
      activeJobs.set(jobId, newJob);
      const result = await provider.generateVideo(params);
      newJob.providerJobId = result.providerJobId;
      newJob.status = result.status;
      newJob.progress = result.status === 'completed' ? 100 : 15;
      if (result.videoUrl) {
        newJob.videoUrl = result.videoUrl;
      }
      newJob.updatedAt = Date.now();
      activeJobs.set(jobId, newJob);

      // If asynchronous, start background polling
      if (result.status === 'processing' || result.status === 'queued') {
        this.startJobPolling(jobId, provider, result.providerJobId);
      }

      return newJob;
    } catch (err: any) {
      newJob.status = 'failed';
      newJob.progress = 0;
      newJob.error = err.message || 'Failed to submit generation request to provider.';
      newJob.updatedAt = Date.now();
      activeJobs.set(jobId, newJob);
      throw err;
    }
  }

  private calculateCreditCost(duration: number): number {
    switch (duration) {
      case 5: return 5;
      case 10: return 10;
      case 15: return 15;
      case 30: return 30;
      default: return Math.max(5, duration);
    }
  }

  /**
   * Get job status
   */
  async getJob(jobId: string): Promise<VideoJob | null> {
    return activeJobs.get(jobId) || null;
  }

  /**
   * Poll provider in background until terminal state
   */
  private startJobPolling(jobId: string, provider: VideoProviderAdapter, providerJobId: string) {
    let attempts = 0;
    const maxAttempts = 60; // 5 minutes polling at 5s intervals

    const interval = setInterval(async () => {
      attempts++;
      const currentJob = activeJobs.get(jobId);
      if (!currentJob || currentJob.status === 'completed' || currentJob.status === 'failed') {
        clearInterval(interval);
        return;
      }

      if (attempts >= maxAttempts) {
        clearInterval(interval);
        currentJob.status = 'failed';
        currentJob.error = 'Job timed out after 5 minutes waiting for provider response.';
        currentJob.updatedAt = Date.now();
        activeJobs.set(jobId, currentJob);
        return;
      }

      try {
        const status = await provider.getVideoStatus(providerJobId);
        currentJob.status = status.status;
        currentJob.progress = status.progress;
        if (status.videoUrl) {
          currentJob.videoUrl = status.videoUrl;
        }
        if (status.thumbnailUrl) {
          currentJob.thumbnailUrl = status.thumbnailUrl;
        }
        if (status.error) {
          currentJob.error = status.error;
        }
        currentJob.updatedAt = Date.now();
        activeJobs.set(jobId, currentJob);

        if (status.status === 'completed' || status.status === 'failed') {
          clearInterval(interval);
        }
      } catch (pollErr: any) {
        console.error(`Error polling job ${jobId}:`, pollErr.message);
      }
    }, 5000);
  }
}

export const videoGenerator = new VideoGeneratorService();
