import { GoogleGenAI } from '@google/genai';
import dotenv from 'dotenv';
dotenv.config();

export interface GeneratedScript {
  topic: string;
  hook: string;
  scenes: Array<{
    sceneNumber: number;
    title: string;
    visualPrompt: string;
    durationSeconds: number;
    voiceoverText: string;
  }>;
  voiceoverScript: string;
  ending: string;
  suggestedStyle: string;
}

export async function generateAIScript(topic: string, style: string = 'Cinematic', targetDuration: number = 15): Promise<GeneratedScript> {
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) {
    throw new Error('Gemini API key is not configured. Please add GEMINI_API_KEY in the Secrets panel.');
  }

  const ai = new GoogleGenAI({ apiKey });

  const prompt = `You are a world-class viral video producer and screenwriter for VideoForge AI.
Create a structured video production script for the following topic:
"${topic}"

Target style: ${style}
Target total duration: ${targetDuration} seconds

Return ONLY valid JSON adhering strictly to this JSON schema:
{
  "topic": "${topic}",
  "hook": "An irresistible 3-second opening hook line that grabs attention immediately",
  "scenes": [
    {
      "sceneNumber": 1,
      "title": "Short title of scene",
      "visualPrompt": "Detailed visual generation prompt for AI video generation describing camera movement, lighting, subjects, and cinematic atmosphere",
      "durationSeconds": 5,
      "voiceoverText": "Spoken voice-over narration for this scene"
    }
  ],
  "voiceoverScript": "The complete merged voice-over narration text from start to finish",
  "ending": "A memorable punchy closing line or call to action",
  "suggestedStyle": "${style}"
}

Ensure the sum of scene durations roughly matches ${targetDuration} seconds. Write high-converting, engaging, cinematic content. Do not include markdown code block syntax if possible, just raw JSON.`;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-2.5-flash',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
      },
    });

    const responseText = response.text || '';
    const cleaned = responseText.replace(/```json/g, '').replace(/```/g, '').trim();
    const parsed: GeneratedScript = JSON.parse(cleaned);
    return parsed;
  } catch (err: any) {
    console.error('Gemini script generation error:', err);
    throw new Error(`AI Script generation failed: ${err.message || 'Unknown error'}`);
  }
}
