import express, { Request, Response } from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';
import { videoGenerator, VideoJobParams } from './server/services/videoGenerator.ts';
import { generateAIScript } from './server/services/scriptGenerator.ts';
import { createVoiceover } from './server/services/voiceoverService.ts';
import { createCheckoutSession, getStripeClient } from './server/services/stripeService.ts';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = 3000;

// Admin identifier
const ADMIN_EMAIL = process.env.ADMIN_EMAIL || 'ghulamhussain8523@gmail.com';

// Mock system memory store for metrics tracking & active subscriptions
const systemMetrics = {
  totalUsers: 1,
  freeUsers: 1,
  paidUsers: 0,
  videosGenerated: 0,
  creditsConsumed: 0,
  failedGenerations: 0,
  revenue: 0,
};

// Express JSON body parser (keep raw for webhook if needed)
app.use((req, res, next) => {
  if (req.originalUrl === '/api/webhook') {
    express.raw({ type: 'application/json' })(req, res, next);
  } else {
    express.json({ limit: '50mb' })(req, res, next);
  }
});
app.use(express.urlencoded({ extended: true, limit: '50mb' }));

// 1. Health check
app.get('/api/health', (req: Request, res: Response) => {
  res.json({
    status: 'ok',
    timestamp: Date.now(),
    service: 'VideoForge AI Backend Engine',
  });
});

// 2. Configuration & API Keys status
app.get('/api/config/status', (req: Request, res: Response) => {
  const geminiConfigured = Boolean(process.env.GEMINI_API_KEY && process.env.GEMINI_API_KEY.trim().length > 0);
  const videoConfigured = Boolean(
    (process.env.VIDEO_API_KEY && process.env.VIDEO_API_KEY.trim().length > 0) ||
    geminiConfigured
  );
  const stripeConfigured = Boolean(process.env.STRIPE_SECRET_KEY && process.env.STRIPE_SECRET_KEY.trim().length > 0);

  res.json({
    geminiConfigured,
    videoConfigured,
    stripeConfigured,
    providers: videoGenerator.getAvailableProviders(),
    adminEmail: ADMIN_EMAIL,
  });
});

// 3. AI Script Generation via Gemini
app.post('/api/script/generate', async (req: Request, res: Response) => {
  try {
    const { topic, style = 'Cinematic', targetDuration = 15 } = req.body;

    if (!topic || typeof topic !== 'string' || topic.trim().length === 0) {
      res.status(400).json({ error: 'Please provide a topic for the script.' });
      return;
    }

    const script = await generateAIScript(topic.trim(), style, Number(targetDuration) || 15);
    res.json({ success: true, script });
  } catch (err: any) {
    console.error('Script generation error:', err.message);
    res.status(500).json({
      error: err.message || 'Failed to generate script. Please check GEMINI_API_KEY in Secrets.',
    });
  }
});

// 4. AI Voiceover & Captions Generation
app.post('/api/voiceover/generate', async (req: Request, res: Response) => {
  try {
    const { text, voice = 'calm', language = 'en', speed = 1.0 } = req.body;
    if (!text || typeof text !== 'string' || text.trim().length === 0) {
      res.status(400).json({ error: 'Voiceover text is required.' });
      return;
    }

    const result = await createVoiceover(text.trim(), { voice, language, speed });
    res.json({ success: true, voiceover: result });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Failed to generate voiceover.' });
  }
});

// 5. Submit Video Generation Job
app.post('/api/video/generate', async (req: Request, res: Response) => {
  try {
    const {
      userId,
      userEmail,
      prompt,
      style = 'Cinematic',
      duration = 10,
      aspectRatio = '16:9',
      imageUrl,
      voiceover,
      captions,
      backgroundMusic,
      userPlan = 'free',
      userCredits = 30,
    } = req.body;

    if (!userId) {
      res.status(401).json({ error: 'Unauthorized: User ID is required.' });
      return;
    }

    if (!prompt || typeof prompt !== 'string' || prompt.trim().length === 0) {
      res.status(400).json({ error: 'Video prompt is required.' });
      return;
    }

    // Duration validation
    const numDuration = Number(duration);
    if (![5, 10, 15, 30].includes(numDuration)) {
      res.status(400).json({ error: 'Invalid duration. Allowed: 5, 10, 15, or 30 seconds.' });
      return;
    }

    // Free plan constraint: max 10s
    if (userPlan === 'free' && numDuration > 10) {
      res.status(403).json({
        error: 'Free trial is limited to maximum 10-second videos. Upgrade to Starter or Pro to generate up to 30-second videos.',
      });
      return;
    }

    // Credit cost: 5s=5, 10s=10, 15s=15, 30s=30
    const creditCost = numDuration;
    if (userCredits < creditCost) {
      res.status(402).json({
        error: `Insufficient credits. This video requires ${creditCost} credits, but you have ${userCredits} available.`,
        requiredCredits: creditCost,
        availableCredits: userCredits,
      });
      return;
    }

    const jobId = 'job_' + Date.now() + '_' + Math.random().toString(36).substring(2, 8);

    const jobParams: VideoJobParams = {
      userId,
      userEmail,
      prompt: prompt.trim(),
      style,
      duration: numDuration,
      aspectRatio,
      imageUrl,
      voiceover,
      captions,
      backgroundMusic,
      isFreePlan: userPlan === 'free',
    };

    try {
      const job = await videoGenerator.submitJob(jobParams, jobId);
      systemMetrics.videosGenerated++;
      systemMetrics.creditsConsumed += creditCost;

      res.json({
        success: true,
        jobId: job.id,
        status: job.status,
        progress: job.progress,
        creditsUsed: creditCost,
        provider: job.provider,
      });
    } catch (submitErr: any) {
      systemMetrics.failedGenerations++;
      res.status(400).json({
        error: submitErr.message || 'Video generation service is not configured yet. Add the required API key in Secrets.',
      });
    }
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Internal error creating video job.' });
  }
});

// 6. Poll Video Job Status
app.get('/api/video/status/:jobId', async (req: Request, res: Response) => {
  try {
    const { jobId } = req.params;
    const job = await videoGenerator.getJob(jobId);

    if (!job) {
      res.status(404).json({ error: 'Video generation job not found.' });
      return;
    }

    res.json({
      jobId: job.id,
      status: job.status,
      progress: job.progress,
      videoUrl: job.videoUrl,
      thumbnailUrl: job.thumbnailUrl,
      creditsUsed: job.creditsUsed,
      error: job.error,
      updatedAt: job.updatedAt,
    });
  } catch (err: any) {
    res.status(500).json({ error: err.message || 'Failed to retrieve job status.' });
  }
});

// 7. Create Stripe Checkout Session
app.post('/api/create-checkout', async (req: Request, res: Response) => {
  try {
    const { userId, userEmail, planId } = req.body;
    if (!userId || !userEmail || !planId) {
      res.status(400).json({ error: 'Missing required parameters (userId, userEmail, planId).' });
      return;
    }

    const appUrl = process.env.APP_URL || `http://localhost:${PORT}`;
    const result = await createCheckoutSession({
      userId,
      userEmail,
      planId,
      appUrl,
    });

    res.json(result);
  } catch (err: any) {
    console.error('Checkout error:', err);
    res.status(500).json({ error: err.message || 'Failed to initiate checkout.' });
  }
});

// 8. Stripe Webhook
app.post('/api/webhook', async (req: Request, res: Response) => {
  const stripe = getStripeClient();
  const webhookSecret = process.env.STRIPE_WEBHOOK_SECRET;

  if (!stripe || !webhookSecret) {
    // If webhook secret is not set, log and return 200
    res.status(200).json({ received: true, note: 'Stripe webhook secret not configured.' });
    return;
  }

  const sig = req.headers['stripe-signature'] as string;
  let event: any;

  try {
    event = stripe.webhooks.constructEvent(req.body, sig, webhookSecret);
  } catch (err: any) {
    console.error(`Webhook signature verification failed: ${err.message}`);
    res.status(400).send(`Webhook Error: ${err.message}`);
    return;
  }

  // Handle the checkout event
  if (event.type === 'checkout.session.completed') {
    const session = event.data.object;
    const userId = session.client_reference_id || session.metadata?.userId;
    const planId = session.metadata?.planId;
    const creditsToAdd = parseInt(session.metadata?.creditsToAdd || '100', 10);

    console.log(`[Stripe Webhook] Upgrading user ${userId} to plan ${planId} (+${creditsToAdd} credits)`);
    systemMetrics.paidUsers++;
    systemMetrics.revenue += (session.amount_total || 0) / 100;
  }

  res.json({ received: true });
});

// 9. Subscription & Cancellation Endpoints
app.get('/api/subscription/:userId', (req: Request, res: Response) => {
  res.json({
    active: true,
    plans: [
      { id: 'starter', name: 'Starter', price: 5, credits: 100, features: ['100 credits/mo', '1080p Export', 'No watermark', 'AI voice'] },
      { id: 'pro', name: 'Pro', price: 12, credits: 300, features: ['300 credits/mo', '1080p Export', 'No watermark', 'Premium voices', 'Priority queue'] },
      { id: 'business', name: 'Business', price: 25, credits: 800, features: ['800 credits/mo', '1080p Export', 'No watermark', 'Ultra-fast queue', 'Dedicated API support'] },
    ],
  });
});

app.post('/api/cancel-subscription', (req: Request, res: Response) => {
  res.json({
    success: true,
    message: 'Subscription cancellation scheduled at the end of the current billing cycle.',
  });
});

// 10. Admin Endpoints (Protected)
function checkAdminAuth(req: Request): boolean {
  const userEmail = req.headers['x-user-email'] as string;
  const isAdminHeader = req.headers['x-is-admin'] === 'true';
  return isAdminHeader || userEmail === ADMIN_EMAIL;
}

app.get('/api/admin/stats', (req: Request, res: Response) => {
  if (!checkAdminAuth(req)) {
    res.status(403).json({ error: 'Access denied. Admin authorization required.' });
    return;
  }

  res.json({
    metrics: {
      ...systemMetrics,
      activeJobs: 0,
    },
    systemStatus: {
      gemini: Boolean(process.env.GEMINI_API_KEY),
      videoProvider: Boolean(process.env.VIDEO_API_KEY || process.env.GEMINI_API_KEY),
      stripe: Boolean(process.env.STRIPE_SECRET_KEY),
    },
  });
});

// Proxy video download endpoint to handle CORS and trigger browser download
app.get('/api/video/download', async (req: Request, res: Response) => {
  const url = req.query.url as string;
  if (!url) {
    res.status(400).send('Missing video URL parameter.');
    return;
  }

  try {
    const videoResp = await fetch(url);
    if (!videoResp.ok) {
      res.status(videoResp.status).send('Failed to fetch video from remote storage.');
      return;
    }

    const contentType = videoResp.headers.get('content-type') || 'video/mp4';
    res.setHeader('Content-Type', contentType);
    res.setHeader('Content-Disposition', 'attachment; filename="videoforge_ai_render.mp4"');

    const arrayBuffer = await videoResp.arrayBuffer();
    res.send(Buffer.from(arrayBuffer));
  } catch (err: any) {
    res.status(500).send(`Download error: ${err.message}`);
  }
});

// Vite Middleware for Development or Static serving for Production
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req: Request, res: Response) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`VideoForge AI Server running on http://0.0.0.0:${PORT}`);
  });
}

startServer().catch((err) => {
  console.error('Fatal server startup error:', err);
});
