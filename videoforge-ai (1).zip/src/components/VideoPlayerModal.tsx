import React, { useState, useRef, useEffect } from 'react';
import { VideoRecord, CaptionDisplayOptions } from '../types';
import {
  X,
  Download,
  Trash2,
  Subtitles,
  Sliders,
  Play,
  Pause,
  RotateCcw,
  Volume2,
  VolumeX,
} from 'lucide-react';

interface VideoPlayerModalProps {
  video: VideoRecord | null;
  onClose: () => void;
  onDelete?: (videoId: string) => void;
  onRegenerate?: (video: VideoRecord) => void;
}

export const VideoPlayerModal: React.FC<VideoPlayerModalProps> = ({
  video,
  onClose,
  onDelete,
  onRegenerate,
}) => {
  const videoRef = useRef<HTMLVideoElement>(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [isMuted, setIsMuted] = useState(false);
  const [activeCaption, setActiveCaption] = useState<string | null>(null);

  // Caption Display Customization
  const [captionSettings, setCaptionSettings] = useState<CaptionDisplayOptions>({
    enabled: true,
    fontSize: 'medium',
    position: 'bottom',
    style: 'reels',
  });
  const [showCaptionControls, setShowCaptionControls] = useState(false);

  useEffect(() => {
    if (video?.videoUrl && videoRef.current) {
      videoRef.current.currentTime = 0;
      videoRef.current.play().catch(() => {});
    }
  }, [video]);

  if (!video) return null;

  const handleTimeUpdate = () => {
    if (!videoRef.current) return;
    const time = videoRef.current.currentTime;
    setCurrentTime(time);

    // Find current caption cue
    if (captionSettings.enabled && video.captions && video.captions.length > 0) {
      const active = video.captions.find((c) => time >= c.start && time <= c.end);
      setActiveCaption(active ? active.text : null);
    } else {
      setActiveCaption(null);
    }
  };

  const togglePlay = () => {
    if (!videoRef.current) return;
    if (videoRef.current.paused) {
      videoRef.current.play();
      setIsPlaying(true);
    } else {
      videoRef.current.pause();
      setIsPlaying(false);
    }
  };

  const toggleMute = () => {
    if (!videoRef.current) return;
    videoRef.current.muted = !videoRef.current.muted;
    setIsMuted(videoRef.current.muted);
  };

  const handleDownload = () => {
    if (!video.videoUrl) return;
    const downloadUrl = `/api/video/download?url=${encodeURIComponent(video.videoUrl)}`;
    const a = document.createElement('a');
    a.href = downloadUrl;
    a.download = `videoforge_${video.videoId.slice(0, 8)}.mp4`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  // Caption Styling classes
  const fontSizes = {
    small: 'text-sm sm:text-base',
    medium: 'text-base sm:text-xl font-bold',
    large: 'text-xl sm:text-2xl font-black uppercase tracking-wide',
  };

  const positions = {
    top: 'top-8',
    center: 'top-1/2 -translate-y-1/2',
    bottom: 'bottom-16',
  };

  const styles = {
    cinematic: 'text-amber-300 italic drop-shadow-[0_2px_4px_rgba(0,0,0,0.9)]',
    reels: 'text-yellow-300 font-black drop-shadow-[0_3px_6px_rgba(0,0,0,1)] [-webkit-text-stroke:1px_black]',
    minimal: 'text-white bg-black/50 px-3 py-1 rounded-lg backdrop-blur-xs',
    banner: 'text-white bg-indigo-950/80 px-4 py-1.5 rounded-md border border-indigo-500/30',
  };

  const aspectClass =
    video.aspectRatio === '9:16'
      ? 'max-w-xs aspect-[9/16]'
      : video.aspectRatio === '1:1'
      ? 'max-w-md aspect-square'
      : 'max-w-2xl aspect-[16/9]';

  return (
    <div
      id="video-player-modal-backdrop"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/85 backdrop-blur-md animate-in fade-in"
    >
      <div
        id="video-player-card"
        className="relative w-full max-w-3xl bg-zinc-950 border border-zinc-800 rounded-2xl overflow-hidden shadow-2xl flex flex-col max-h-[95vh]"
      >
        {/* Header */}
        <div className="flex items-center justify-between px-5 py-3.5 border-b border-zinc-800/80 bg-zinc-900/50">
          <div className="flex items-center gap-2.5 truncate mr-4">
            <span className="text-xs font-semibold px-2 py-0.5 rounded bg-zinc-800 text-zinc-300 border border-zinc-700 font-mono">
              {video.aspectRatio}
            </span>
            <span className="text-xs font-semibold px-2 py-0.5 rounded bg-indigo-950/60 text-indigo-300 border border-indigo-700/50">
              {video.style}
            </span>
            <h3 className="text-xs font-medium text-zinc-200 truncate">{video.prompt}</h3>
          </div>

          <div className="flex items-center gap-2">
            <button
              id="player-caption-settings-toggle"
              onClick={() => setShowCaptionControls(!showCaptionControls)}
              className={`p-1.5 rounded-lg border text-xs flex items-center gap-1.5 transition-colors ${
                showCaptionControls
                  ? 'bg-indigo-600 text-white border-indigo-500'
                  : 'bg-zinc-900 text-zinc-300 border-zinc-800 hover:border-zinc-700'
              }`}
              title="Caption Settings"
            >
              <Subtitles className="w-3.5 h-3.5" />
              <span className="hidden sm:inline">Captions</span>
            </button>

            <button
              id="player-download-btn"
              onClick={handleDownload}
              className="p-1.5 rounded-lg bg-indigo-600 hover:bg-indigo-500 text-white transition-colors"
              title="Download Video"
            >
              <Download className="w-4 h-4" />
            </button>

            <button
              id="player-close-btn"
              onClick={onClose}
              className="p-1.5 rounded-lg text-zinc-400 hover:text-white hover:bg-zinc-800 transition-colors"
              title="Close"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* Video Canvas & Caption Layer */}
        <div className="relative flex-1 bg-black flex items-center justify-center p-4 overflow-hidden min-h-[300px]">
          <div className={`relative w-full ${aspectClass} mx-auto flex items-center justify-center bg-zinc-900 rounded-xl overflow-hidden shadow-2xl`}>
            {video.videoUrl ? (
              <video
                ref={videoRef}
                src={video.videoUrl}
                playsInline
                loop
                onPlay={() => setIsPlaying(true)}
                onPause={() => setIsPlaying(false)}
                onTimeUpdate={handleTimeUpdate}
                onLoadedMetadata={() => {
                  if (videoRef.current) setDuration(videoRef.current.duration);
                }}
                className="w-full h-full object-contain cursor-pointer"
                onClick={togglePlay}
              />
            ) : (
              <div className="p-6 text-center text-zinc-400 text-xs">
                Video is not available or still processing.
              </div>
            )}

            {/* Captions Overlay */}
            {captionSettings.enabled && activeCaption && (
              <div
                id="video-player-captions-overlay"
                className={`absolute left-0 right-0 px-4 text-center pointer-events-none transition-all ${
                  positions[captionSettings.position]
                }`}
              >
                <span
                  className={`inline-block max-w-[90%] transition-transform duration-100 ${
                    fontSizes[captionSettings.fontSize]
                  } ${styles[captionSettings.style]}`}
                >
                  {activeCaption}
                </span>
              </div>
            )}
          </div>
        </div>

        {/* Caption Settings Drawer */}
        {showCaptionControls && (
          <div className="bg-zinc-900 border-t border-zinc-800 p-4 animate-in slide-in-from-bottom-2 text-xs">
            <div className="flex flex-wrap items-center justify-between gap-4">
              <div className="flex items-center gap-4">
                <label className="flex items-center gap-2 cursor-pointer font-medium text-zinc-200">
                  <input
                    type="checkbox"
                    checked={captionSettings.enabled}
                    onChange={(e) =>
                      setCaptionSettings({ ...captionSettings, enabled: e.target.checked })
                    }
                    className="rounded border-zinc-700 text-indigo-600 focus:ring-indigo-500"
                  />
                  <span>Show Captions</span>
                </label>

                <div className="flex items-center gap-2">
                  <span className="text-zinc-400">Position:</span>
                  {(['bottom', 'center', 'top'] as const).map((pos) => (
                    <button
                      key={pos}
                      onClick={() => setCaptionSettings({ ...captionSettings, position: pos })}
                      className={`px-2 py-0.5 rounded capitalize ${
                        captionSettings.position === pos
                          ? 'bg-indigo-600 text-white'
                          : 'bg-zinc-800 text-zinc-400 hover:text-white'
                      }`}
                    >
                      {pos}
                    </button>
                  ))}
                </div>
              </div>

              <div className="flex items-center gap-4">
                <div className="flex items-center gap-2">
                  <span className="text-zinc-400">Size:</span>
                  {(['small', 'medium', 'large'] as const).map((size) => (
                    <button
                      key={size}
                      onClick={() => setCaptionSettings({ ...captionSettings, fontSize: size })}
                      className={`px-2 py-0.5 rounded capitalize ${
                        captionSettings.fontSize === size
                          ? 'bg-indigo-600 text-white'
                          : 'bg-zinc-800 text-zinc-400 hover:text-white'
                      }`}
                    >
                      {size}
                    </button>
                  ))}
                </div>

                <div className="flex items-center gap-2">
                  <span className="text-zinc-400">Style:</span>
                  {(['reels', 'cinematic', 'minimal', 'banner'] as const).map((style) => (
                    <button
                      key={style}
                      onClick={() => setCaptionSettings({ ...captionSettings, style })}
                      className={`px-2 py-0.5 rounded capitalize ${
                        captionSettings.style === style
                          ? 'bg-indigo-600 text-white'
                          : 'bg-zinc-800 text-zinc-400 hover:text-white'
                      }`}
                    >
                      {style}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Playback Controls Footer */}
        <div className="px-5 py-3 border-t border-zinc-800/80 bg-zinc-900/60 flex items-center justify-between text-xs">
          <div className="flex items-center gap-3">
            <button
              id="player-play-toggle-btn"
              onClick={togglePlay}
              className="p-2 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-white transition-colors"
            >
              {isPlaying ? <Pause className="w-4 h-4" /> : <Play className="w-4 h-4" />}
            </button>

            <button
              id="player-mute-toggle-btn"
              onClick={toggleMute}
              className="p-2 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-white transition-colors"
            >
              {isMuted ? <VolumeX className="w-4 h-4" /> : <Volume2 className="w-4 h-4" />}
            </button>

            <span className="text-zinc-400 font-mono text-[11px]">
              {currentTime.toFixed(1)}s / {duration > 0 ? duration.toFixed(1) : video.duration}s
            </span>
          </div>

          <div className="flex items-center gap-2">
            {onRegenerate && (
              <button
                id="player-regenerate-btn"
                onClick={() => onRegenerate(video)}
                className="px-3 py-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-zinc-300 hover:text-white flex items-center gap-1.5 transition-colors"
              >
                <RotateCcw className="w-3.5 h-3.5" />
                <span className="hidden sm:inline">Regenerate</span>
              </button>
            )}

            {onDelete && (
              <button
                id="player-delete-btn"
                onClick={() => onDelete(video.videoId)}
                className="p-1.5 rounded-lg text-zinc-500 hover:text-rose-400 hover:bg-rose-950/40 transition-colors"
                title="Delete Video"
              >
                <Trash2 className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
