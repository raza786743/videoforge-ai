import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { AppView } from '../types';
import {
  Sparkles,
  Coins,
  ShieldCheck,
  User,
  LogOut,
  Menu,
  X,
  CreditCard,
  Plus,
} from 'lucide-react';

interface NavbarProps {
  currentView: AppView;
  setCurrentView: (view: AppView) => void;
  onOpenAuth: (mode?: 'login' | 'signup') => void;
  isSidebarOpen: boolean;
  setIsSidebarOpen: (open: boolean) => void;
}

export const Navbar: React.FC<NavbarProps> = ({
  currentView,
  setCurrentView,
  onOpenAuth,
  isSidebarOpen,
  setIsSidebarOpen,
}) => {
  const { user, profile, logout, isAdmin } = useAuth();
  const [userDropdownOpen, setUserDropdownOpen] = useState(false);

  const planBadgeColors: Record<string, string> = {
    free: 'bg-zinc-800 text-zinc-300 border-zinc-700',
    starter: 'bg-blue-950/60 text-blue-300 border-blue-700/50',
    pro: 'bg-indigo-950/60 text-indigo-300 border-indigo-700/50',
    business: 'bg-purple-950/60 text-purple-300 border-purple-700/50',
  };

  return (
    <header id="app-navbar" className="sticky top-0 z-40 h-16 w-full border-b border-zinc-800/80 bg-zinc-950/80 backdrop-blur-md px-4 sm:px-6 flex items-center justify-between">
      <div className="flex items-center gap-3">
        {/* Mobile menu toggle */}
        {user && (
          <button
            id="mobile-sidebar-toggle"
            onClick={() => setIsSidebarOpen(!isSidebarOpen)}
            className="md:hidden p-2 text-zinc-400 hover:text-white rounded-lg hover:bg-zinc-900"
            aria-label="Toggle Navigation"
          >
            {isSidebarOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        )}

        {/* Logo / Brand */}
        <button
          id="brand-logo-btn"
          onClick={() => setCurrentView(user ? 'dashboard' : 'landing')}
          className="flex items-center gap-2.5 group text-left cursor-pointer"
        >
          <div className="w-8 h-8 rounded-xl bg-gradient-to-tr from-indigo-500 via-indigo-600 to-violet-500 flex items-center justify-center shadow-md shadow-indigo-600/30 group-hover:scale-105 transition-transform">
            <Sparkles className="w-4 h-4 text-white" />
          </div>
          <div>
            <div className="flex items-center gap-1.5">
              <span className="font-bold text-base tracking-tight text-white">VideoForge</span>
              <span className="text-[10px] uppercase font-bold tracking-wider px-1.5 py-0.5 rounded bg-indigo-500/20 text-indigo-400 border border-indigo-500/30">
                AI
              </span>
            </div>
          </div>
        </button>
      </div>

      {/* Center navigation for Landing mode */}
      {!user && (
        <nav className="hidden md:flex items-center gap-6 text-sm font-medium text-zinc-400">
          <button
            id="nav-features-btn"
            onClick={() => setCurrentView('landing')}
            className={`transition-colors hover:text-white ${currentView === 'landing' ? 'text-white' : ''}`}
          >
            Features
          </button>
          <button
            id="nav-templates-btn"
            onClick={() => setCurrentView('templates')}
            className={`transition-colors hover:text-white ${currentView === 'templates' ? 'text-white' : ''}`}
          >
            Templates
          </button>
          <button
            id="nav-pricing-btn"
            onClick={() => setCurrentView('pricing')}
            className={`transition-colors hover:text-white ${currentView === 'pricing' ? 'text-white' : ''}`}
          >
            Pricing
          </button>
        </nav>
      )}

      {/* Right Controls */}
      <div className="flex items-center gap-3">
        {user ? (
          <>
            {/* Credits badge */}
            <div
              id="navbar-credits-badge"
              onClick={() => setCurrentView('pricing')}
              className="flex items-center gap-2 px-3 py-1.5 rounded-full bg-zinc-900 border border-zinc-800 text-zinc-200 text-xs font-semibold hover:border-zinc-700 transition-colors cursor-pointer"
              title="Available Credits - Click to Buy More"
            >
              <Coins className="w-3.5 h-3.5 text-amber-400" />
              <span>{profile?.credits ?? 0}</span>
              <span className="text-zinc-500 font-normal hidden sm:inline">credits</span>
            </div>

            {/* Plan Badge */}
            <div
              id="navbar-plan-badge"
              className={`hidden sm:inline-flex items-center text-[11px] font-semibold uppercase tracking-wider px-2.5 py-1 rounded-full border ${
                planBadgeColors[profile?.plan || 'free']
              }`}
            >
              {profile?.plan || 'free'}
            </div>

            {/* Quick Create Video CTA */}
            <button
              id="navbar-quick-create-btn"
              onClick={() => setCurrentView('create')}
              className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-xs font-medium transition-colors shadow-sm shadow-indigo-600/30"
            >
              <Plus className="w-3.5 h-3.5" />
              Create
            </button>

            {/* User Profile Dropdown */}
            <div className="relative">
              <button
                id="user-profile-menu-btn"
                onClick={() => setUserDropdownOpen(!userDropdownOpen)}
                className="flex items-center gap-2 p-1 rounded-full border border-zinc-800 hover:border-zinc-700 bg-zinc-900 text-zinc-200 transition-colors"
                aria-label="User Menu"
              >
                {user.photoURL ? (
                  <img
                    src={user.photoURL}
                    alt={user.displayName || 'User'}
                    className="w-7 h-7 rounded-full object-cover"
                    referrerPolicy="no-referrer"
                  />
                ) : (
                  <div className="w-7 h-7 rounded-full bg-indigo-600/30 border border-indigo-500/40 flex items-center justify-center text-xs font-bold text-indigo-300">
                    {(user.displayName || user.email || 'U').charAt(0).toUpperCase()}
                  </div>
                )}
              </button>

              {userDropdownOpen && (
                <div
                  id="user-dropdown-menu"
                  className="absolute right-0 mt-2 w-56 rounded-xl bg-zinc-900 border border-zinc-800 shadow-xl py-2 z-50 text-xs text-zinc-300 animate-in fade-in zoom-in-95"
                >
                  <div className="px-3.5 py-2 border-b border-zinc-800 mb-1">
                    <p className="font-semibold text-white truncate">{user.displayName || 'Video Creator'}</p>
                    <p className="text-zinc-500 truncate text-[11px]">{user.email}</p>
                    <div className="mt-1.5 flex items-center gap-1.5">
                      <span className="text-[10px] px-1.5 py-0.5 rounded bg-zinc-800 text-zinc-300 uppercase font-mono">
                        {profile?.plan || 'Free'} Plan
                      </span>
                      {isAdmin && (
                        <span className="text-[10px] px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-400 border border-amber-500/30 uppercase font-mono flex items-center gap-1">
                          <ShieldCheck className="w-2.5 h-2.5" /> Admin
                        </span>
                      )}
                    </div>
                  </div>

                  <button
                    id="menu-settings-btn"
                    onClick={() => {
                      setCurrentView('settings');
                      setUserDropdownOpen(false);
                    }}
                    className="w-full text-left px-3.5 py-2 hover:bg-zinc-800/80 flex items-center gap-2"
                  >
                    <User className="w-3.5 h-3.5 text-zinc-400" />
                    Account & API Status
                  </button>

                  <button
                    id="menu-pricing-btn"
                    onClick={() => {
                      setCurrentView('pricing');
                      setUserDropdownOpen(false);
                    }}
                    className="w-full text-left px-3.5 py-2 hover:bg-zinc-800/80 flex items-center gap-2"
                  >
                    <CreditCard className="w-3.5 h-3.5 text-zinc-400" />
                    Upgrade Plan / Add Credits
                  </button>

                  {isAdmin && (
                    <button
                      id="menu-admin-btn"
                      onClick={() => {
                        setCurrentView('admin');
                        setUserDropdownOpen(false);
                      }}
                      className="w-full text-left px-3.5 py-2 hover:bg-zinc-800/80 flex items-center gap-2 text-amber-400"
                    >
                      <ShieldCheck className="w-3.5 h-3.5" />
                      Admin Dashboard
                    </button>
                  )}

                  <div className="border-t border-zinc-800 my-1" />

                  <button
                    id="menu-logout-btn"
                    onClick={async () => {
                      setUserDropdownOpen(false);
                      await logout();
                      setCurrentView('landing');
                    }}
                    className="w-full text-left px-3.5 py-2 hover:bg-rose-950/40 text-rose-400 flex items-center gap-2"
                  >
                    <LogOut className="w-3.5 h-3.5" />
                    Sign Out
                  </button>
                </div>
              )}
            </div>
          </>
        ) : (
          <div className="flex items-center gap-2.5">
            <button
              id="navbar-login-btn"
              onClick={() => onOpenAuth('login')}
              className="px-3 py-1.5 text-xs font-medium text-zinc-300 hover:text-white transition-colors"
            >
              Sign In
            </button>
            <button
              id="navbar-signup-btn"
              onClick={() => onOpenAuth('signup')}
              className="px-3.5 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-xs font-semibold transition-all shadow-md shadow-indigo-600/25 cursor-pointer"
            >
              Start Free
            </button>
          </div>
        )}
      </div>
    </header>
  );
};
