import React from 'react';
import { AppView } from '../types';
import { useAuth } from '../context/AuthContext';
import {
  LayoutDashboard,
  Video,
  Image as ImageIcon,
  FileText,
  Film,
  Sparkles,
  Coins,
  CreditCard,
  Settings,
  ShieldCheck,
  Zap,
} from 'lucide-react';

interface SidebarProps {
  currentView: AppView;
  setCurrentView: (view: AppView) => void;
  isOpen: boolean;
  onClose: () => void;
  videosCount?: number;
}

export const Sidebar: React.FC<SidebarProps> = ({
  currentView,
  setCurrentView,
  isOpen,
  onClose,
  videosCount = 0,
}) => {
  const { profile, isAdmin } = useAuth();

  const navigationItems: Array<{
    id: AppView;
    label: string;
    icon: React.ReactNode;
    badge?: string | number;
    badgeColor?: string;
  }> = [
    {
      id: 'dashboard',
      label: 'Dashboard',
      icon: <LayoutDashboard className="w-4 h-4" />,
    },
    {
      id: 'create',
      label: 'Create Video',
      icon: <Video className="w-4 h-4" />,
      badge: 'Pro',
      badgeColor: 'bg-indigo-500/20 text-indigo-400 border-indigo-500/30',
    },
    {
      id: 'image-to-video',
      label: 'Image to Video',
      icon: <ImageIcon className="w-4 h-4" />,
    },
    {
      id: 'script',
      label: 'AI Script',
      icon: <FileText className="w-4 h-4" />,
      badge: 'Gemini',
      badgeColor: 'bg-emerald-500/20 text-emerald-400 border-emerald-500/30',
    },
    {
      id: 'videos',
      label: 'My Videos',
      icon: <Film className="w-4 h-4" />,
      badge: videosCount > 0 ? videosCount : undefined,
      badgeColor: 'bg-zinc-800 text-zinc-300 border-zinc-700',
    },
    {
      id: 'templates',
      label: 'Templates',
      icon: <Sparkles className="w-4 h-4" />,
    },
    {
      id: 'pricing',
      label: 'Pricing & Plans',
      icon: <CreditCard className="w-4 h-4" />,
    },
    {
      id: 'settings',
      label: 'Settings',
      icon: <Settings className="w-4 h-4" />,
    },
  ];

  if (isAdmin) {
    navigationItems.push({
      id: 'admin',
      label: 'Admin Panel',
      icon: <ShieldCheck className="w-4 h-4" />,
      badge: 'Admin',
      badgeColor: 'bg-amber-500/20 text-amber-400 border-amber-500/30',
    });
  }

  const handleSelect = (view: AppView) => {
    setCurrentView(view);
    onClose();
  };

  return (
    <>
      {/* Mobile Backdrop */}
      {isOpen && (
        <div
          id="sidebar-backdrop"
          onClick={onClose}
          className="fixed inset-0 bg-black/60 backdrop-blur-xs z-30 md:hidden animate-in fade-in"
        />
      )}

      <aside
        id="app-sidebar"
        className={`fixed md:sticky top-16 left-0 z-30 h-[calc(100vh-4rem)] w-64 shrink-0 bg-zinc-950 border-r border-zinc-800/80 flex flex-col justify-between p-4 transition-transform duration-200 ease-in-out ${
          isOpen ? 'translate-x-0' : '-translate-x-full md:translate-x-0'
        }`}
      >
        <div className="space-y-1">
          <div className="px-3 py-2 text-[11px] font-semibold uppercase tracking-wider text-zinc-500">
            Navigation
          </div>

          <nav className="space-y-1">
            {navigationItems.map((item) => {
              const active = currentView === item.id;
              return (
                <button
                  key={item.id}
                  id={`sidebar-item-${item.id}`}
                  onClick={() => handleSelect(item.id)}
                  className={`w-full flex items-center justify-between px-3 py-2.5 rounded-xl text-xs font-medium transition-all ${
                    active
                      ? 'bg-indigo-600/15 text-indigo-300 border border-indigo-500/30 shadow-xs'
                      : 'text-zinc-400 hover:text-zinc-200 hover:bg-zinc-900/80'
                  }`}
                >
                  <div className="flex items-center gap-3">
                    <span className={active ? 'text-indigo-400' : 'text-zinc-400'}>
                      {item.icon}
                    </span>
                    <span>{item.label}</span>
                  </div>

                  {item.badge && (
                    <span
                      className={`text-[10px] font-mono px-1.5 py-0.5 rounded border ${
                        item.badgeColor || 'bg-zinc-800 text-zinc-300 border-zinc-700'
                      }`}
                    >
                      {item.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </nav>
        </div>

        {/* Bottom Credits Card */}
        <div className="pt-4 border-t border-zinc-800/80">
          <div
            id="sidebar-credits-card"
            className="p-3.5 rounded-xl bg-gradient-to-br from-zinc-900 via-zinc-900 to-indigo-950/40 border border-zinc-800/90 text-zinc-300"
          >
            <div className="flex items-center justify-between mb-2">
              <span className="text-[11px] font-medium text-zinc-400 flex items-center gap-1.5">
                <Coins className="w-3.5 h-3.5 text-amber-400" />
                Remaining Credits
              </span>
              <span className="text-xs font-bold text-white font-mono">
                {profile?.credits ?? 0}
              </span>
            </div>

            <div className="w-full bg-zinc-800 rounded-full h-1.5 overflow-hidden mb-3">
              <div
                className="bg-gradient-to-r from-indigo-500 to-violet-500 h-full rounded-full transition-all duration-500"
                style={{
                  width: `${Math.min(100, Math.max(5, ((profile?.credits ?? 0) / (profile?.plan === 'business' ? 800 : profile?.plan === 'pro' ? 300 : profile?.plan === 'starter' ? 100 : 30)) * 100))}%`,
                }}
              />
            </div>

            <button
              id="sidebar-upgrade-btn"
              onClick={() => handleSelect('pricing')}
              className="w-full py-1.5 px-3 bg-zinc-800 hover:bg-zinc-700 text-zinc-200 hover:text-white rounded-lg text-[11px] font-medium flex items-center justify-center gap-1.5 border border-zinc-700/60 transition-colors"
            >
              <Zap className="w-3 h-3 text-amber-400" />
              {profile?.plan === 'free' ? 'Upgrade Plan' : 'Get More Credits'}
            </button>
          </div>
        </div>
      </aside>
    </>
  );
};
