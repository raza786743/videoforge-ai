/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { AuthProvider, useAuth } from './context/AuthContext';
import { AppView, VideoRecord, VideoStyle, VideoDuration, AspectRatio } from './types';
import { subscribeUserVideos } from './lib/firebase';
import { Navbar } from './components/Navbar';
import { Sidebar } from './components/Sidebar';
import { AuthModal } from './components/AuthModal';
import { VideoPlayerModal } from './components/VideoPlayerModal';

// Views
import { LandingView } from './views/LandingView';
import { DashboardView } from './views/DashboardView';
import { CreateVideoView } from './views/CreateVideoView';
import { ImageToVideoView } from './views/ImageToVideoView';
import { ScriptGeneratorView } from './views/ScriptGeneratorView';
import { MyVideosView } from './views/MyVideosView';
import { TemplatesView } from './views/TemplatesView';
import { PricingView } from './views/PricingView';
import { SettingsView } from './views/SettingsView';
import { AdminView } from './views/AdminView';

function VideoForgeApp() {
  const { user, profile, loading } = useAuth();

  // Navigation state: if signed in, default to dashboard; otherwise landing
  const [currentView, setCurrentView] = useState<AppView>('landing');
  const [authModalOpen, setAuthModalOpen] = useState(false);
  const [authMode, setAuthMode] = useState<'login' | 'signup' | 'forgot-password'>('signup');

  // Video playback modal
  const [activeVideo, setActiveVideo] = useState<VideoRecord | null>(null);

  // User videos from Firestore
  const [userVideos, setUserVideos] = useState<VideoRecord[]>([]);

  // Pre-filled state for Create Video (from script generator or templates or regenerate)
  const [createPrefill, setCreatePrefill] = useState<{
    prompt: string;
    style: VideoStyle;
    duration: VideoDuration;
  }>({
    prompt: '',
    style: 'Cinematic',
    duration: 10,
  });

  // Switch to dashboard upon initial login if currently on landing
  useEffect(() => {
    if (user && currentView === 'landing') {
      setCurrentView('dashboard');
    }
  }, [user]);

  // Subscribe to real-time user videos in Firestore
  useEffect(() => {
    if (!user) {
      setUserVideos([]);
      return;
    }

    const unsubscribe = subscribeUserVideos(user.uid, (videos) => {
      setUserVideos(videos);
    });

    return () => unsubscribe();
  }, [user]);

  const handleOpenAuth = (mode: 'login' | 'signup') => {
    setAuthMode(mode);
    setAuthModalOpen(true);
  };

  const handlePlayVideo = (video: VideoRecord) => {
    setActiveVideo(video);
  };

  const handleVideoCreated = (video: VideoRecord) => {
    // Add or update in list
    setUserVideos((prev) => {
      const exists = prev.some((v) => v.videoId === video.videoId);
      if (exists) {
        return prev.map((v) => (v.videoId === video.videoId ? video : v));
      }
      return [video, ...prev];
    });
  };

  const handleRegenerate = (video: VideoRecord) => {
    setCreatePrefill({
      prompt: video.prompt,
      style: video.style,
      duration: video.duration,
    });
    setCurrentView('create');
  };

  const handleUseScriptInVideo = (data: {
    prompt: string;
    style: VideoStyle;
    duration: VideoDuration;
    voiceoverText: string;
  }) => {
    setCreatePrefill({
      prompt: data.prompt,
      style: data.style,
      duration: data.duration,
    });
    setCurrentView('create');
  };

  const handleUseTemplate = (template: {
    prompt: string;
    style: VideoStyle;
    duration: VideoDuration;
    aspectRatio: AspectRatio;
  }) => {
    setCreatePrefill({
      prompt: template.prompt,
      style: template.style,
      duration: template.duration,
    });
    setCurrentView('create');
  };

  const handleVideoDeleted = (videoId: string) => {
    setUserVideos((prev) => prev.filter((v) => v.videoId !== videoId));
    if (activeVideo?.videoId === videoId) {
      setActiveVideo(null);
    }
  };

  return (
    <div className="min-h-screen bg-zinc-950 text-zinc-100 flex flex-col font-sans selection:bg-indigo-500 selection:text-white">
      {/* Top Navigation */}
      <Navbar
        currentView={currentView}
        onNavigate={setCurrentView}
        onOpenAuth={handleOpenAuth}
      />

      {/* Main Content Area */}
      <div className="flex-1 flex overflow-hidden">
        {/* Sidebar shown when authenticated or exploring app views */}
        {currentView !== 'landing' && (
          <Sidebar currentView={currentView} onNavigate={setCurrentView} />
        )}

        <main className="flex-1 overflow-y-auto bg-zinc-950 min-h-[calc(100vh-64px)] pb-16">
          {currentView === 'landing' && (
            <LandingView
              onStartFree={() => (user ? setCurrentView('create') : handleOpenAuth('signup'))}
              onNavigate={setCurrentView}
              onPlayVideo={handlePlayVideo}
            />
          )}

          {currentView === 'dashboard' && (
            <DashboardView
              videos={userVideos}
              onNavigate={setCurrentView}
              onPlayVideo={handlePlayVideo}
            />
          )}

          {currentView === 'create' && (
            <CreateVideoView
              initialPrompt={createPrefill.prompt}
              initialStyle={createPrefill.style}
              initialDuration={createPrefill.duration}
              onVideoCreated={handleVideoCreated}
              onNavigate={setCurrentView}
              onPlayVideo={handlePlayVideo}
            />
          )}

          {currentView === 'image-to-video' && (
            <ImageToVideoView
              onVideoCreated={handleVideoCreated}
              onNavigate={setCurrentView}
              onPlayVideo={handlePlayVideo}
            />
          )}

          {currentView === 'script' && (
            <ScriptGeneratorView onUseInVideoCreator={handleUseScriptInVideo} />
          )}

          {currentView === 'videos' && (
            <MyVideosView
              videos={userVideos}
              onPlayVideo={handlePlayVideo}
              onRegenerateVideo={handleRegenerate}
              onNavigate={setCurrentView}
              onVideoDeleted={handleVideoDeleted}
            />
          )}

          {currentView === 'templates' && (
            <TemplatesView onSelectTemplate={handleUseTemplate} />
          )}

          {currentView === 'pricing' && <PricingView />}

          {currentView === 'settings' && <SettingsView />}

          {currentView === 'admin' && <AdminView onPlayVideo={handlePlayVideo} />}
        </main>
      </div>

      {/* Auth Modal (Login / Signup / Forgot Password) */}
      <AuthModal
        isOpen={authModalOpen}
        onClose={() => setAuthModalOpen(false)}
        initialMode={authMode}
      />

      {/* Video Player Modal with Caption Overlays & Audio controls */}
      {activeVideo && (
        <VideoPlayerModal
          video={activeVideo}
          isOpen={!!activeVideo}
          onClose={() => setActiveVideo(null)}
          onRegenerate={handleRegenerate}
        />
      )}
    </div>
  );
}

export default function App() {
  return (
    <AuthProvider>
      <VideoForgeApp />
    </AuthProvider>
  );
}
