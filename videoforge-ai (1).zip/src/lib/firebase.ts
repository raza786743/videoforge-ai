import { initializeApp, getApps, getApp } from 'firebase/app';
import {
  getAuth,
  GoogleAuthProvider,
  signInWithPopup,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  sendPasswordResetEmail,
  signOut,
  onAuthStateChanged,
  User,
} from 'firebase/auth';
import {
  getFirestore,
  doc,
  getDoc,
  setDoc,
  updateDoc,
  collection,
  query,
  where,
  orderBy,
  onSnapshot,
  deleteDoc,
  getDocs,
  serverTimestamp,
} from 'firebase/firestore';
import firebaseConfig from '../../firebase-applet-config.json';
import { UserProfile, VideoRecord, PlanType } from '../types';

// Initialize Firebase App
const app = !getApps().length ? initializeApp(firebaseConfig) : getApp();

// Initialize Auth
export const auth = getAuth(app);
export const googleProvider = new GoogleAuthProvider();

// Initialize Firestore with custom database ID if provided
export const db = firebaseConfig.firestoreDatabaseId
  ? getFirestore(app, firebaseConfig.firestoreDatabaseId)
  : getFirestore(app);

export const ADMIN_EMAIL = 'ghulamhussain8523@gmail.com';

/**
 * Get user profile from Firestore
 */
export async function getUserProfile(uid: string): Promise<UserProfile | null> {
  try {
    const userRef = doc(db, 'users', uid);
    const snap = await getDoc(userRef);
    if (snap.exists()) {
      return snap.data() as UserProfile;
    }
    return null;
  } catch (err) {
    console.error('Error fetching user profile:', err);
    return null;
  }
}

/**
 * Create or initialize user profile in Firestore
 */
export async function createOrUpdateUserProfile(
  user: User,
  extra?: Partial<UserProfile>
): Promise<UserProfile> {
  const userRef = doc(db, 'users', user.uid);
  const snap = await getDoc(userRef);

  const isAdmin = user.email === ADMIN_EMAIL || extra?.isAdmin === true;

  if (snap.exists()) {
    const current = snap.data() as UserProfile;
    const updated: UserProfile = {
      ...current,
      name: user.displayName || current.name || 'Creator',
      email: user.email || current.email,
      photo: user.photoURL || current.photo,
      isAdmin: isAdmin || current.isAdmin,
      ...extra,
      updatedAt: Date.now(),
    };
    await setDoc(userRef, updated, { merge: true });
    return updated;
  }

  // New User - Free Trial starts with 30 credits (equivalent to 3 10-second videos)
  const newProfile: UserProfile = {
    uid: user.uid,
    name: user.displayName || 'Creator',
    email: user.email || '',
    photo: user.photoURL || '',
    plan: 'free',
    credits: 30, // 3 trial generations of 10s (10 credits each)
    free_trial_used: false,
    createdAt: Date.now(),
    updatedAt: Date.now(),
    isAdmin,
    ...extra,
  };

  await setDoc(userRef, newProfile);
  return newProfile;
}

/**
 * Deduct credits from user profile in Firestore
 */
export async function deductUserCredits(uid: string, amount: number): Promise<number> {
  const userRef = doc(db, 'users', uid);
  const snap = await getDoc(userRef);
  if (!snap.exists()) {
    throw new Error('User profile not found.');
  }
  const current = snap.data() as UserProfile;
  if (current.credits < amount) {
    throw new Error(`Insufficient credits: needed ${amount}, available ${current.credits}`);
  }
  const newCredits = Math.max(0, current.credits - amount);
  await updateDoc(userRef, {
    credits: newCredits,
    free_trial_used: newCredits === 0 && current.plan === 'free',
    updatedAt: Date.now(),
  });
  return newCredits;
}

/**
 * Refund credits to user in case of generation failure
 */
export async function refundUserCredits(uid: string, amount: number): Promise<number> {
  try {
    const userRef = doc(db, 'users', uid);
    const snap = await getDoc(userRef);
    if (!snap.exists()) return 0;
    const current = snap.data() as UserProfile;
    const newCredits = current.credits + amount;
    await updateDoc(userRef, {
      credits: newCredits,
      updatedAt: Date.now(),
    });
    return newCredits;
  } catch (err) {
    console.error('Error refunding credits:', err);
    return 0;
  }
}

/**
 * Save video generation record
 */
export async function saveVideoRecord(video: VideoRecord): Promise<void> {
  const videoRef = doc(db, 'videos', video.videoId);
  await setDoc(videoRef, video, { merge: true });
}

/**
 * Update video status
 */
export async function updateVideoStatus(
  videoId: string,
  status: VideoRecord['status'],
  extra?: Partial<VideoRecord>
): Promise<void> {
  const videoRef = doc(db, 'videos', videoId);
  await updateDoc(videoRef, {
    status,
    ...extra,
  });
}

/**
 * Subscribe to user's videos
 */
export function subscribeUserVideos(
  uid: string,
  callback: (videos: VideoRecord[]) => void
) {
  const vCol = collection(db, 'videos');
  const q = query(vCol, where('userId', '==', uid));

  return onSnapshot(
    q,
    (snapshot) => {
      const records: VideoRecord[] = [];
      snapshot.forEach((doc) => {
        records.push(doc.data() as VideoRecord);
      });
      // Sort newest first
      records.sort((a, b) => b.createdAt - a.createdAt);
      callback(records);
    },
    (error) => {
      console.error('Videos subscription error:', error);
      callback([]);
    }
  );
}

/**
 * Delete video
 */
export async function deleteVideo(videoId: string): Promise<void> {
  const videoRef = doc(db, 'videos', videoId);
  await deleteDoc(videoRef);
}

/**
 * Admin: Get all users
 */
export async function getAllUsersAdmin(): Promise<UserProfile[]> {
  try {
    const usersCol = collection(db, 'users');
    const snap = await getDocs(usersCol);
    const list: UserProfile[] = [];
    snap.forEach((d) => list.push(d.data() as UserProfile));
    return list;
  } catch (err) {
    console.error('Error getting admin users:', err);
    return [];
  }
}

/**
 * Admin: Get all videos
 */
export async function getAllVideosAdmin(): Promise<VideoRecord[]> {
  try {
    const videosCol = collection(db, 'videos');
    const snap = await getDocs(videosCol);
    const list: VideoRecord[] = [];
    snap.forEach((d) => list.push(d.data() as VideoRecord));
    list.sort((a, b) => b.createdAt - a.createdAt);
    return list;
  } catch (err) {
    console.error('Error getting admin videos:', err);
    return [];
  }
}

/**
 * Admin: Add or update credits for user
 */
export async function updateUserCreditsAdmin(uid: string, creditsToAdd: number): Promise<void> {
  const userRef = doc(db, 'users', uid);
  const snap = await getDoc(userRef);
  if (!snap.exists()) return;
  const curr = snap.data() as UserProfile;
  await updateDoc(userRef, {
    credits: (curr.credits || 0) + creditsToAdd,
    updatedAt: Date.now(),
  });
}

/**
 * Admin: Change user plan
 */
export async function updateUserPlanAdmin(uid: string, plan: PlanType): Promise<void> {
  const userRef = doc(db, 'users', uid);
  await updateDoc(userRef, {
    plan,
    updatedAt: Date.now(),
  });
}

export const getAdminUsersList = getAllUsersAdmin;
export const adminUpdateUser = async (uid: string, updates: Partial<UserProfile>) => {
  const userRef = doc(db, 'users', uid);
  await updateDoc(userRef, { ...updates, updatedAt: Date.now() });
};

