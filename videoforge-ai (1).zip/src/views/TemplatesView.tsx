import React, { useState } from 'react';
import { VideoStyle, VideoDuration, AspectRatio } from '../types';
import { Sparkles, Video, Play, ArrowRight } from 'lucide-react';

interface TemplateItem {
  id: string;
  category: string;
  title: string;
  description: string;
  prompt: string;
  style: VideoStyle;
  duration: VideoDuration;
  aspectRatio: AspectRatio;
  thumbnail: string;
}

interface TemplatesViewProps {
  onSelectTemplate: (template: {
    prompt: string;
    style: VideoStyle;
    duration: VideoDuration;
    aspectRatio: AspectRatio;
  }) => void;
}

export const TemplatesView: React.FC<TemplatesViewProps> = ({ onSelectTemplate }) => {
  const [activeCategory, setActiveCategory] = useState<string>('All');

  const templates: TemplateItem[] = [
    {
      id: 't1',
      category: 'Commercial',
      title: 'Luxury Watch Launch',
      description: 'Ultra-high end slow-motion spin of a luxury titanium wristwatch with dramatic studio rim lighting.',
      prompt: 'Cinematic commercial of a luxury black titanium wristwatch rotating slowly in midair, studio rim lighting, water droplets bouncing off sapphire crystal, 8k hyper-detailed.',
      style: 'Product Advertisement',
      duration: 10,
      aspectRatio: '16:9',
      thumbnail: 'https://images.unsplash.com/photo-1522335789203-aabd1fc54bc9?auto=format&fit=crop&w=800&q=80',
    },
    {
      id: 't2',
      category: 'Sci-Fi',
      title: 'Cyberpunk Metropolis Flight',
      description: 'Sweeping drone run through flying aerocars and holographic mega-structures in neo-Tokyo rain.',
      prompt: 'First-person flight between towering neon skyscrapers in a rain-drenched cyberpunk metropolis, flying cars passing with blue engine glow, cinematic volumetric fog.',
      style: 'Cinematic',
      duration: 15,
      aspectRatio: '16:9',
      thumbnail: 'https://images.unsplash.com/photo-1519501025264-65ba15a82390?auto=format&fit=crop&w=800&q=80',
    },
    {
      id: 't3',
      category: 'Social Media',
      title: 'Viral Motivation Reel',
      description: 'High-contrast silhouette of an athlete running along an ocean cliffside at red sunrise.',
      prompt: 'Dramatic silhouette of a solitary runner sprinting along an ocean mountain cliff edge at vibrant sunrise, golden sunlight rays, high-energy cinematic camera track.',
      style: 'Cinematic',
      duration: 10,
      aspectRatio: '9:16',
      thumbnail: 'https://images.unsplash.com/photo-1502680390469-be75c86b636f?auto=format&fit=crop&w=800&q=80',
    },
    {
      id: 't4',
      category: 'Documentary',
      title: 'Deep Ocean Bioluminescence',
      description: 'Glowing deep sea jellyfish floating gracefully in pitch-black abyss with gentle particle illumination.',
      prompt: 'National Geographic documentary 4k footage of an ethereal glowing bioluminescent jellyfish floating through the midnight deep sea trench, shimmering electric blue and purple.',
      style: 'Documentary',
      duration: 10,
      aspectRatio: '16:9',
      thumbnail: 'https://images.unsplash.com/photo-1544551763-46a013bb70d5?auto=format&fit=crop&w=800&q=80',
    },
    {
      id: 't5',
      category: 'Anime',
      title: 'Neo-Tokyo Anime Skyline',
      description: 'Shinkai-style sunset clouds over futuristic rail tracks and cherry blossom petals.',
      prompt: 'Masterpiece anime aesthetic in the style of Makoto Shinkai, lush pink sunset sky, high-speed bullet train crossing river, cherry blossom petals swirling in gentle breeze.',
      style: 'Anime',
      duration: 10,
      aspectRatio: '16:9',
      thumbnail: 'https://images.unsplash.com/photo-1579783902614-a3fb3927b675?auto=format&fit=crop&w=800&q=80',
    },
    {
      id: 't6',
      category: '3D World',
      title: 'Magical Floating Islands',
      description: 'Pixar/Unreal 3D render of vibrant mossy islands floating in pastel clouds with waterfalls.',
      prompt: 'Whimsical 3D animation of green floating islands with crystal waterfalls cascading into soft pastel clouds, glowing lanterns floating into golden sunset, stylized fantasy landscape.',
      style: '3D Animation',
      duration: 10,
      aspectRatio: '1:1',
      thumbnail: 'https://images.unsplash.com/photo-1518709268805-4e9042af9f23?auto=format&fit=crop&w=800&q=80',
    },
  ];

  const categories = ['All', 'Commercial', 'Sci-Fi', 'Social Media', 'Documentary', 'Anime', '3D World'];

  const filtered = activeCategory === 'All'
    ? templates
    : templates.filter((t) => t.category === activeCategory);

  return (
    <div id="templates-page" className="p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto space-y-6">
      <div>
        <div className="flex items-center gap-2 mb-1">
          <span className="text-xs uppercase font-mono tracking-wider text-indigo-400">Library</span>
          <span className="text-[10px] uppercase font-bold px-2 py-0.5 rounded bg-zinc-800 text-zinc-300 border border-zinc-700">
            Viral Blueprints
          </span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-bold text-white tracking-tight">
          Video Production Templates
        </h1>
        <p className="text-xs sm:text-sm text-zinc-400 mt-1">
          Jumpstart your video creation with pre-engineered cinematic prompt architecture.
        </p>
      </div>

      {/* Category Pills */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1">
        {categories.map((cat) => (
          <button
            key={cat}
            onClick={() => setActiveCategory(cat)}
            className={`px-3.5 py-1.5 rounded-full text-xs font-medium transition-colors whitespace-nowrap ${
              activeCategory === cat
                ? 'bg-indigo-600 text-white font-semibold shadow-sm'
                : 'bg-zinc-900 text-zinc-400 hover:text-white border border-zinc-800'
            }`}
          >
            {cat}
          </button>
        ))}
      </div>

      {/* Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
        {filtered.map((item) => (
          <div
            key={item.id}
            id={`template-card-${item.id}`}
            className="group bg-zinc-900/60 border border-zinc-800 rounded-2xl overflow-hidden hover:border-zinc-700 transition-all flex flex-col justify-between shadow-lg"
          >
            <div className="relative aspect-video bg-zinc-950 overflow-hidden">
              <img
                src={item.thumbnail}
                alt={item.title}
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-zinc-950 via-zinc-950/20 to-transparent" />

              <div className="absolute top-3 left-3 flex items-center gap-1.5">
                <span className="px-2 py-0.5 text-[10px] font-mono font-semibold rounded bg-black/70 text-white border border-white/10 backdrop-blur-xs">
                  {item.aspectRatio}
                </span>
                <span className="px-2 py-0.5 text-[10px] rounded bg-indigo-950/80 text-indigo-300 border border-indigo-500/30">
                  {item.style}
                </span>
              </div>

              <div className="absolute bottom-3 right-3">
                <span className="px-2 py-0.5 text-[10px] font-mono rounded bg-black/70 text-zinc-300 backdrop-blur-xs">
                  {item.duration}s
                </span>
              </div>
            </div>

            <div className="p-4 flex-1 flex flex-col justify-between">
              <div>
                <span className="text-[10px] font-mono uppercase text-indigo-400 font-bold">
                  {item.category}
                </span>
                <h3 className="text-sm font-bold text-white mt-0.5 mb-1.5">{item.title}</h3>
                <p className="text-xs text-zinc-400 line-clamp-2 leading-relaxed">
                  {item.description}
                </p>
              </div>

              <button
                onClick={() =>
                  onSelectTemplate({
                    prompt: item.prompt,
                    style: item.style,
                    duration: item.duration,
                    aspectRatio: item.aspectRatio,
                  })
                }
                className="mt-4 w-full py-2 px-3 bg-zinc-800 hover:bg-indigo-600 text-zinc-200 hover:text-white rounded-xl text-xs font-semibold flex items-center justify-center gap-1.5 transition-all cursor-pointer"
              >
                <span>Use Template</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
