import React, { useState } from 'react';
import {
  Sparkles,
  Video,
  Image as ImageIcon,
  Mic,
  Subtitles,
  Layers,
  Flame,
  ArrowRight,
  Play,
  CheckCircle2,
  Zap,
  Star,
  Film,
  Download,
} from 'lucide-react';
import { AppView, VideoRecord } from '../types';

interface LandingViewProps {
  onStartFree: () => void;
  onNavigate: (view: AppView) => void;
  onPlayVideo: (video: VideoRecord) => void;
}

export const LandingView: React.FC<LandingViewProps> = ({
  onStartFree,
  onNavigate,
  onPlayVideo,
}) => {
  const [activeTab, setActiveTab] = useState<'text' | 'image' | 'voice' | 'captions'>('text');

  // High quality sample showcase items
  const demoVideos: VideoRecord[] = [
    {
      videoId: 'demo_1',
      userId: 'demo',
      prompt: 'Cyberpunk neo-Tokyo skyline with flying aerocars and rain reflections on neon glass',
      duration: 10,
      aspectRatio: '16:9',
      style: 'Cinematic',
      status: 'completed',
      videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4',
      thumbnailUrl: 'https://images.unsplash.com/photo-1519501025264-65ba15a82390?auto=format&fit=crop&w=800&q=80',
      creditsUsed: 10,
      createdAt: Date.now() - 3600000,
      captions: [
        { id: 'c1', start: 0, end: 3, text: 'The skyline pulses with electric neon.' },
        { id: 'c2', start: 3, end: 6, text: 'Flying transports cut through the midnight drizzle.' },
        { id: 'c3', start: 6, end: 10, text: 'Welcome to the metropolis of tomorrow.' },
      ],
    },
    {
      videoId: 'demo_2',
      userId: 'demo',
      prompt: 'Cinematic documentary exploration of underwater coral reefs and bioluminescent manta ray',
      duration: 10,
      aspectRatio: '9:16',
      style: 'Documentary',
      status: 'completed',
      videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4',
      thumbnailUrl: 'https://images.unsplash.com/photo-1544551763-46a013bb70d5?auto=format&fit=crop&w=800&q=80',
      creditsUsed: 10,
      createdAt: Date.now() - 7200000,
      captions: [
        { id: 'c1', start: 0, end: 3.5, text: 'Beneath the ocean swells lies an alien empire.' },
        { id: 'c2', start: 3.5, end: 7, text: 'Colonies of coral generate rhythmic light pulses.' },
        { id: 'c3', start: 7, end: 10, text: 'A creature of pure luminescence emerges.' },
      ],
    },
    {
      videoId: 'demo_3',
      userId: 'demo',
      prompt: 'High-end luxury wristwatch advertisement spinning in slow motion with studio volumetric light',
      duration: 5,
      aspectRatio: '1:1',
      style: 'Product Advertisement',
      status: 'completed',
      videoUrl: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4',
      thumbnailUrl: 'https://images.unsplash.com/photo-1522335789203-aabd1fc54bc9?auto=format&fit=crop&w=800&q=80',
      creditsUsed: 5,
      createdAt: Date.now() - 10800000,
      captions: [
        { id: 'c1', start: 0, end: 2.5, text: 'Master craftsmanship redefined.' },
        { id: 'c2', start: 2.5, end: 5, text: 'Engineered for absolute precision.' },
      ],
    },
  ];

  const features = [
    {
      icon: <Video className="w-5 h-5 text-indigo-400" />,
      title: 'Text to Video',
      description: 'Describe any vision in natural language. Our neural video engine orchestrates motion, camera depth, and cinema lighting.',
    },
    {
      icon: <ImageIcon className="w-5 h-5 text-cyan-400" />,
      title: 'Image to Video',
      description: 'Upload any static JPG or PNG concept art, product photo, or portrait and breathe photorealistic cinematic motion into it.',
    },
    {
      icon: <Mic className="w-5 h-5 text-emerald-400" />,
      title: 'AI Voice-Over',
      description: 'Natural human voice narration across 12+ styles and multiple languages, perfectly matched to scene beats.',
    },
    {
      icon: <Subtitles className="w-5 h-5 text-amber-400" />,
      title: 'Auto Captions',
      description: 'Generate word-by-word viral subtitles with TikTok & Reels kinetic styling, custom positioning, and high readability.',
    },
    {
      icon: <Layers className="w-5 h-5 text-violet-400" />,
      title: 'Viral Templates',
      description: 'Start in seconds with pre-engineered high-retention templates tailored for ads, TikTok, YouTube Shorts, and trailers.',
    },
    {
      icon: <Download className="w-5 h-5 text-rose-400" />,
      title: 'HD Export & Download',
      description: 'Render up to 1080p full high-definition video files with zero watermarks on paid plans. Instant local downloads.',
    },
  ];

  return (
    <div id="landing-page" className="w-full bg-zinc-950 text-zinc-100 overflow-x-hidden">
      {/* Hero Section */}
      <section className="relative pt-16 pb-20 px-4 sm:px-6 lg:px-8 max-w-6xl mx-auto text-center">
        {/* Ambient glow accent */}
        <div className="absolute top-10 left-1/2 -translate-x-1/2 w-96 h-96 bg-indigo-600/15 blur-[120px] pointer-events-none rounded-full" />

        <div className="inline-flex items-center gap-2 px-3 py-1.5 rounded-full bg-indigo-950/60 border border-indigo-500/30 text-indigo-300 text-xs font-medium mb-6 animate-in fade-in">
          <Sparkles className="w-3.5 h-3.5 text-indigo-400" />
          <span>Next-Gen Video Synthesis & Script Studio</span>
        </div>

        <h1 className="text-4xl sm:text-5xl lg:text-6xl font-black tracking-tight text-white max-w-4xl mx-auto leading-tight">
          Create Stunning <span className="text-transparent bg-clip-text bg-gradient-to-r from-indigo-400 via-violet-400 to-indigo-300">AI Videos</span> in Seconds
        </h1>

        <p className="mt-6 text-base sm:text-lg text-zinc-400 max-w-2xl mx-auto leading-relaxed">
          Turn your ideas, scripts and images into professional AI videos. Powered by state-of-the-art video models, synchronized AI voices, and animated captions.
        </p>

        {/* CTA Buttons */}
        <div className="mt-8 flex flex-col sm:flex-row items-center justify-center gap-3.5">
          <button
            id="hero-start-free-btn"
            onClick={onStartFree}
            className="w-full sm:w-auto px-7 py-3.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-sm font-bold transition-all shadow-xl shadow-indigo-600/30 flex items-center justify-center gap-2 cursor-pointer"
          >
            <span>Start Free (3 Free Videos)</span>
            <ArrowRight className="w-4 h-4" />
          </button>

          <button
            id="hero-create-video-btn"
            onClick={() => onNavigate('create')}
            className="w-full sm:w-auto px-7 py-3.5 bg-zinc-900 hover:bg-zinc-800 border border-zinc-800 hover:border-zinc-700 text-zinc-200 rounded-xl text-sm font-semibold transition-all flex items-center justify-center gap-2 cursor-pointer"
          >
            <Video className="w-4 h-4 text-indigo-400" />
            <span>Create Video</span>
          </button>
        </div>

        {/* Value props bullets */}
        <div className="mt-10 flex flex-wrap items-center justify-center gap-6 text-xs text-zinc-400">
          <div className="flex items-center gap-1.5">
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            <span>No credit card required</span>
          </div>
          <div className="flex items-center gap-1.5">
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            <span>30 Free starter credits</span>
          </div>
          <div className="flex items-center gap-1.5">
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            <span>Real downloadable MP4s</span>
          </div>
        </div>
      </section>

      {/* Live Sample Showcase Gallery */}
      <section className="py-12 px-4 sm:px-6 lg:px-8 max-w-6xl mx-auto border-t border-zinc-900">
        <div className="flex flex-col sm:flex-row sm:items-end justify-between mb-8 gap-4">
          <div>
            <span className="text-xs uppercase font-mono tracking-widest text-indigo-400">Showcase</span>
            <h2 className="text-2xl font-bold text-white tracking-tight mt-1">Generated with VideoForge AI</h2>
            <p className="text-xs text-zinc-400 mt-1">Click any sample below to open the interactive player and caption controls.</p>
          </div>
          <button
            onClick={() => onNavigate('templates')}
            className="text-xs font-medium text-indigo-400 hover:text-indigo-300 flex items-center gap-1 self-start sm:self-auto"
          >
            Browse all templates <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          {demoVideos.map((video) => (
            <div
              key={video.videoId}
              id={`showcase-card-${video.videoId}`}
              onClick={() => onPlayVideo(video)}
              className="group relative bg-zinc-900/60 border border-zinc-800/80 rounded-2xl overflow-hidden hover:border-zinc-700 transition-all cursor-pointer shadow-lg hover:shadow-indigo-950/20"
            >
              <div className="relative aspect-video bg-zinc-950 overflow-hidden">
                <img
                  src={video.thumbnailUrl}
                  alt={video.prompt}
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-zinc-950 via-zinc-950/20 to-transparent" />

                {/* Play icon overlay */}
                <div className="absolute inset-0 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity bg-black/40 backdrop-blur-xs">
                  <div className="w-12 h-12 rounded-full bg-indigo-600 text-white flex items-center justify-center shadow-lg transform group-hover:scale-110 transition-transform">
                    <Play className="w-5 h-5 fill-white ml-0.5" />
                  </div>
                </div>

                <div className="absolute top-3 left-3 flex items-center gap-1.5">
                  <span className="px-2 py-0.5 text-[10px] font-mono font-semibold rounded bg-black/70 text-white backdrop-blur-xs border border-white/10">
                    {video.aspectRatio}
                  </span>
                  <span className="px-2 py-0.5 text-[10px] font-semibold rounded bg-indigo-950/80 text-indigo-300 border border-indigo-500/30">
                    {video.style}
                  </span>
                </div>

                <div className="absolute bottom-3 right-3">
                  <span className="px-2 py-0.5 text-[10px] font-mono rounded bg-black/70 text-zinc-300 backdrop-blur-xs">
                    {video.duration}s
                  </span>
                </div>
              </div>

              <div className="p-4">
                <p className="text-xs text-zinc-200 line-clamp-2 leading-relaxed font-medium">
                  "{video.prompt}"
                </p>
                <div className="mt-3 pt-3 border-t border-zinc-800/60 flex items-center justify-between text-[11px] text-zinc-400">
                  <span>Auto Captions Enabled</span>
                  <span className="text-indigo-400 font-semibold flex items-center gap-1">
                    <Play className="w-3 h-3" /> Preview
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* Feature Grid Section */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 max-w-6xl mx-auto">
        <div className="text-center max-w-2xl mx-auto mb-12">
          <span className="text-xs uppercase font-mono tracking-widest text-indigo-400">Capabilities</span>
          <h2 className="text-3xl font-bold text-white tracking-tight mt-1">
            Engineered for Creators, Marketers & Studios
          </h2>
          <p className="text-sm text-zinc-400 mt-2">
            Every layer from prompt interpretation to script writing, voiceover sync, and rendering runs through server-side pipelines.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {features.map((feature, i) => (
            <div
              key={i}
              className="p-6 rounded-2xl bg-zinc-900/40 border border-zinc-800/80 hover:border-zinc-700/80 transition-all hover:bg-zinc-900/70 shadow-sm"
            >
              <div className="w-10 h-10 rounded-xl bg-zinc-800/90 flex items-center justify-center mb-4">
                {feature.icon}
              </div>
              <h3 className="text-base font-semibold text-white mb-2">{feature.title}</h3>
              <p className="text-xs text-zinc-400 leading-relaxed">{feature.description}</p>
            </div>
          ))}
        </div>
      </section>

      {/* Pricing Teaser Section */}
      <section className="py-16 px-4 sm:px-6 lg:px-8 max-w-6xl mx-auto border-t border-zinc-900">
        <div className="text-center max-w-2xl mx-auto mb-12">
          <span className="text-xs uppercase font-mono tracking-widest text-indigo-400">Plans & Pricing</span>
          <h2 className="text-3xl font-bold text-white tracking-tight mt-1">
            Transparent Credit-Based Generation
          </h2>
          <p className="text-sm text-zinc-400 mt-2">
            Start completely free with 3 trial videos, then choose a tier that matches your production rhythm.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          {/* Free Tier */}
          <div className="p-5 rounded-2xl bg-zinc-900/40 border border-zinc-800 flex flex-col justify-between">
            <div>
              <span className="text-[11px] font-mono text-zinc-400 uppercase font-semibold">Free Trial</span>
              <div className="mt-2 flex items-baseline gap-1">
                <span className="text-2xl font-bold text-white">$0</span>
                <span className="text-xs text-zinc-400">/ forever</span>
              </div>
              <p className="text-xs text-zinc-400 mt-2">Perfect for trying out the video generator.</p>
              <ul className="mt-4 space-y-2 text-xs text-zinc-300">
                <li className="flex items-center gap-2"><CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" /> 3 trial generations (30 cr)</li>
                <li className="flex items-center gap-2"><CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" /> Max 10-second videos</li>
                <li className="flex items-center gap-2"><CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" /> 720p with watermark</li>
              </ul>
            </div>
            <button
              onClick={onStartFree}
              className="mt-6 w-full py-2 bg-zinc-800 hover:bg-zinc-700 text-zinc-200 rounded-xl text-xs font-semibold transition-colors"
            >
              Get Started Free
            </button>
          </div>

          {/* Starter Tier */}
          <div className="p-5 rounded-2xl bg-zinc-900/60 border border-zinc-800 flex flex-col justify-between">
            <div>
              <span className="text-[11px] font-mono text-blue-400 uppercase font-semibold">Starter</span>
              <div className="mt-2 flex items-baseline gap-1">
                <span className="text-2xl font-bold text-white">$5</span>
                <span className="text-xs text-zinc-400">/ month</span>
              </div>
              <p className="text-xs text-zinc-400 mt-2">Essential creator tools with full 1080p output.</p>
              <ul className="mt-4 space-y-2 text-xs text-zinc-300">
                <li className="flex items-center gap-2"><CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" /> 100 monthly credits</li>
                <li className="flex items-center gap-2"><CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" /> 1080p HD rendering</li>
                <li className="flex items-center gap-2"><CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" /> No watermark</li>
                <li className="flex items-center gap-2"><CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" /> AI voice & auto captions</li>
              </ul>
            </div>
            <button
              onClick={() => onNavigate('pricing')}
              className="mt-6 w-full py-2 bg-blue-600 hover:bg-blue-500 text-white rounded-xl text-xs font-semibold transition-colors"
            >
              Choose Starter
            </button>
          </div>

          {/* Pro Tier (Featured) */}
          <div className="relative p-5 rounded-2xl bg-gradient-to-b from-indigo-950/40 via-zinc-900/90 to-zinc-900 border-2 border-indigo-500/70 flex flex-col justify-between shadow-xl shadow-indigo-950/30">
            <div className="absolute -top-3 left-1/2 -translate-x-1/2 px-2.5 py-0.5 rounded-full bg-indigo-600 text-white text-[10px] font-bold uppercase tracking-wider">
              Most Popular
            </div>
            <div>
              <span className="text-[11px] font-mono text-indigo-400 uppercase font-semibold">Pro</span>
              <div className="mt-2 flex items-baseline gap-1">
                <span className="text-2xl font-bold text-white">$12</span>
                <span className="text-xs text-zinc-400">/ month</span>
              </div>
              <p className="text-xs text-zinc-400 mt-2">High-volume production with priority GPU queue.</p>
              <ul className="mt-4 space-y-2 text-xs text-zinc-300">
                <li className="flex items-center gap-2"><CheckCircle2 className="w-3.5 h-3.5 text-indigo-400" /> 300 monthly credits</li>
                <li className="flex items-center gap-2"><CheckCircle2 className="w-3.5 h-3.5 text-indigo-400" /> Priority generation queue</li>
                <li className="flex items-center gap-2"><CheckCircle2 className="w-3.5 h-3.5 text-indigo-400" /> Premium voice models</li>
                <li className="flex items-center gap-2"><CheckCircle2 className="w-3.5 h-3.5 text-indigo-400" /> Up to 30s video lengths</li>
              </ul>
            </div>
            <button
              onClick={() => onNavigate('pricing')}
              className="mt-6 w-full py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-bold transition-all shadow-md shadow-indigo-600/30"
            >
              Choose Pro
            </button>
          </div>

          {/* Business Tier */}
          <div className="p-5 rounded-2xl bg-zinc-900/60 border border-zinc-800 flex flex-col justify-between">
            <div>
              <span className="text-[11px] font-mono text-purple-400 uppercase font-semibold">Business</span>
              <div className="mt-2 flex items-baseline gap-1">
                <span className="text-2xl font-bold text-white">$25</span>
                <span className="text-xs text-zinc-400">/ month</span>
              </div>
              <p className="text-xs text-zinc-400 mt-2">Unlimited studio scale with dedicated compute.</p>
              <ul className="mt-4 space-y-2 text-xs text-zinc-300">
                <li className="flex items-center gap-2"><CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" /> 800 monthly credits</li>
                <li className="flex items-center gap-2"><CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" /> Ultra-fast priority line</li>
                <li className="flex items-center gap-2"><CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" /> All premium templates</li>
                <li className="flex items-center gap-2"><CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" /> Batch job API support</li>
              </ul>
            </div>
            <button
              onClick={() => onNavigate('pricing')}
              className="mt-6 w-full py-2 bg-zinc-800 hover:bg-zinc-700 text-zinc-200 rounded-xl text-xs font-semibold transition-colors"
            >
              Choose Business
            </button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-12 px-4 sm:px-6 lg:px-8 border-t border-zinc-900 text-xs text-zinc-500 max-w-6xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4">
        <div className="flex items-center gap-2">
          <div className="w-6 h-6 rounded-lg bg-indigo-600 flex items-center justify-center text-white">
            <Sparkles className="w-3 h-3" />
          </div>
          <span className="text-zinc-300 font-semibold">VideoForge AI</span>
          <span>© 2026. All rights reserved.</span>
        </div>
        <div className="flex items-center gap-6">
          <button onClick={() => onNavigate('templates')} className="hover:text-zinc-300 transition-colors">
            Templates
          </button>
          <button onClick={() => onNavigate('pricing')} className="hover:text-zinc-300 transition-colors">
            Pricing
          </button>
          <button onClick={() => onNavigate('create')} className="hover:text-zinc-300 transition-colors">
            Video Engine
          </button>
        </div>
      </footer>
    </div>
  );
};
