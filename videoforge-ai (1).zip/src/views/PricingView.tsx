import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import { PlanType } from '../types';
import {
  CheckCircle2,
  Zap,
  ShieldCheck,
  Coins,
  ArrowRight,
  Loader2,
  AlertCircle,
  ExternalLink,
} from 'lucide-react';

export const PricingView: React.FC = () => {
  const { user, profile, refreshProfile } = useAuth();
  const [loadingPlan, setLoadingPlan] = useState<string | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [successNotice, setSuccessNotice] = useState<string | null>(null);

  const plans: {
    id: PlanType;
    name: string;
    price: number;
    period: string;
    credits: number;
    description: string;
    popular?: boolean;
    features: string[];
  }[] = [
    {
      id: 'free',
      name: 'Free Trial',
      price: 0,
      period: 'forever',
      credits: 30,
      description: 'Test out our neural video engine with starter credits.',
      features: [
        '3 trial video generations (30 credits)',
        'Up to 10 seconds per video',
        '720p standard resolution',
        'VideoForge watermark',
        'Standard generation speed',
      ],
    },
    {
      id: 'starter',
      name: 'Starter',
      price: 5,
      period: 'month',
      credits: 100,
      description: 'Ideal for independent content creators & influencers.',
      features: [
        '100 monthly credits',
        'Up to 15 seconds per video',
        'Full 1080p HD rendering',
        'No watermark',
        'AI voice-over & auto captions',
        'Commercial usage rights',
      ],
    },
    {
      id: 'pro',
      name: 'Pro',
      price: 12,
      period: 'month',
      credits: 300,
      popular: true,
      description: 'Maximum power for serious video creators & marketers.',
      features: [
        '300 monthly credits',
        'Up to 30 seconds per video',
        'Priority GPU generation line',
        'No watermark',
        'Premium voice models & 7 languages',
        'Full HD 1080p 60fps export',
        'Priority support',
      ],
    },
    {
      id: 'business',
      name: 'Business',
      price: 25,
      period: 'month',
      credits: 800,
      description: 'Dedicated compute capacity for agencies and studios.',
      features: [
        '800 monthly credits',
        'Up to 30 seconds per video',
        'Ultra-fast priority queue',
        'All styles & premium templates',
        'Full HD commercial licensing',
        'API & Batch generation access',
        'Dedicated account manager',
      ],
    },
  ];

  const creditPacks = [
    { credits: 50, price: 3, label: 'Micro Pack', desc: '5 full 10s video generations' },
    { credits: 150, price: 7, label: 'Creator Pack', desc: '15 full 10s video generations' },
    { credits: 400, price: 15, label: 'Studio Pack', desc: '40 full 10s video generations' },
  ];

  const handleSubscribe = async (planId: PlanType) => {
    setError(null);
    setSuccessNotice(null);

    if (!user) {
      setError('Please sign in first to choose or upgrade a plan.');
      return;
    }

    if (planId === profile?.plan) {
      setError(`You are already subscribed to the ${planId} plan.`);
      return;
    }

    setLoadingPlan(planId);
    try {
      const response = await fetch('/api/stripe/checkout', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          plan: planId,
          userId: user.uid,
          userEmail: user.email,
        }),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || 'Failed to initiate checkout.');
      }

      if (data.url) {
        // If simulated or test URL, we open or notify
        if (data.url.startsWith('http')) {
          window.location.href = data.url;
        } else {
          setSuccessNotice(data.message || 'Subscription processed successfully!');
          await refreshProfile();
        }
      }
    } catch (err: any) {
      console.error('Checkout error:', err);
      setError(err.message || 'Payment initiation failed.');
    } finally {
      setLoadingPlan(null);
    }
  };

  const handleBuyCredits = async (amount: number, price: number) => {
    setError(null);
    setSuccessNotice(null);

    if (!user) {
      setError('Please sign in first to purchase credit top-ups.');
      return;
    }

    setLoadingPlan(`credits_${amount}`);
    try {
      const response = await fetch('/api/stripe/topup', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          credits: amount,
          price,
          userId: user.uid,
          userEmail: user.email,
        }),
      });

      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.error || 'Topup checkout failed.');
      }

      setSuccessNotice(`Successfully purchased ${amount} credits!`);
      await refreshProfile();
    } catch (err: any) {
      console.error('Top-up error:', err);
      setError(err.message || 'Failed to process credit purchase.');
    } finally {
      setLoadingPlan(null);
    }
  };

  return (
    <div id="pricing-page" className="p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto space-y-12">
      {/* Header */}
      <div className="text-center max-w-2xl mx-auto">
        <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-indigo-950/60 border border-indigo-500/30 text-indigo-300 text-xs font-medium mb-3">
          <Zap className="w-3.5 h-3.5 text-indigo-400" />
          <span>Flexible Creator Pricing</span>
        </div>
        <h1 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight">
          Choose the Perfect Video Plan
        </h1>
        <p className="text-sm text-zinc-400 mt-2">
          Unlock 1080p full HD rendering, watermark removal, priority queues, and longer video limits.
        </p>
      </div>

      {/* Error & Success Messages */}
      {error && (
        <div className="p-4 rounded-xl bg-rose-950/80 border border-rose-800 text-rose-200 text-xs flex items-start gap-3 max-w-2xl mx-auto animate-in fade-in">
          <AlertCircle className="w-5 h-5 text-rose-400 shrink-0 mt-0.5" />
          <div className="flex-1">
            <p className="font-semibold text-rose-100">Notice</p>
            <p className="mt-1 leading-relaxed">{error}</p>
          </div>
        </div>
      )}

      {successNotice && (
        <div className="p-4 rounded-xl bg-emerald-950/80 border border-emerald-800 text-emerald-200 text-xs flex items-start gap-3 max-w-2xl mx-auto animate-in fade-in">
          <CheckCircle2 className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
          <div className="flex-1">
            <p className="font-semibold text-emerald-100">Success</p>
            <p className="mt-1 leading-relaxed">{successNotice}</p>
          </div>
        </div>
      )}

      {/* Pricing Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {plans.map((plan) => {
          const isCurrent = profile?.plan === plan.id;
          return (
            <div
              key={plan.id}
              id={`pricing-card-${plan.id}`}
              className={`relative rounded-3xl p-6 flex flex-col justify-between transition-all ${
                plan.popular
                  ? 'bg-gradient-to-b from-indigo-950/50 via-zinc-900 to-zinc-900 border-2 border-indigo-500/80 shadow-xl shadow-indigo-950/30'
                  : 'bg-zinc-900/60 border border-zinc-800 hover:border-zinc-700'
              }`}
            >
              {plan.popular && (
                <div className="absolute -top-3 left-1/2 -translate-x-1/2 px-3 py-0.5 rounded-full bg-indigo-600 text-white text-[10px] font-bold uppercase tracking-wider shadow-md">
                  Most Popular
                </div>
              )}

              <div>
                <div className="flex items-center justify-between">
                  <h3 className="text-base font-bold text-white">{plan.name}</h3>
                  {isCurrent && (
                    <span className="px-2 py-0.5 text-[10px] font-mono font-bold rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                      Active Plan
                    </span>
                  )}
                </div>

                <div className="mt-3 flex items-baseline gap-1">
                  <span className="text-3xl font-extrabold text-white">${plan.price}</span>
                  <span className="text-xs text-zinc-400">/{plan.period}</span>
                </div>

                <p className="text-xs text-zinc-400 mt-2 min-h-[36px]">{plan.description}</p>

                <div className="mt-4 pt-4 border-t border-zinc-800/80 space-y-2.5">
                  {plan.features.map((feature, idx) => (
                    <div key={idx} className="flex items-start gap-2 text-xs text-zinc-300">
                      <CheckCircle2
                        className={`w-3.5 h-3.5 shrink-0 mt-0.5 ${
                          plan.popular ? 'text-indigo-400' : 'text-emerald-400'
                        }`}
                      />
                      <span>{feature}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="mt-6 pt-4 border-t border-zinc-800/80">
                <button
                  id={`select-plan-${plan.id}-btn`}
                  disabled={isCurrent || loadingPlan === plan.id}
                  onClick={() => handleSubscribe(plan.id)}
                  className={`w-full py-2.5 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-2 cursor-pointer ${
                    isCurrent
                      ? 'bg-zinc-800 text-zinc-500 cursor-not-allowed'
                      : plan.popular
                      ? 'bg-indigo-600 hover:bg-indigo-500 text-white shadow-lg shadow-indigo-600/30'
                      : 'bg-zinc-800 hover:bg-zinc-700 text-zinc-200'
                  }`}
                >
                  {loadingPlan === plan.id ? (
                    <>
                      <Loader2 className="w-3.5 h-3.5 animate-spin" />
                      <span>Processing...</span>
                    </>
                  ) : isCurrent ? (
                    <span>Current Plan</span>
                  ) : (
                    <>
                      <span>{plan.price === 0 ? 'Downgrade' : `Get ${plan.name}`}</span>
                      <ArrowRight className="w-3.5 h-3.5" />
                    </>
                  )}
                </button>
              </div>
            </div>
          );
        })}
      </div>

      {/* Credit Top-Up Section */}
      <div className="mt-12 p-8 rounded-3xl bg-zinc-900/50 border border-zinc-800">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 mb-6">
          <div>
            <div className="flex items-center gap-2 mb-1 text-amber-400 text-xs font-semibold">
              <Coins className="w-4 h-4" />
              <span>Instant Refill</span>
            </div>
            <h2 className="text-xl font-bold text-white">Need Extra Credits?</h2>
            <p className="text-xs text-zinc-400 mt-0.5">
              Top up your balance on demand without changing your monthly subscription plan.
            </p>
          </div>

          <div className="text-right">
            <span className="text-xs text-zinc-400">Current Balance:</span>
            <div className="text-xl font-mono font-bold text-amber-400">
              {profile?.credits ?? 0} Credits
            </div>
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          {creditPacks.map((pack) => (
            <div
              key={pack.credits}
              className="p-5 rounded-2xl bg-zinc-900 border border-zinc-800 hover:border-zinc-700 flex flex-col justify-between"
            >
              <div>
                <span className="text-[10px] uppercase font-mono text-zinc-400 font-semibold">
                  {pack.label}
                </span>
                <div className="mt-2 flex items-baseline gap-2">
                  <span className="text-2xl font-black text-white font-mono">{pack.credits}</span>
                  <span className="text-xs text-zinc-500">credits</span>
                </div>
                <p className="text-xs text-zinc-400 mt-1">{pack.desc}</p>
              </div>

              <button
                disabled={loadingPlan === `credits_${pack.credits}`}
                onClick={() => handleBuyCredits(pack.credits, pack.price)}
                className="mt-5 w-full py-2 bg-zinc-800 hover:bg-amber-600 hover:text-black text-zinc-200 rounded-xl text-xs font-bold transition-all flex items-center justify-center gap-1.5 cursor-pointer"
              >
                {loadingPlan === `credits_${pack.credits}` ? (
                  <Loader2 className="w-3.5 h-3.5 animate-spin" />
                ) : (
                  <>
                    <Coins className="w-3.5 h-3.5" />
                    <span>Buy for ${pack.price}</span>
                  </>
                )}
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
