import React, { useState, useRef } from 'react';
import { useAuth } from '../context/AuthContext';
import { VideoDuration, AspectRatio, VideoRecord, AppView } from '../types';
import { saveVideoRecord, deductUserCredits, refundUserCredits } from '../lib/firebase';
import {
  Upload,
  Image as ImageIcon,
  Sparkles,
  Video,
  Clock,
  Ratio,
  AlertCircle,
  Loader2,
  CheckCircle2,
  Coins,
  Play,
  X,
} from 'lucide-react';

interface ImageToVideoViewProps {
  onVideoCreated: (video: VideoRecord) => void;
  onNavigate: (view: AppView) => void;
  onPlayVideo: (video: VideoRecord) => void;
}

export const ImageToVideoView: React.FC<ImageToVideoViewProps> = ({
  onVideoCreated,
  onNavigate,
  onPlayVideo,
}) => {
  const { user, profile, refreshProfile, deductLocalCredits, refundLocalCredits } = useAuth();

  const fileInputRef = useRef<HTMLInputElement>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  const [imageName, setImageName] = useState<string>('');
  const [prompt, setPrompt] = useState('');
  const [duration, setDuration] = useState<VideoDuration>(5);
  const [aspectRatio, setAspectRatio] = useState<AspectRatio>('16:9');
  const [motionIntensity, setMotionIntensity] = useState<'subtle' | 'moderate' | 'dynamic'>('moderate');

  const [isSubmitting, setIsSubmitting] = useState(false);
  const [activeJob, setActiveJob] = useState<VideoRecord | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const durationCosts: Record<VideoDuration, number> = {
    5: 5,
    10: 10,
    15: 15,
    30: 30,
  };

  const currentCost = durationCosts[duration];
  const userCredits = profile?.credits ?? 0;
  const isFreePlan = profile?.plan === 'free';
  const isDurationForbiddenOnFree = isFreePlan && duration > 10;

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      processFile(file);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    const file = e.dataTransfer.files?.[0];
    if (file) {
      processFile(file);
    }
  };

  const processFile = (file: File) => {
    const validTypes = ['image/jpeg', 'image/png', 'image/webp'];
    if (!validTypes.includes(file.type)) {
      setErrorMessage('Please upload a valid JPG, PNG, or WEBP image.');
      return;
    }
    if (file.size > 10 * 1024 * 1024) {
      setErrorMessage('Image size must be under 10MB.');
      return;
    }

    setErrorMessage(null);
    setImageName(file.name);
    const reader = new FileReader();
    reader.onload = (ev) => {
      setImagePreview(ev.target?.result as string);
    };
    reader.readAsDataURL(file);
  };

  const handleGenerate = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);

    if (!user) {
      setErrorMessage('Please sign in to generate image-to-video animations.');
      return;
    }

    if (!imagePreview) {
      setErrorMessage('Please upload a source image (JPG, PNG, or WEBP).');
      return;
    }

    if (!prompt.trim()) {
      setErrorMessage('Please describe the motion or animation for the image.');
      return;
    }

    if (isDurationForbiddenOnFree) {
      setErrorMessage('Free trial allows up to 10-second videos. Upgrade to unlock longer video renders.');
      return;
    }

    if (userCredits < currentCost) {
      setErrorMessage(`Insufficient credits. Needed: ${currentCost}, available: ${userCredits}.`);
      return;
    }

    setIsSubmitting(true);
    const videoId = 'img_vid_' + Date.now() + '_' + Math.random().toString(36).substring(2, 8);

    const newVideoRecord: VideoRecord = {
      videoId,
      userId: user.uid,
      userEmail: user.email || '',
      prompt: `[Image to Video] ${prompt.trim()} (Motion: ${motionIntensity})`,
      imageUrl: imagePreview,
      duration,
      aspectRatio,
      style: 'Realistic',
      status: 'queued',
      progress: 5,
      creditsUsed: currentCost,
      createdAt: Date.now(),
    };

    try {
      await deductUserCredits(user.uid, currentCost);
      deductLocalCredits(currentCost);
      await saveVideoRecord(newVideoRecord);
      setActiveJob(newVideoRecord);

      const response = await fetch('/api/video/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          userId: user.uid,
          userEmail: user.email,
          prompt: `Animate image with ${motionIntensity} motion: ${prompt.trim()}`,
          imageUrl: imagePreview,
          duration,
          aspectRatio,
          style: 'Realistic',
          userPlan: profile?.plan || 'free',
          userCredits,
        }),
      });

      const data = await response.json();

      if (!response.ok) {
        await refundUserCredits(user.uid, currentCost);
        refundLocalCredits(currentCost);

        const errorMsg = data.error || 'Video generation service is not configured yet. Add the required API key in Secrets.';
        newVideoRecord.status = 'failed';
        newVideoRecord.error = errorMsg;
        await saveVideoRecord(newVideoRecord);
        setActiveJob(newVideoRecord);
        setErrorMessage(errorMsg);
        setIsSubmitting(false);
        return;
      }

      startPolling(data.jobId, newVideoRecord);
    } catch (err: any) {
      console.error('Image-to-video submission error:', err);
      await refundUserCredits(user.uid, currentCost);
      refundLocalCredits(currentCost);

      const errorMsg = err.message || 'Failed to submit image animation job.';
      newVideoRecord.status = 'failed';
      newVideoRecord.error = errorMsg;
      await saveVideoRecord(newVideoRecord);
      setActiveJob(newVideoRecord);
      setErrorMessage(errorMsg);
      setIsSubmitting(false);
    }
  };

  const startPolling = (jobId: string, currentRecord: VideoRecord) => {
    let attempts = 0;
    const interval = setInterval(async () => {
      attempts++;
      if (attempts > 36) {
        clearInterval(interval);
        currentRecord.status = 'failed';
        currentRecord.error = 'Image-to-video generation timed out.';
        await saveVideoRecord(currentRecord);
        setActiveJob({ ...currentRecord });
        setIsSubmitting(false);
        return;
      }

      try {
        const res = await fetch(`/api/video/status/${jobId}`);
        if (res.ok) {
          const statusData = await res.json();
          currentRecord.status = statusData.status;
          currentRecord.progress = statusData.progress;
          if (statusData.videoUrl) currentRecord.videoUrl = statusData.videoUrl;
          if (statusData.thumbnailUrl) currentRecord.thumbnailUrl = statusData.thumbnailUrl;
          if (statusData.error) currentRecord.error = statusData.error;

          setActiveJob({ ...currentRecord });

          if (statusData.status === 'completed') {
            clearInterval(interval);
            setIsSubmitting(false);
            await saveVideoRecord(currentRecord);
            onVideoCreated(currentRecord);
            await refreshProfile();
          } else if (statusData.status === 'failed') {
            clearInterval(interval);
            setIsSubmitting(false);
            if (user) {
              await refundUserCredits(user.uid, currentCost);
              refundLocalCredits(currentCost);
            }
            await saveVideoRecord(currentRecord);
            setErrorMessage(statusData.error || 'Generation failed at provider.');
          }
        }
      } catch (pollErr) {
        console.warn('Image polling err:', pollErr);
      }
    }, 4000);
  };

  return (
    <div id="image-to-video-page" className="p-4 sm:p-6 lg:p-8 max-w-5xl mx-auto space-y-6">
      <div>
        <div className="flex items-center gap-2 mb-1">
          <span className="text-xs uppercase font-mono tracking-wider text-cyan-400">Motion Studio</span>
          <span className="text-[10px] uppercase font-bold px-2 py-0.5 rounded bg-zinc-800 text-zinc-300 border border-zinc-700">
            Image to Video
          </span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-bold text-white tracking-tight">
          Animate Images with AI
        </h1>
        <p className="text-xs sm:text-sm text-zinc-400 mt-1">
          Upload any photo, portrait, concept art or product render and animate it with camera moves.
        </p>
      </div>

      {errorMessage && (
        <div className="p-4 rounded-xl bg-rose-950/80 border border-rose-800 text-rose-200 text-xs flex items-start gap-3 animate-in fade-in">
          <AlertCircle className="w-5 h-5 text-rose-400 shrink-0 mt-0.5" />
          <div className="flex-1">
            <p className="font-semibold text-rose-100">Generation Notice</p>
            <p className="mt-1 leading-relaxed">{errorMessage}</p>
          </div>
        </div>
      )}

      {/* Active Job Tracker */}
      {activeJob && (
        <div className="p-5 rounded-2xl bg-zinc-900 border border-cyan-500/40 shadow-xl space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              {activeJob.status === 'processing' || activeJob.status === 'queued' ? (
                <Loader2 className="w-5 h-5 text-cyan-400 animate-spin" />
              ) : activeJob.status === 'completed' ? (
                <CheckCircle2 className="w-5 h-5 text-emerald-400" />
              ) : (
                <AlertCircle className="w-5 h-5 text-rose-400" />
              )}
              <div>
                <h3 className="text-sm font-semibold text-white capitalize">
                  Status: {activeJob.status}
                </h3>
                <p className="text-xs text-zinc-400">
                  {activeJob.status === 'processing'
                    ? 'Synthesizing motion flow and temporal keyframes from image...'
                    : activeJob.status === 'queued'
                    ? 'Queued on image animation cluster...'
                    : activeJob.status === 'completed'
                    ? 'Video render finished!'
                    : activeJob.error || 'Failed.'}
                </p>
              </div>
            </div>

            {activeJob.status === 'completed' && activeJob.videoUrl && (
              <button
                onClick={() => onPlayVideo(activeJob)}
                className="px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-semibold flex items-center gap-1.5 shadow-md shadow-emerald-600/30"
              >
                <Play className="w-3.5 h-3.5 fill-white" />
                Play Video
              </button>
            )}
          </div>

          {(activeJob.status === 'processing' || activeJob.status === 'queued') && (
            <div className="w-full bg-zinc-800 rounded-full h-2 overflow-hidden">
              <div
                className="bg-cyan-500 h-full rounded-full transition-all duration-500"
                style={{ width: `${Math.max(8, activeJob.progress || 10)}%` }}
              />
            </div>
          )}
        </div>
      )}

      <form onSubmit={handleGenerate} className="space-y-6">
        {/* Upload Zone */}
        <div className="space-y-2">
          <label className="text-xs font-semibold text-zinc-200 flex items-center gap-1.5">
            <ImageIcon className="w-4 h-4 text-cyan-400" />
            Source Image (JPG, PNG, WEBP)
          </label>

          <input
            ref={fileInputRef}
            type="file"
            accept="image/jpeg,image/png,image/webp"
            className="hidden"
            onChange={handleFileChange}
          />

          {!imagePreview ? (
            <div
              id="image-dropzone"
              onClick={() => fileInputRef.current?.click()}
              onDragOver={(e) => e.preventDefault()}
              onDrop={handleDrop}
              className="border-2 border-dashed border-zinc-800 hover:border-cyan-500/60 bg-zinc-900/40 hover:bg-zinc-900/80 rounded-2xl p-8 text-center cursor-pointer transition-all"
            >
              <div className="w-12 h-12 rounded-2xl bg-zinc-800 flex items-center justify-center mx-auto mb-3 text-cyan-400">
                <Upload className="w-6 h-6" />
              </div>
              <p className="text-sm font-semibold text-white">
                Drag and drop your image here, or <span className="text-cyan-400 underline">browse</span>
              </p>
              <p className="text-xs text-zinc-500 mt-1">
                Supports JPG, PNG, and WEBP files up to 10MB
              </p>
            </div>
          ) : (
            <div className="relative rounded-2xl bg-zinc-900 border border-zinc-800 p-4 flex flex-col sm:flex-row items-center gap-4">
              <div className="w-36 h-36 rounded-xl overflow-hidden bg-black shrink-0 relative">
                <img
                  src={imagePreview}
                  alt="Upload preview"
                  className="w-full h-full object-cover"
                />
              </div>

              <div className="flex-1 text-xs text-zinc-300 space-y-1 truncate">
                <p className="font-semibold text-white truncate">{imageName || 'Uploaded Image'}</p>
                <p className="text-emerald-400 flex items-center gap-1">
                  <CheckCircle2 className="w-3.5 h-3.5" /> Ready for animation
                </p>
                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  className="text-cyan-400 hover:text-cyan-300 font-medium underline block pt-2"
                >
                  Change image
                </button>
              </div>

              <button
                type="button"
                onClick={() => {
                  setImagePreview(null);
                  setImageName('');
                }}
                className="p-2 text-zinc-400 hover:text-rose-400 hover:bg-rose-950/40 rounded-lg transition-colors"
                title="Remove image"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          )}
        </div>

        {/* Animation Prompt */}
        <div className="space-y-2">
          <label className="text-xs font-semibold text-zinc-200 flex items-center gap-1.5">
            <Sparkles className="w-4 h-4 text-cyan-400" />
            Motion & Camera Direction
          </label>
          <textarea
            id="image-motion-prompt"
            rows={3}
            required
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            placeholder="Describe what moves in the image (e.g. 'Slow cinematic camera push-in, wind gently blowing hair and leaves, soft warm light shifting across the face...')"
            className="w-full bg-zinc-900 border border-zinc-800 rounded-2xl p-4 text-sm text-white placeholder-zinc-500 focus:outline-none focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500 transition-all leading-relaxed"
          />
        </div>

        {/* Options */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
          {/* Duration */}
          <div className="space-y-2">
            <label className="text-xs font-semibold text-zinc-200 flex items-center gap-1.5">
              <Clock className="w-4 h-4 text-zinc-400" />
              Duration
            </label>
            <div className="grid grid-cols-2 gap-2">
              {([5, 10] as VideoDuration[]).map((dur) => (
                <button
                  key={dur}
                  type="button"
                  onClick={() => setDuration(dur)}
                  className={`p-3 rounded-xl border text-left transition-all ${
                    duration === dur
                      ? 'bg-cyan-600/20 border-cyan-500 text-white font-semibold'
                      : 'bg-zinc-900 border-zinc-800 text-zinc-300 hover:border-zinc-700'
                  }`}
                >
                  <span className="text-xs font-bold block">{dur} seconds</span>
                  <span className="text-[10px] text-zinc-400 block mt-0.5">{dur} credits</span>
                </button>
              ))}
            </div>
          </div>

          {/* Aspect Ratio */}
          <div className="space-y-2">
            <label className="text-xs font-semibold text-zinc-200 flex items-center gap-1.5">
              <Ratio className="w-4 h-4 text-zinc-400" />
              Target Ratio
            </label>
            <div className="grid grid-cols-3 gap-2">
              {(['16:9', '9:16', '1:1'] as AspectRatio[]).map((r) => (
                <button
                  key={r}
                  type="button"
                  onClick={() => setAspectRatio(r)}
                  className={`p-3 rounded-xl border text-center transition-all ${
                    aspectRatio === r
                      ? 'bg-cyan-600/20 border-cyan-500 text-white font-semibold'
                      : 'bg-zinc-900 border-zinc-800 text-zinc-300 hover:border-zinc-700'
                  }`}
                >
                  <span className="text-xs font-bold block">{r}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Motion Intensity */}
          <div className="space-y-2">
            <label className="text-xs font-semibold text-zinc-200">Motion Amplitude</label>
            <div className="grid grid-cols-3 gap-2">
              {[
                { id: 'subtle', label: 'Subtle' },
                { id: 'moderate', label: 'Medium' },
                { id: 'dynamic', label: 'Dynamic' },
              ].map((m) => (
                <button
                  key={m.id}
                  type="button"
                  onClick={() => setMotionIntensity(m.id as any)}
                  className={`p-3 rounded-xl border text-center capitalize text-xs transition-all ${
                    motionIntensity === m.id
                      ? 'bg-cyan-600/20 border-cyan-500 text-white font-semibold'
                      : 'bg-zinc-900 border-zinc-800 text-zinc-400 hover:text-white'
                  }`}
                >
                  {m.label}
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Action Bar */}
        <div className="p-5 rounded-2xl bg-zinc-900 border border-zinc-800 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3 text-xs">
            <Coins className="w-4 h-4 text-amber-400" />
            <span className="text-zinc-400">Generation Cost:</span>
            <span className="font-bold text-white font-mono">{currentCost} credits</span>
            <span className="text-zinc-500">• Balance: {userCredits} cr</span>
          </div>

          <button
            type="submit"
            disabled={isSubmitting || !imagePreview || !prompt.trim() || userCredits < currentCost}
            className="w-full sm:w-auto px-7 py-3 bg-cyan-600 hover:bg-cyan-500 disabled:opacity-50 text-white rounded-xl text-xs font-bold transition-all shadow-lg shadow-cyan-600/30 flex items-center justify-center gap-2 cursor-pointer"
          >
            {isSubmitting ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                <span>Rendering Animation...</span>
              </>
            ) : (
              <>
                <Video className="w-4 h-4" />
                <span>Animate Image ({currentCost} Credits)</span>
              </>
            )}
          </button>
        </div>
      </form>
    </div>
  );
};
