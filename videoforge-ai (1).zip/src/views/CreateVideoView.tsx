import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import {
  VideoDuration,
  AspectRatio,
  VideoStyle,
  VideoRecord,
  AppView,
} from '../types';
import { saveVideoRecord, deductUserCredits, refundUserCredits } from '../lib/firebase';
import {
  Sparkles,
  Video,
  Clock,
  Ratio,
  Palette,
  Mic,
  Subtitles,
  Music,
  AlertCircle,
  Loader2,
  CheckCircle2,
  Coins,
  ArrowRight,
  Info,
  Play,
  RotateCcw,
} from 'lucide-react';

interface CreateVideoViewProps {
  onVideoCreated: (video: VideoRecord) => void;
  onNavigate: (view: AppView) => void;
  onPlayVideo: (video: VideoRecord) => void;
  initialPrompt?: string;
  initialStyle?: VideoStyle;
  initialDuration?: VideoDuration;
}

export const CreateVideoView: React.FC<CreateVideoViewProps> = ({
  onVideoCreated,
  onNavigate,
  onPlayVideo,
  initialPrompt = '',
  initialStyle = 'Cinematic',
  initialDuration = 10,
}) => {
  const { user, profile, refreshProfile, deductLocalCredits, refundLocalCredits } = useAuth();

  const [prompt, setPrompt] = useState(initialPrompt);
  const [duration, setDuration] = useState<VideoDuration>(initialDuration);
  const [aspectRatio, setAspectRatio] = useState<AspectRatio>('16:9');
  const [style, setStyle] = useState<VideoStyle>(initialStyle);

  // AI Voiceover settings
  const [voiceEnabled, setVoiceEnabled] = useState(false);
  const [voiceType, setVoiceType] = useState<'male' | 'female' | 'energetic' | 'calm' | 'documentary' | 'storytelling'>('calm');
  const [voiceLanguage, setVoiceLanguage] = useState('en');
  const [voiceText, setVoiceText] = useState('');

  // Auto Captions
  const [captionsEnabled, setCaptionsEnabled] = useState(true);
  const [captionStyle, setCaptionStyle] = useState<'reels' | 'cinematic' | 'minimal' | 'banner'>('reels');

  // Background Music
  const [backgroundMusic, setBackgroundMusic] = useState<string>('cinematic_ambient');

  // Status & Job State
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [activeJob, setActiveJob] = useState<VideoRecord | null>(null);
  const [errorMessage, setErrorMessage] = useState<string | null>(null);

  const durationCosts: Record<VideoDuration, number> = {
    5: 5,
    10: 10,
    15: 15,
    30: 30,
  };

  const currentCost = durationCosts[duration];
  const userCredits = profile?.credits ?? 0;
  const isFreePlan = profile?.plan === 'free';
  const isDurationForbiddenOnFree = isFreePlan && duration > 10;

  // Prompt suggestions
  const promptSuggestions = [
    'Create a cinematic video of a futuristic city at night with flying cars and neon rain reflections.',
    'A high-tech robotic humanoid waking up inside an atmospheric sci-fi laboratory with volumetric lasers.',
    'Macro shot of a drop of liquid mercury morphing into an intricate mechanical butterfly in slow motion.',
    'Sweeping drone shot through misty Nordic pine mountains at golden hour with dramatic sun shafts.',
  ];

  const handleGenerate = async (e: React.FormEvent) => {
    e.preventDefault();
    setErrorMessage(null);

    if (!user) {
      setErrorMessage('Please sign in or create an account to generate videos.');
      return;
    }

    if (!prompt.trim()) {
      setErrorMessage('Please enter a description for your video.');
      return;
    }

    if (isDurationForbiddenOnFree) {
      setErrorMessage('Free trial allows up to 10-second videos. Upgrade your plan to unlock 15s and 30s generation.');
      return;
    }

    if (userCredits < currentCost) {
      setErrorMessage(`Insufficient credits. This video requires ${currentCost} credits, but you currently have ${userCredits}.`);
      return;
    }

    setIsSubmitting(true);
    const videoId = 'vid_' + Date.now() + '_' + Math.random().toString(36).substring(2, 8);

    // Create preliminary Firestore record
    const newVideoRecord: VideoRecord = {
      videoId,
      userId: user.uid,
      userEmail: user.email || '',
      prompt: prompt.trim(),
      duration,
      aspectRatio,
      style,
      status: 'queued',
      progress: 5,
      creditsUsed: currentCost,
      createdAt: Date.now(),
      captions: captionsEnabled
        ? [
            { id: 'c1', start: 0, end: duration / 2, text: prompt.slice(0, 45) + '...' },
            { id: 'c2', start: duration / 2, end: duration, text: 'Rendered in high resolution with VideoForge AI' },
          ]
        : undefined,
      voiceover: voiceEnabled
        ? {
            voice: voiceType,
            language: voiceLanguage,
            text: voiceText.trim() || prompt.trim(),
          }
        : undefined,
      backgroundMusic: backgroundMusic !== 'none' ? backgroundMusic : undefined,
    };

    try {
      // 1. Check & Deduct credits in Firestore server-side / client wrapper
      await deductUserCredits(user.uid, currentCost);
      deductLocalCredits(currentCost);

      // 2. Save initial job status in Firestore
      await saveVideoRecord(newVideoRecord);
      setActiveJob(newVideoRecord);

      // 3. Submit generation request to backend server
      const response = await fetch('/api/video/generate', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          userId: user.uid,
          userEmail: user.email,
          prompt: prompt.trim(),
          style,
          duration,
          aspectRatio,
          voiceover: voiceEnabled
            ? {
                enabled: true,
                voice: voiceType,
                language: voiceLanguage,
                text: voiceText.trim() || prompt.trim(),
              }
            : undefined,
          captions: {
            enabled: captionsEnabled,
            style: captionStyle,
          },
          backgroundMusic,
          userPlan: profile?.plan || 'free',
          userCredits,
        }),
      });

      const data = await response.json();

      if (!response.ok) {
        // Generation submission failed at server/provider:
        // Automatically refund credits!
        await refundUserCredits(user.uid, currentCost);
        refundLocalCredits(currentCost);

        const errorMsg = data.error || 'Video generation service is not configured yet. Add the required API key in Secrets.';
        newVideoRecord.status = 'failed';
        newVideoRecord.error = errorMsg;
        await saveVideoRecord(newVideoRecord);
        setActiveJob(newVideoRecord);
        setErrorMessage(errorMsg);
        setIsSubmitting(false);
        return;
      }

      // 4. Start polling status
      const jobId = data.jobId;
      startPolling(jobId, newVideoRecord);
    } catch (err: any) {
      console.error('Generation submission error:', err);
      // Refund credits
      await refundUserCredits(user.uid, currentCost);
      refundLocalCredits(currentCost);

      const errorMsg = err.message || 'Failed to submit generation request.';
      newVideoRecord.status = 'failed';
      newVideoRecord.error = errorMsg;
      await saveVideoRecord(newVideoRecord);
      setActiveJob(newVideoRecord);
      setErrorMessage(errorMsg);
      setIsSubmitting(false);
    }
  };

  const startPolling = (jobId: string, currentRecord: VideoRecord) => {
    let attempts = 0;
    const interval = setInterval(async () => {
      attempts++;
      if (attempts > 36) {
        // Timed out
        clearInterval(interval);
        currentRecord.status = 'failed';
        currentRecord.error = 'Video generation timed out waiting for provider response.';
        await saveVideoRecord(currentRecord);
        setActiveJob({ ...currentRecord });
        setIsSubmitting(false);
        return;
      }

      try {
        const res = await fetch(`/api/video/status/${jobId}`);
        if (res.ok) {
          const statusData = await res.json();
          currentRecord.status = statusData.status;
          currentRecord.progress = statusData.progress;
          if (statusData.videoUrl) currentRecord.videoUrl = statusData.videoUrl;
          if (statusData.thumbnailUrl) currentRecord.thumbnailUrl = statusData.thumbnailUrl;
          if (statusData.error) currentRecord.error = statusData.error;

          setActiveJob({ ...currentRecord });

          if (statusData.status === 'completed') {
            clearInterval(interval);
            setIsSubmitting(false);
            await saveVideoRecord(currentRecord);
            onVideoCreated(currentRecord);
            await refreshProfile();
          } else if (statusData.status === 'failed') {
            clearInterval(interval);
            setIsSubmitting(false);
            // Refund
            if (user) {
              await refundUserCredits(user.uid, currentCost);
              refundLocalCredits(currentCost);
            }
            await saveVideoRecord(currentRecord);
            setErrorMessage(statusData.error || 'Video generation failed at provider.');
          }
        }
      } catch (pollErr) {
        console.warn('Status poll attempt failed:', pollErr);
      }
    }, 4000);
  };

  return (
    <div id="create-video-page" className="p-4 sm:p-6 lg:p-8 max-w-5xl mx-auto space-y-6">
      {/* Header */}
      <div>
        <div className="flex items-center gap-2 mb-1">
          <span className="text-xs uppercase font-mono tracking-wider text-indigo-400">Video Studio</span>
          <span className="text-[10px] uppercase font-bold px-2 py-0.5 rounded bg-zinc-800 text-zinc-300 border border-zinc-700">
            Text to Video
          </span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-bold text-white tracking-tight">
          Create AI Video
        </h1>
        <p className="text-xs sm:text-sm text-zinc-400 mt-1">
          Compose your cinematic vision with synchronized voice-over, captions, and duration options.
        </p>
      </div>

      {/* Error Alert */}
      {errorMessage && (
        <div id="create-error-banner" className="p-4 rounded-xl bg-rose-950/80 border border-rose-800 text-rose-200 text-xs flex items-start gap-3 animate-in fade-in">
          <AlertCircle className="w-5 h-5 text-rose-400 shrink-0 mt-0.5" />
          <div className="flex-1">
            <p className="font-semibold text-rose-100">Generation Notice</p>
            <p className="mt-1 leading-relaxed">{errorMessage}</p>
            {errorMessage.includes('upgrade') && (
              <button
                onClick={() => onNavigate('pricing')}
                className="mt-2 text-indigo-300 hover:text-indigo-200 font-semibold underline flex items-center gap-1"
              >
                View Upgrade Plans <ArrowRight className="w-3 h-3" />
              </button>
            )}
            {errorMessage.includes('Secrets') && (
              <p className="mt-1.5 text-[11px] text-rose-300">
                Tip: If you are setting up your own video provider key, configure <code className="px-1 py-0.5 bg-black/40 rounded">VIDEO_API_KEY</code> or verify <code className="px-1 py-0.5 bg-black/40 rounded">GEMINI_API_KEY</code>.
              </p>
            )}
          </div>
        </div>
      )}

      {/* Active Job Progress Widget */}
      {activeJob && (
        <div id="active-job-tracker" className="p-5 rounded-2xl bg-zinc-900 border border-indigo-500/40 shadow-xl space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5">
              {activeJob.status === 'processing' || activeJob.status === 'queued' ? (
                <Loader2 className="w-5 h-5 text-indigo-400 animate-spin" />
              ) : activeJob.status === 'completed' ? (
                <CheckCircle2 className="w-5 h-5 text-emerald-400" />
              ) : (
                <AlertCircle className="w-5 h-5 text-rose-400" />
              )}
              <div>
                <h3 className="text-sm font-semibold text-white capitalize">
                  Status: {activeJob.status}
                </h3>
                <p className="text-xs text-zinc-400">
                  {activeJob.status === 'processing'
                    ? 'Neural renderer is creating visual frames and audio sync...'
                    : activeJob.status === 'queued'
                    ? 'Job received and queued on rendering cluster...'
                    : activeJob.status === 'completed'
                    ? 'Video render finished successfully!'
                    : activeJob.error || 'Video generation failed.'}
                </p>
              </div>
            </div>

            {activeJob.status === 'completed' && activeJob.videoUrl && (
              <button
                onClick={() => onPlayVideo(activeJob)}
                className="px-3.5 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg text-xs font-semibold flex items-center gap-1.5 shadow-md shadow-emerald-600/30 cursor-pointer"
              >
                <Play className="w-3.5 h-3.5 fill-white" />
                Play Video
              </button>
            )}
          </div>

          {(activeJob.status === 'processing' || activeJob.status === 'queued') && (
            <div className="space-y-1.5">
              <div className="w-full bg-zinc-800 rounded-full h-2 overflow-hidden">
                <div
                  className="bg-gradient-to-r from-indigo-500 to-violet-500 h-full rounded-full transition-all duration-500"
                  style={{ width: `${Math.max(8, activeJob.progress || 10)}%` }}
                />
              </div>
              <div className="flex justify-between text-[11px] text-zinc-500 font-mono">
                <span>Rendering video & audio</span>
                <span>{activeJob.progress || 10}%</span>
              </div>
            </div>
          )}
        </div>
      )}

      {/* Main Generation Form */}
      <form onSubmit={handleGenerate} className="space-y-6">
        {/* 1. Prompt Input & Suggestions */}
        <div className="space-y-2">
          <div className="flex items-center justify-between">
            <label className="text-xs font-semibold text-zinc-200 flex items-center gap-1.5">
              <Sparkles className="w-4 h-4 text-indigo-400" />
              Video Prompt
            </label>
            <button
              type="button"
              onClick={() => onNavigate('script')}
              className="text-xs text-indigo-400 hover:text-indigo-300 flex items-center gap-1 font-medium"
            >
              Generate Script with AI <ArrowRight className="w-3 h-3" />
            </button>
          </div>

          <textarea
            id="video-prompt-input"
            rows={4}
            required
            value={prompt}
            onChange={(e) => setPrompt(e.target.value)}
            placeholder="Describe your scene in detail (e.g. 'Create a cinematic video of a futuristic city at night with flying cars, neon lights reflecting on wet streets, slow pan upward...')"
            className="w-full bg-zinc-900 border border-zinc-800 rounded-2xl p-4 text-sm text-white placeholder-zinc-500 focus:outline-none focus:border-indigo-500 focus:ring-1 focus:ring-indigo-500 transition-all leading-relaxed"
          />

          {/* Quick inspiration pills */}
          <div className="flex flex-wrap items-center gap-2 pt-1">
            <span className="text-[11px] text-zinc-500">Try asking:</span>
            {promptSuggestions.map((suggestion, idx) => (
              <button
                key={idx}
                type="button"
                onClick={() => setPrompt(suggestion)}
                className="text-[11px] px-2.5 py-1 rounded-full bg-zinc-900 hover:bg-zinc-800 text-zinc-400 hover:text-zinc-200 border border-zinc-800 transition-colors truncate max-w-xs text-left"
              >
                {suggestion.slice(0, 42)}...
              </button>
            ))}
          </div>
        </div>

        {/* 2. Options Grid: Duration, Aspect Ratio, Style */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-5">
          {/* Duration Selector */}
          <div className="space-y-2">
            <label className="text-xs font-semibold text-zinc-200 flex items-center gap-1.5">
              <Clock className="w-4 h-4 text-zinc-400" />
              Duration
            </label>
            <div className="grid grid-cols-2 gap-2">
              {([5, 10, 15, 30] as VideoDuration[]).map((dur) => {
                const disabled = isFreePlan && dur > 10;
                return (
                  <button
                    key={dur}
                    type="button"
                    id={`duration-${dur}s-btn`}
                    onClick={() => setDuration(dur)}
                    className={`p-3 rounded-xl border text-left transition-all ${
                      duration === dur
                        ? 'bg-indigo-600/20 border-indigo-500 text-white font-semibold'
                        : disabled
                        ? 'bg-zinc-950/60 border-zinc-850 text-zinc-600 cursor-not-allowed'
                        : 'bg-zinc-900 border-zinc-800 text-zinc-300 hover:border-zinc-700'
                    }`}
                  >
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-bold">{dur} seconds</span>
                      <span className="text-[10px] font-mono opacity-80">{dur} cr</span>
                    </div>
                    {disabled && (
                      <span className="text-[9px] text-amber-500/90 font-medium block mt-1">
                        Paid Plan Only
                      </span>
                    )}
                  </button>
                );
              })}
            </div>
          </div>

          {/* Aspect Ratio Selector */}
          <div className="space-y-2">
            <label className="text-xs font-semibold text-zinc-200 flex items-center gap-1.5">
              <Ratio className="w-4 h-4 text-zinc-400" />
              Aspect Ratio
            </label>
            <div className="grid grid-cols-3 gap-2">
              {[
                { id: '16:9' as AspectRatio, label: '16:9', desc: 'Landscape' },
                { id: '9:16' as AspectRatio, label: '9:16', desc: 'Reels / Shorts' },
                { id: '1:1' as AspectRatio, label: '1:1', desc: 'Square Post' },
              ].map((ratio) => (
                <button
                  key={ratio.id}
                  type="button"
                  id={`ratio-${ratio.id.replace(':', '-')}-btn`}
                  onClick={() => setAspectRatio(ratio.id)}
                  className={`p-3 rounded-xl border text-center transition-all ${
                    aspectRatio === ratio.id
                      ? 'bg-indigo-600/20 border-indigo-500 text-white font-semibold'
                      : 'bg-zinc-900 border-zinc-800 text-zinc-300 hover:border-zinc-700'
                  }`}
                >
                  <span className="text-xs font-bold block">{ratio.label}</span>
                  <span className="text-[10px] text-zinc-400 block mt-0.5">{ratio.desc}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Style Selector */}
          <div className="space-y-2">
            <label className="text-xs font-semibold text-zinc-200 flex items-center gap-1.5">
              <Palette className="w-4 h-4 text-zinc-400" />
              Visual Style
            </label>
            <select
              id="style-select"
              value={style}
              onChange={(e) => setStyle(e.target.value as VideoStyle)}
              className="w-full bg-zinc-900 border border-zinc-800 rounded-xl p-3 text-xs text-white focus:outline-none focus:border-indigo-500"
            >
              <option value="Cinematic">Cinematic (Hollywood Grade)</option>
              <option value="Realistic">Realistic Photoreal</option>
              <option value="Anime">Anime (Japanese Studio)</option>
              <option value="3D Animation">3D Animation (Pixar/Unreal)</option>
              <option value="Documentary">Documentary (National Geographic)</option>
              <option value="Cartoon">Cartoon (Stylized 2D)</option>
              <option value="Product Advertisement">Product Advertisement</option>
            </select>
          </div>
        </div>

        {/* 3. Audio & Subtitles Accordion */}
        <div className="p-5 rounded-2xl bg-zinc-900/60 border border-zinc-800 space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-xs font-bold text-white uppercase tracking-wider">
              Audio & Captions Configuration
            </h3>
            <span className="text-[11px] text-zinc-500">Included in generation</span>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
            {/* AI Voiceover Toggle */}
            <div className="p-3.5 rounded-xl bg-zinc-900 border border-zinc-800 space-y-2.5">
              <label className="flex items-center justify-between cursor-pointer">
                <span className="font-semibold text-zinc-200 flex items-center gap-1.5">
                  <Mic className="w-3.5 h-3.5 text-emerald-400" />
                  AI Voice-Over
                </span>
                <input
                  type="checkbox"
                  checked={voiceEnabled}
                  onChange={(e) => setVoiceEnabled(e.target.checked)}
                  className="rounded border-zinc-700 text-indigo-600 focus:ring-indigo-500"
                />
              </label>

              {voiceEnabled && (
                <div className="space-y-2 pt-1 animate-in fade-in">
                  <div>
                    <label className="text-[11px] text-zinc-400">Voice Archetype</label>
                    <select
                      value={voiceType}
                      onChange={(e) => setVoiceType(e.target.value as any)}
                      className="w-full mt-1 bg-zinc-800 border border-zinc-700 rounded-lg p-1.5 text-xs text-zinc-200"
                    >
                      <option value="calm">Calm & Trustworthy</option>
                      <option value="energetic">Energetic & Upbeat</option>
                      <option value="documentary">Deep Documentary</option>
                      <option value="storytelling">Narrative Storyteller</option>
                      <option value="male">Warm Male</option>
                      <option value="female">Crisp Female</option>
                    </select>
                  </div>
                  <div>
                    <label className="text-[11px] text-zinc-400">Language</label>
                    <select
                      value={voiceLanguage}
                      onChange={(e) => setVoiceLanguage(e.target.value)}
                      className="w-full mt-1 bg-zinc-800 border border-zinc-700 rounded-lg p-1.5 text-xs text-zinc-200"
                    >
                      <option value="en">English (US/UK)</option>
                      <option value="es">Spanish</option>
                      <option value="fr">French</option>
                      <option value="de">German</option>
                      <option value="ja">Japanese</option>
                      <option value="pt">Portuguese</option>
                      <option value="hi">Hindi</option>
                    </select>
                  </div>
                </div>
              )}
            </div>

            {/* Auto Captions */}
            <div className="p-3.5 rounded-xl bg-zinc-900 border border-zinc-800 space-y-2.5">
              <label className="flex items-center justify-between cursor-pointer">
                <span className="font-semibold text-zinc-200 flex items-center gap-1.5">
                  <Subtitles className="w-3.5 h-3.5 text-amber-400" />
                  Auto Captions
                </span>
                <input
                  type="checkbox"
                  checked={captionsEnabled}
                  onChange={(e) => setCaptionsEnabled(e.target.checked)}
                  className="rounded border-zinc-700 text-indigo-600 focus:ring-indigo-500"
                />
              </label>

              {captionsEnabled && (
                <div className="space-y-2 pt-1 animate-in fade-in">
                  <div>
                    <label className="text-[11px] text-zinc-400">Caption Style</label>
                    <select
                      value={captionStyle}
                      onChange={(e) => setCaptionStyle(e.target.value as any)}
                      className="w-full mt-1 bg-zinc-800 border border-zinc-700 rounded-lg p-1.5 text-xs text-zinc-200"
                    >
                      <option value="reels">TikTok / Reels Kinetic Bold</option>
                      <option value="cinematic">Cinematic Golden Italic</option>
                      <option value="minimal">Minimal Modern Subtitle</option>
                      <option value="banner">Solid Banner Backdrop</option>
                    </select>
                  </div>
                  <p className="text-[10px] text-zinc-500">
                    Captions are synchronized and toggleable in the player.
                  </p>
                </div>
              )}
            </div>

            {/* Background Music */}
            <div className="p-3.5 rounded-xl bg-zinc-900 border border-zinc-800 space-y-2.5">
              <span className="font-semibold text-zinc-200 flex items-center gap-1.5">
                <Music className="w-3.5 h-3.5 text-violet-400" />
                Background Music
              </span>
              <div>
                <select
                  value={backgroundMusic}
                  onChange={(e) => setBackgroundMusic(e.target.value)}
                  className="w-full bg-zinc-800 border border-zinc-700 rounded-lg p-2 text-xs text-zinc-200"
                >
                  <option value="cinematic_ambient">Cinematic Ambient Soundtrack</option>
                  <option value="synthwave">Futuristic Cyberpunk Synth</option>
                  <option value="orchestral">Epic Dramatic Orchestral</option>
                  <option value="lofi">Lo-fi Study & Chill Beat</option>
                  <option value="none">No Background Music</option>
                </select>
              </div>
              <p className="text-[10px] text-zinc-500">
                Royalty-free background tracks mixed to not overpower narration.
              </p>
            </div>
          </div>
        </div>

        {/* 4. Generation Summary Bar & CTA */}
        <div className="p-5 rounded-2xl bg-zinc-900 border border-zinc-800 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2">
              <Coins className="w-4 h-4 text-amber-400" />
              <span className="text-xs text-zinc-400">Generation Cost:</span>
              <span className="text-sm font-bold text-white font-mono">{currentCost} credits</span>
            </div>

            <div className="h-4 w-px bg-zinc-800 hidden sm:block" />

            <div className="text-xs text-zinc-400">
              <span>Your balance: </span>
              <span className="font-bold text-zinc-200 font-mono">{userCredits} credits</span>
            </div>
          </div>

          <div className="flex items-center gap-3">
            <button
              id="generate-video-submit-btn"
              type="submit"
              disabled={isSubmitting || isDurationForbiddenOnFree || userCredits < currentCost}
              className="w-full sm:w-auto px-7 py-3 bg-indigo-600 hover:bg-indigo-500 disabled:opacity-50 disabled:cursor-not-allowed text-white rounded-xl text-xs font-bold transition-all shadow-lg shadow-indigo-600/30 flex items-center justify-center gap-2 cursor-pointer"
            >
              {isSubmitting ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  <span>Processing Video Job...</span>
                </>
              ) : (
                <>
                  <Video className="w-4 h-4" />
                  <span>Generate Video ({currentCost} Credits)</span>
                </>
              )}
            </button>
          </div>
        </div>
      </form>
    </div>
  );
};
