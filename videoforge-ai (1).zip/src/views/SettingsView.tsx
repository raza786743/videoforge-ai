import React, { useState } from 'react';
import { useAuth } from '../context/AuthContext';
import {
  User,
  Shield,
  Key,
  CheckCircle2,
  AlertTriangle,
  Mail,
  Coins,
  Zap,
  Save,
  LogOut,
} from 'lucide-react';

export const SettingsView: React.FC = () => {
  const { user, profile, logout } = useAuth();
  const [displayName, setDisplayName] = useState(profile?.name || user?.displayName || '');
  const [isSaved, setIsSaved] = useState(false);

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    setIsSaved(true);
    setTimeout(() => setIsSaved(false), 2500);
  };

  return (
    <div id="settings-page" className="p-4 sm:p-6 lg:p-8 max-w-4xl mx-auto space-y-8">
      <div>
        <div className="flex items-center gap-2 mb-1">
          <span className="text-xs uppercase font-mono tracking-wider text-indigo-400">Account</span>
          <span className="text-[10px] uppercase font-bold px-2 py-0.5 rounded bg-zinc-800 text-zinc-300 border border-zinc-700">
            Preferences
          </span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-bold text-white tracking-tight">
          Settings & Account
        </h1>
        <p className="text-xs sm:text-sm text-zinc-400 mt-1">
          Manage your account profile, plan status, and generation defaults.
        </p>
      </div>

      {/* User Profile Card */}
      <div className="p-6 rounded-2xl bg-zinc-900 border border-zinc-800 space-y-6">
        <h2 className="text-sm font-bold text-white flex items-center gap-2">
          <User className="w-4 h-4 text-indigo-400" />
          Profile Information
        </h2>

        <form onSubmit={handleSave} className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="text-xs font-semibold text-zinc-300 block mb-1">Display Name</label>
              <input
                type="text"
                value={displayName}
                onChange={(e) => setDisplayName(e.target.value)}
                className="w-full bg-zinc-950 border border-zinc-800 rounded-xl px-3.5 py-2.5 text-xs text-white focus:outline-none focus:border-indigo-500"
              />
            </div>

            <div>
              <label className="text-xs font-semibold text-zinc-300 block mb-1">Email Address</label>
              <input
                type="email"
                disabled
                value={user?.email || 'user@example.com'}
                className="w-full bg-zinc-950/60 border border-zinc-800 rounded-xl px-3.5 py-2.5 text-xs text-zinc-400 cursor-not-allowed"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-2">
            <div className="p-3.5 rounded-xl bg-zinc-950 border border-zinc-800/80">
              <span className="text-[10px] uppercase font-mono text-zinc-500">Plan Status</span>
              <div className="text-sm font-bold text-white capitalize mt-0.5">
                {profile?.plan || 'Free'}
              </div>
            </div>

            <div className="p-3.5 rounded-xl bg-zinc-950 border border-zinc-800/80">
              <span className="text-[10px] uppercase font-mono text-zinc-500">Available Credits</span>
              <div className="text-sm font-bold text-amber-400 font-mono mt-0.5">
                {profile?.credits ?? 0}
              </div>
            </div>

            <div className="p-3.5 rounded-xl bg-zinc-950 border border-zinc-800/80">
              <span className="text-[10px] uppercase font-mono text-zinc-500">User ID</span>
              <div className="text-xs font-mono text-zinc-400 truncate mt-0.5" title={user?.uid}>
                {user?.uid || 'Not signed in'}
              </div>
            </div>
          </div>

          <div className="flex justify-end pt-2">
            <button
              type="submit"
              className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
            >
              {isSaved ? (
                <>
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                  <span>Saved!</span>
                </>
              ) : (
                <>
                  <Save className="w-3.5 h-3.5" />
                  <span>Save Changes</span>
                </>
              )}
            </button>
          </div>
        </form>
      </div>

      {/* Security & Server-Side Secret Architecture */}
      <div className="p-6 rounded-2xl bg-zinc-900 border border-zinc-800 space-y-4">
        <h2 className="text-sm font-bold text-white flex items-center gap-2">
          <Shield className="w-4 h-4 text-emerald-400" />
          Server-Side Security & Secrets Architecture
        </h2>
        <p className="text-xs text-zinc-400 leading-relaxed">
          VideoForge AI enforces strict server-side encapsulation. Your API keys (Gemini, Google Veo / Video generation providers, and Stripe secrets) are never exposed to the client browser and run entirely inside the Node.js container backend.
        </p>

        <div className="space-y-2 pt-2 text-xs">
          <div className="p-3 rounded-xl bg-zinc-950 border border-zinc-800 flex items-center justify-between">
            <div className="flex items-center gap-2 text-zinc-300">
              <Key className="w-4 h-4 text-zinc-500" />
              <span>Gemini AI Screenwriter</span>
            </div>
            <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-emerald-950/60 text-emerald-400 border border-emerald-500/30">
              Active (Server-Side)
            </span>
          </div>

          <div className="p-3 rounded-xl bg-zinc-950 border border-zinc-800 flex items-center justify-between">
            <div className="flex items-center gap-2 text-zinc-300">
              <Key className="w-4 h-4 text-zinc-500" />
              <span>Video Generation Provider</span>
            </div>
            <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-indigo-950/60 text-indigo-400 border border-indigo-500/30">
              Configured via Environment / Secrets
            </span>
          </div>

          <div className="p-3 rounded-xl bg-zinc-950 border border-zinc-800 flex items-center justify-between">
            <div className="flex items-center gap-2 text-zinc-300">
              <Key className="w-4 h-4 text-zinc-500" />
              <span>Stripe Payment Webhook</span>
            </div>
            <span className="px-2 py-0.5 rounded text-[10px] font-mono bg-indigo-950/60 text-indigo-400 border border-indigo-500/30">
              Server-Side Verified
            </span>
          </div>
        </div>
      </div>

      {/* Session Controls */}
      <div className="p-6 rounded-2xl bg-zinc-900 border border-zinc-800 flex items-center justify-between">
        <div>
          <h3 className="text-sm font-semibold text-white">Sign Out</h3>
          <p className="text-xs text-zinc-400 mt-0.5">End your current session on this device.</p>
        </div>
        <button
          onClick={logout}
          className="px-4 py-2 rounded-xl bg-zinc-800 hover:bg-rose-950/40 text-zinc-300 hover:text-rose-400 border border-zinc-700 hover:border-rose-800 text-xs font-semibold flex items-center gap-1.5 transition-colors cursor-pointer"
        >
          <LogOut className="w-3.5 h-3.5" />
          <span>Sign Out</span>
        </button>
      </div>
    </div>
  );
};
