import React from 'react';
import { useAuth } from '../context/AuthContext';
import { VideoRecord, AppView } from '../types';
import {
  Coins,
  Film,
  Sparkles,
  Zap,
  ArrowRight,
  Plus,
  Play,
  Clock,
  CheckCircle2,
  AlertCircle,
  Loader2,
  Image as ImageIcon,
  FileText,
} from 'lucide-react';

interface DashboardViewProps {
  videos: VideoRecord[];
  onNavigate: (view: AppView) => void;
  onPlayVideo: (video: VideoRecord) => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({
  videos,
  onNavigate,
  onPlayVideo,
}) => {
  const { user, profile } = useAuth();

  const completedVideos = videos.filter((v) => v.status === 'completed');
  const activeJobs = videos.filter((v) => v.status === 'queued' || v.status === 'processing');

  // Free trial remaining generations (each generation is 10 cr)
  const freeTrialRemaining =
    profile?.plan === 'free'
      ? Math.max(0, Math.floor((profile?.credits ?? 0) / 10))
      : 'Unlimited';

  return (
    <div id="dashboard-view" className="p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto space-y-8">
      {/* Welcome Banner */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 bg-gradient-to-r from-zinc-900 via-zinc-900 to-indigo-950/40 p-6 rounded-2xl border border-zinc-800/80">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-xs uppercase font-mono tracking-wider text-indigo-400">Creator Studio</span>
            <span className="text-[10px] uppercase font-bold px-2 py-0.5 rounded bg-zinc-800 text-zinc-300 border border-zinc-700">
              {profile?.plan || 'Free'} Plan
            </span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-bold text-white tracking-tight">
            Welcome back, {user?.displayName || 'Creator'}!
          </h1>
          <p className="text-xs sm:text-sm text-zinc-400 mt-1">
            Ready to forge high-converting AI videos today? What are you creating?
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2.5">
          <button
            id="dash-create-video-btn"
            onClick={() => onNavigate('create')}
            className="px-4 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-semibold flex items-center gap-2 shadow-lg shadow-indigo-600/30 transition-all cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>Create Video</span>
          </button>

          <button
            id="dash-gen-script-btn"
            onClick={() => onNavigate('script')}
            className="px-4 py-2.5 bg-zinc-800 hover:bg-zinc-700 border border-zinc-700 text-zinc-200 rounded-xl text-xs font-medium flex items-center gap-2 transition-colors cursor-pointer"
          >
            <FileText className="w-4 h-4 text-emerald-400" />
            <span>AI Script Writer</span>
          </button>
        </div>
      </div>

      {/* 4 Metric Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Card 1: Available Credits */}
        <div
          id="metric-credits"
          onClick={() => onNavigate('pricing')}
          className="p-5 rounded-2xl bg-zinc-900/60 border border-zinc-800 hover:border-zinc-700 transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between text-zinc-400 mb-3">
            <span className="text-xs font-medium">Available Credits</span>
            <div className="w-8 h-8 rounded-xl bg-amber-500/10 text-amber-400 flex items-center justify-center">
              <Coins className="w-4 h-4" />
            </div>
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-3xl font-black text-white font-mono">{profile?.credits ?? 0}</span>
            <span className="text-xs text-zinc-500">cr</span>
          </div>
          <p className="text-[11px] text-zinc-400 mt-2 flex items-center gap-1 group-hover:text-indigo-400 transition-colors">
            <span>Buy or upgrade plan</span>
            <ArrowRight className="w-3 h-3" />
          </p>
        </div>

        {/* Card 2: Videos Created */}
        <div
          id="metric-videos"
          onClick={() => onNavigate('videos')}
          className="p-5 rounded-2xl bg-zinc-900/60 border border-zinc-800 hover:border-zinc-700 transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between text-zinc-400 mb-3">
            <span className="text-xs font-medium">Videos Created</span>
            <div className="w-8 h-8 rounded-xl bg-indigo-500/10 text-indigo-400 flex items-center justify-center">
              <Film className="w-4 h-4" />
            </div>
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-3xl font-black text-white font-mono">{videos.length}</span>
            <span className="text-xs text-zinc-500">total</span>
          </div>
          <p className="text-[11px] text-zinc-400 mt-2 flex items-center gap-1 group-hover:text-indigo-400 transition-colors">
            <span>View video library</span>
            <ArrowRight className="w-3 h-3" />
          </p>
        </div>

        {/* Card 3: Free Trial Remaining */}
        <div
          id="metric-freetrial"
          className="p-5 rounded-2xl bg-zinc-900/60 border border-zinc-800"
        >
          <div className="flex items-center justify-between text-zinc-400 mb-3">
            <span className="text-xs font-medium">Free Trial Remaining</span>
            <div className="w-8 h-8 rounded-xl bg-emerald-500/10 text-emerald-400 flex items-center justify-center">
              <Sparkles className="w-4 h-4" />
            </div>
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-3xl font-black text-white font-mono">{freeTrialRemaining}</span>
            <span className="text-xs text-zinc-500">{typeof freeTrialRemaining === 'number' ? 'videos' : ''}</span>
          </div>
          <p className="text-[11px] text-zinc-400 mt-2">
            {profile?.plan === 'free' ? 'Each generation uses 10 credits' : 'Subscribed to monthly quota'}
          </p>
        </div>

        {/* Card 4: Current Plan */}
        <div
          id="metric-plan"
          onClick={() => onNavigate('pricing')}
          className="p-5 rounded-2xl bg-zinc-900/60 border border-zinc-800 hover:border-zinc-700 transition-all cursor-pointer group"
        >
          <div className="flex items-center justify-between text-zinc-400 mb-3">
            <span className="text-xs font-medium">Current Plan</span>
            <div className="w-8 h-8 rounded-xl bg-violet-500/10 text-violet-400 flex items-center justify-center">
              <Zap className="w-4 h-4" />
            </div>
          </div>
          <div className="flex items-baseline gap-2">
            <span className="text-2xl font-black text-white capitalize">{profile?.plan || 'Free'}</span>
          </div>
          <p className="text-[11px] text-zinc-400 mt-2 flex items-center gap-1 group-hover:text-indigo-400 transition-colors">
            {profile?.plan === 'free' ? 'Upgrade for 1080p & No Watermark' : 'Manage Subscription'}
            <ArrowRight className="w-3 h-3" />
          </p>
        </div>
      </div>

      {/* Active Jobs in Progress */}
      {activeJobs.length > 0 && (
        <div className="bg-indigo-950/30 border border-indigo-500/30 rounded-2xl p-5">
          <div className="flex items-center gap-2 mb-3">
            <Loader2 className="w-4 h-4 text-indigo-400 animate-spin" />
            <h3 className="text-sm font-semibold text-white">
              Active Generation Jobs ({activeJobs.length})
            </h3>
          </div>
          <div className="space-y-3">
            {activeJobs.map((job) => (
              <div
                key={job.videoId}
                className="bg-zinc-900/80 border border-zinc-800 rounded-xl p-3 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs"
              >
                <div className="flex-1 truncate">
                  <div className="flex items-center gap-2 mb-1">
                    <span className="px-1.5 py-0.5 rounded bg-indigo-600/30 text-indigo-300 font-mono text-[10px]">
                      {job.aspectRatio}
                    </span>
                    <span className="font-semibold text-zinc-200 truncate">{job.prompt}</span>
                  </div>
                  <div className="flex items-center gap-2 text-zinc-500 text-[11px]">
                    <span>Style: {job.style}</span>
                    <span>•</span>
                    <span>Duration: {job.duration}s</span>
                  </div>
                </div>

                <div className="flex items-center gap-3 shrink-0">
                  <div className="w-32 bg-zinc-800 rounded-full h-2 overflow-hidden">
                    <div
                      className="bg-indigo-500 h-full rounded-full transition-all duration-300"
                      style={{ width: `${job.progress || 35}%` }}
                    />
                  </div>
                  <span className="text-zinc-400 font-mono text-[11px] w-12 text-right">
                    {job.progress || 35}%
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Quick Launchers */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div
          onClick={() => onNavigate('create')}
          className="p-5 rounded-2xl bg-zinc-900/40 border border-zinc-800 hover:border-indigo-500/50 hover:bg-zinc-900/70 transition-all cursor-pointer group"
        >
          <div className="w-10 h-10 rounded-xl bg-indigo-600/20 text-indigo-400 flex items-center justify-center mb-3">
            <Film className="w-5 h-5" />
          </div>
          <h3 className="text-sm font-semibold text-white group-hover:text-indigo-300 transition-colors">
            Text to Video
          </h3>
          <p className="text-xs text-zinc-400 mt-1">
            Generate cinematic footage from pure text prompts with customizable camera moves and lighting.
          </p>
        </div>

        <div
          onClick={() => onNavigate('image-to-video')}
          className="p-5 rounded-2xl bg-zinc-900/40 border border-zinc-800 hover:border-cyan-500/50 hover:bg-zinc-900/70 transition-all cursor-pointer group"
        >
          <div className="w-10 h-10 rounded-xl bg-cyan-600/20 text-cyan-400 flex items-center justify-center mb-3">
            <ImageIcon className="w-5 h-5" />
          </div>
          <h3 className="text-sm font-semibold text-white group-hover:text-cyan-300 transition-colors">
            Image to Video
          </h3>
          <p className="text-xs text-zinc-400 mt-1">
            Transform portraits, art, and landscapes into moving motion pictures with camera animations.
          </p>
        </div>

        <div
          onClick={() => onNavigate('script')}
          className="p-5 rounded-2xl bg-zinc-900/40 border border-zinc-800 hover:border-emerald-500/50 hover:bg-zinc-900/70 transition-all cursor-pointer group"
        >
          <div className="w-10 h-10 rounded-xl bg-emerald-600/20 text-emerald-400 flex items-center justify-center mb-3">
            <FileText className="w-5 h-5" />
          </div>
          <h3 className="text-sm font-semibold text-white group-hover:text-emerald-300 transition-colors">
            AI Script Generator
          </h3>
          <p className="text-xs text-zinc-400 mt-1">
            Generate hooks, scene descriptions, voiceovers, and endings with Gemini in one click.
          </p>
        </div>
      </div>

      {/* Recent Videos Section */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="text-lg font-bold text-white tracking-tight">Recent Videos</h2>
            <p className="text-xs text-zinc-400">Your latest renders and active projects</p>
          </div>
          {videos.length > 0 && (
            <button
              onClick={() => onNavigate('videos')}
              className="text-xs font-semibold text-indigo-400 hover:text-indigo-300 flex items-center gap-1"
            >
              View all ({videos.length}) <ArrowRight className="w-3.5 h-3.5" />
            </button>
          )}
        </div>

        {videos.length === 0 ? (
          <div className="p-12 text-center rounded-2xl bg-zinc-900/30 border border-zinc-800/80">
            <Film className="w-10 h-10 text-zinc-600 mx-auto mb-3" />
            <h3 className="text-sm font-semibold text-zinc-300">No videos created yet</h3>
            <p className="text-xs text-zinc-500 max-w-sm mx-auto mt-1 mb-4">
              Enter your first prompt or use an AI script to produce your first high-definition video.
            </p>
            <button
              onClick={() => onNavigate('create')}
              className="px-4 py-2 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-medium transition-colors"
            >
              Generate First Video
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
            {videos.slice(0, 3).map((video) => (
              <div
                key={video.videoId}
                className="bg-zinc-900/60 border border-zinc-800 rounded-xl overflow-hidden hover:border-zinc-700 transition-all group"
              >
                <div
                  onClick={() => video.status === 'completed' && onPlayVideo(video)}
                  className="relative aspect-video bg-zinc-950 flex items-center justify-center cursor-pointer overflow-hidden"
                >
                  {video.thumbnailUrl || video.videoUrl ? (
                    <img
                      src={video.thumbnailUrl || 'https://images.unsplash.com/photo-1519501025264-65ba15a82390?auto=format&fit=crop&w=800&q=80'}
                      alt={video.prompt}
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300"
                    />
                  ) : (
                    <div className="text-zinc-600 flex flex-col items-center gap-2">
                      <Film className="w-8 h-8" />
                    </div>
                  )}

                  {video.status === 'completed' && (
                    <div className="absolute inset-0 bg-black/30 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                      <div className="w-10 h-10 rounded-full bg-indigo-600 text-white flex items-center justify-center shadow-lg">
                        <Play className="w-4 h-4 fill-white ml-0.5" />
                      </div>
                    </div>
                  )}

                  {video.status === 'processing' && (
                    <div className="absolute inset-0 bg-black/60 flex flex-col items-center justify-center p-4">
                      <Loader2 className="w-6 h-6 text-indigo-400 animate-spin mb-2" />
                      <span className="text-[11px] text-indigo-200 font-medium">Processing ({video.progress || 25}%)</span>
                    </div>
                  )}

                  {video.status === 'failed' && (
                    <div className="absolute inset-0 bg-rose-950/80 flex flex-col items-center justify-center p-3 text-center">
                      <AlertCircle className="w-5 h-5 text-rose-400 mb-1" />
                      <span className="text-[11px] text-rose-200">Generation Failed</span>
                    </div>
                  )}

                  <div className="absolute top-2 left-2 flex items-center gap-1.5">
                    <span className="px-1.5 py-0.5 text-[9px] font-mono rounded bg-black/70 text-white border border-white/10">
                      {video.aspectRatio}
                    </span>
                    <span className="px-1.5 py-0.5 text-[9px] rounded bg-indigo-950/80 text-indigo-300 border border-indigo-500/30">
                      {video.style}
                    </span>
                  </div>

                  <div className="absolute bottom-2 right-2">
                    <span className="px-1.5 py-0.5 text-[9px] font-mono rounded bg-black/70 text-zinc-300">
                      {video.duration}s
                    </span>
                  </div>
                </div>

                <div className="p-3.5">
                  <p className="text-xs text-zinc-200 line-clamp-2 font-medium">
                    {video.prompt}
                  </p>
                  <div className="mt-2.5 pt-2.5 border-t border-zinc-800/80 flex items-center justify-between text-[11px] text-zinc-400">
                    <span className="capitalize">{video.status}</span>
                    <span className="text-zinc-500 font-mono">{video.creditsUsed} credits</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};
