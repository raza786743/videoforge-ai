import React, { useState } from 'react';
import { GeneratedScript, ScriptScene, VideoStyle, VideoDuration } from '../types';
import {
  Sparkles,
  FileText,
  Clock,
  ArrowRight,
  Loader2,
  AlertCircle,
  Copy,
  Check,
  Film,
  Edit3,
  Plus,
  Trash2,
} from 'lucide-react';

interface ScriptGeneratorViewProps {
  onUseInVideoCreator: (data: {
    prompt: string;
    style: VideoStyle;
    duration: VideoDuration;
    voiceoverText: string;
  }) => void;
}

export const ScriptGeneratorView: React.FC<ScriptGeneratorViewProps> = ({
  onUseInVideoCreator,
}) => {
  const [topic, setTopic] = useState('5 amazing facts about the cosmos that will blow your mind');
  const [style, setStyle] = useState<VideoStyle>('Documentary');
  const [targetDuration, setTargetDuration] = useState<VideoDuration>(15);

  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [script, setScript] = useState<GeneratedScript | null>(null);
  const [copied, setCopied] = useState(false);

  // Quick topics
  const sampleTopics = [
    '5 amazing facts about space',
    'How artificial intelligence actually works in simple terms',
    '3 secrets to superhuman productivity without burnout',
    'The mind-bending story of the deepest place on Earth',
  ];

  const handleGenerateScript = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(null);
    if (!topic.trim()) {
      setError('Please enter a topic or concept for the script.');
      return;
    }

    setIsLoading(true);
    try {
      const response = await fetch('/api/script/generate', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          topic: topic.trim(),
          style,
          targetDuration,
        }),
      });

      const data = await response.json();
      if (!response.ok) {
        throw new Error(data.error || 'Failed to generate script. Please verify GEMINI_API_KEY in Secrets.');
      }

      setScript(data.script);
    } catch (err: any) {
      console.error('Script generation error:', err);
      setError(err.message || 'Script generation failed.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleCopyScript = () => {
    if (!script) return;
    const fullText = `HOOK:\n${script.hook}\n\nSCENES:\n${script.scenes
      .map((s) => `Scene ${s.sceneNumber} (${s.durationSeconds}s): ${s.visualPrompt}\nVoiceover: ${s.voiceoverText}`)
      .join('\n\n')}\n\nENDING:\n${script.ending}`;

    navigator.clipboard.writeText(fullText);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleTransferToVideo = () => {
    if (!script) return;
    // Combine scene prompts into a coherent prompt or use the hook + scene 1
    const combinedVisualPrompt = `${script.scenes.map((s) => s.visualPrompt).join('. ')}`;
    const fullVoiceover = `${script.hook} ${script.voiceoverScript} ${script.ending}`;

    onUseInVideoCreator({
      prompt: combinedVisualPrompt.slice(0, 450),
      style: (script.suggestedStyle as VideoStyle) || style,
      duration: targetDuration,
      voiceoverText: fullVoiceover,
    });
  };

  const updateScene = (index: number, field: keyof ScriptScene, value: any) => {
    if (!script) return;
    const newScenes = [...script.scenes];
    newScenes[index] = { ...newScenes[index], [field]: value };
    setScript({ ...script, scenes: newScenes });
  };

  return (
    <div id="script-generator-page" className="p-4 sm:p-6 lg:p-8 max-w-5xl mx-auto space-y-6">
      <div>
        <div className="flex items-center gap-2 mb-1">
          <span className="text-xs uppercase font-mono tracking-wider text-emerald-400">Gemini 2.5 Intelligence</span>
          <span className="text-[10px] uppercase font-bold px-2 py-0.5 rounded bg-zinc-800 text-zinc-300 border border-zinc-700">
            AI Screenwriter
          </span>
        </div>
        <h1 className="text-2xl sm:text-3xl font-bold text-white tracking-tight">
          AI Script & Storyboard Generator
        </h1>
        <p className="text-xs sm:text-sm text-zinc-400 mt-1">
          Generate structured viral hooks, scene breakdowns, cinematic prompts, and full voice-over scripts.
        </p>
      </div>

      {error && (
        <div className="p-4 rounded-xl bg-rose-950/80 border border-rose-800 text-rose-200 text-xs flex items-start gap-3 animate-in fade-in">
          <AlertCircle className="w-5 h-5 text-rose-400 shrink-0 mt-0.5" />
          <div className="flex-1">
            <p className="font-semibold text-rose-100">Script Generation Error</p>
            <p className="mt-1 leading-relaxed">{error}</p>
          </div>
        </div>
      )}

      {/* Generator Prompt Box */}
      <form onSubmit={handleGenerateScript} className="p-6 rounded-2xl bg-zinc-900 border border-zinc-800 space-y-4 shadow-xl">
        <div className="space-y-2">
          <label className="text-xs font-semibold text-zinc-200 flex items-center gap-1.5">
            <FileText className="w-4 h-4 text-emerald-400" />
            Script Topic or Video Idea
          </label>
          <input
            id="script-topic-input"
            type="text"
            required
            value={topic}
            onChange={(e) => setTopic(e.target.value)}
            placeholder="e.g. 5 amazing facts about space, luxury perfume launch, or AI future in 2030"
            className="w-full bg-zinc-950 border border-zinc-800 rounded-xl px-4 py-3 text-sm text-white placeholder-zinc-500 focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500"
          />

          <div className="flex flex-wrap items-center gap-2 pt-1">
            <span className="text-[11px] text-zinc-500">Popular topics:</span>
            {sampleTopics.map((t, idx) => (
              <button
                key={idx}
                type="button"
                onClick={() => setTopic(t)}
                className="text-[11px] px-2.5 py-1 rounded-full bg-zinc-950 hover:bg-zinc-800 text-zinc-400 hover:text-zinc-200 border border-zinc-800 transition-colors"
              >
                {t}
              </button>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pt-2">
          <div>
            <label className="text-xs font-semibold text-zinc-200 block mb-1.5">Target Style</label>
            <select
              value={style}
              onChange={(e) => setStyle(e.target.value as VideoStyle)}
              className="w-full bg-zinc-950 border border-zinc-800 rounded-xl p-2.5 text-xs text-white focus:outline-none focus:border-emerald-500"
            >
              <option value="Documentary">Documentary</option>
              <option value="Cinematic">Cinematic</option>
              <option value="Realistic">Realistic Photoreal</option>
              <option value="Anime">Anime Animation</option>
              <option value="3D Animation">3D Unreal Engine</option>
              <option value="Product Advertisement">Product Advertisement</option>
            </select>
          </div>

          <div>
            <label className="text-xs font-semibold text-zinc-200 block mb-1.5">Target Duration</label>
            <div className="grid grid-cols-3 gap-2">
              {([10, 15, 30] as VideoDuration[]).map((d) => (
                <button
                  key={d}
                  type="button"
                  onClick={() => setTargetDuration(d)}
                  className={`py-2 rounded-xl border text-xs font-semibold transition-all ${
                    targetDuration === d
                      ? 'bg-emerald-600/20 border-emerald-500 text-white'
                      : 'bg-zinc-950 border-zinc-800 text-zinc-400 hover:border-zinc-700'
                  }`}
                >
                  {d} seconds
                </button>
              ))}
            </div>
          </div>
        </div>

        <div className="pt-2 flex justify-end">
          <button
            id="generate-script-btn"
            type="submit"
            disabled={isLoading || !topic.trim()}
            className="w-full sm:w-auto px-6 py-2.5 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white rounded-xl text-xs font-bold transition-all shadow-md shadow-emerald-600/30 flex items-center justify-center gap-2 cursor-pointer"
          >
            {isLoading ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                <span>Gemini is drafting storyboard...</span>
              </>
            ) : (
              <>
                <Sparkles className="w-4 h-4" />
                <span>Generate Script with AI</span>
              </>
            )}
          </button>
        </div>
      </form>

      {/* Generated Script Results & Editor */}
      {script && (
        <div id="generated-script-card" className="p-6 rounded-2xl bg-zinc-900 border border-zinc-800 space-y-6 shadow-2xl animate-in fade-in">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-zinc-800/80 pb-4">
            <div>
              <span className="text-[10px] uppercase font-mono tracking-wider text-emerald-400 font-bold">
                Script Ready
              </span>
              <h3 className="text-lg font-bold text-white tracking-tight">{script.topic}</h3>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={handleCopyScript}
                className="px-3 py-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-zinc-200 text-xs font-medium flex items-center gap-1.5 transition-colors"
              >
                {copied ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copied ? 'Copied' : 'Copy All'}</span>
              </button>

              <button
                id="transfer-to-video-btn"
                onClick={handleTransferToVideo}
                className="px-4 py-1.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-xs font-semibold flex items-center gap-1.5 shadow-md shadow-indigo-600/30 transition-all cursor-pointer"
              >
                <Film className="w-3.5 h-3.5" />
                <span>Create Video From Script</span>
              </button>
            </div>
          </div>

          {/* Hook */}
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-amber-400 flex items-center gap-1.5">
              <Sparkles className="w-3.5 h-3.5" />
              Opening Hook (First 3 Seconds)
            </label>
            <input
              type="text"
              value={script.hook}
              onChange={(e) => setScript({ ...script, hook: e.target.value })}
              className="w-full bg-zinc-950 border border-zinc-800 rounded-xl p-3 text-xs text-white focus:outline-none focus:border-amber-500 font-medium"
            />
          </div>

          {/* Scenes Breakdown */}
          <div className="space-y-3">
            <label className="text-xs font-semibold text-zinc-300">
              Scenes & Visual Generation Prompts
            </label>
            <div className="space-y-3">
              {script.scenes.map((scene, idx) => (
                <div
                  key={idx}
                  className="p-4 rounded-xl bg-zinc-950/80 border border-zinc-800/80 space-y-2.5"
                >
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-bold text-white font-mono">
                      Scene {scene.sceneNumber}: {scene.title}
                    </span>
                    <span className="text-[11px] text-zinc-500 font-mono">
                      {scene.durationSeconds}s
                    </span>
                  </div>

                  <div>
                    <label className="text-[11px] text-zinc-500 block mb-1">Visual Prompt</label>
                    <textarea
                      rows={2}
                      value={scene.visualPrompt}
                      onChange={(e) => updateScene(idx, 'visualPrompt', e.target.value)}
                      className="w-full bg-zinc-900 border border-zinc-800 rounded-lg p-2.5 text-xs text-zinc-200 focus:outline-none focus:border-emerald-500"
                    />
                  </div>

                  <div>
                    <label className="text-[11px] text-zinc-500 block mb-1">Voice-Over Line</label>
                    <input
                      type="text"
                      value={scene.voiceoverText}
                      onChange={(e) => updateScene(idx, 'voiceoverText', e.target.value)}
                      className="w-full bg-zinc-900 border border-zinc-800 rounded-lg p-2 text-xs text-zinc-300 focus:outline-none focus:border-emerald-500"
                    />
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Ending */}
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-indigo-400">
              Ending & Call To Action
            </label>
            <input
              type="text"
              value={script.ending}
              onChange={(e) => setScript({ ...script, ending: e.target.value })}
              className="w-full bg-zinc-950 border border-zinc-800 rounded-xl p-3 text-xs text-white focus:outline-none focus:border-indigo-500 font-medium"
            />
          </div>

          {/* Full Voiceover Narrative */}
          <div className="space-y-1.5">
            <label className="text-xs font-semibold text-zinc-400">
              Complete Voiceover Narrative Script
            </label>
            <textarea
              rows={3}
              value={script.voiceoverScript}
              onChange={(e) => setScript({ ...script, voiceoverScript: e.target.value })}
              className="w-full bg-zinc-950 border border-zinc-800 rounded-xl p-3 text-xs text-zinc-300 focus:outline-none focus:border-zinc-700"
            />
          </div>
        </div>
      )}
    </div>
  );
};
