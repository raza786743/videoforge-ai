import React, { useState } from 'react';
import { VideoRecord, JobStatus, AppView } from '../types';
import { deleteVideo } from '../lib/firebase';
import {
  Film,
  Play,
  Download,
  Trash2,
  RotateCcw,
  Clock,
  AlertCircle,
  Loader2,
  Search,
  Filter,
  Plus,
} from 'lucide-react';

interface MyVideosViewProps {
  videos: VideoRecord[];
  onPlayVideo: (video: VideoRecord) => void;
  onRegenerateVideo: (video: VideoRecord) => void;
  onNavigate: (view: AppView) => void;
  onVideoDeleted: (videoId: string) => void;
}

export const MyVideosView: React.FC<MyVideosViewProps> = ({
  videos,
  onPlayVideo,
  onRegenerateVideo,
  onNavigate,
  onVideoDeleted,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | JobStatus>('all');
  const [deletingId, setDeletingId] = useState<string | null>(null);

  const filteredVideos = videos.filter((video) => {
    const matchesSearch =
      video.prompt.toLowerCase().includes(searchQuery.toLowerCase()) ||
      video.style.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesStatus = statusFilter === 'all' ? true : video.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const handleDelete = async (e: React.MouseEvent, videoId: string) => {
    e.stopPropagation();
    if (!confirm('Are you sure you want to delete this video?')) return;

    setDeletingId(videoId);
    try {
      await deleteVideo(videoId);
      onVideoDeleted(videoId);
    } catch (err) {
      console.error('Delete error:', err);
    } finally {
      setDeletingId(null);
    }
  };

  const handleDownload = (e: React.MouseEvent, video: VideoRecord) => {
    e.stopPropagation();
    if (!video.videoUrl) return;
    const downloadUrl = `/api/video/download?url=${encodeURIComponent(video.videoUrl)}`;
    const a = document.createElement('a');
    a.href = downloadUrl;
    a.download = `videoforge_${video.videoId.slice(0, 8)}.mp4`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
  };

  return (
    <div id="my-videos-page" className="p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-xs uppercase font-mono tracking-wider text-indigo-400">Archive</span>
            <span className="text-[10px] uppercase font-bold px-2 py-0.5 rounded bg-zinc-800 text-zinc-300 border border-zinc-700">
              {videos.length} Videos
            </span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-bold text-white tracking-tight">
            My Video Library
          </h1>
          <p className="text-xs sm:text-sm text-zinc-400 mt-1">
            Browse, play, download, and manage your AI video creations.
          </p>
        </div>

        <button
          onClick={() => onNavigate('create')}
          className="px-4 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-semibold flex items-center gap-2 shadow-lg shadow-indigo-600/30 transition-all self-start sm:self-auto cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>New Video</span>
        </button>
      </div>

      {/* Search & Filter Toolbar */}
      <div className="flex flex-col sm:flex-row items-center gap-3">
        <div className="relative flex-1 w-full">
          <Search className="w-4 h-4 text-zinc-500 absolute left-3.5 top-3" />
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search by prompt keywords or style..."
            className="w-full bg-zinc-900 border border-zinc-800 rounded-xl pl-10 pr-4 py-2.5 text-xs text-white placeholder-zinc-500 focus:outline-none focus:border-indigo-500"
          />
        </div>

        <div className="flex items-center gap-1.5 self-start sm:self-auto overflow-x-auto w-full sm:w-auto pb-1 sm:pb-0">
          {(['all', 'completed', 'processing', 'failed'] as const).map((filter) => (
            <button
              key={filter}
              onClick={() => setStatusFilter(filter)}
              className={`px-3 py-2 rounded-xl text-xs font-medium capitalize whitespace-nowrap transition-colors ${
                statusFilter === filter
                  ? 'bg-indigo-600 text-white font-semibold'
                  : 'bg-zinc-900 text-zinc-400 hover:text-white border border-zinc-800'
              }`}
            >
              {filter}
            </button>
          ))}
        </div>
      </div>

      {/* Videos Grid */}
      {filteredVideos.length === 0 ? (
        <div className="p-16 text-center rounded-2xl bg-zinc-900/30 border border-zinc-800">
          <Film className="w-12 h-12 text-zinc-600 mx-auto mb-3" />
          <h3 className="text-base font-semibold text-zinc-300">No videos found</h3>
          <p className="text-xs text-zinc-500 max-w-sm mx-auto mt-1 mb-5">
            {videos.length === 0
              ? 'You have not created any videos yet. Start by generating your first cinematic scene.'
              : 'No videos matched your filter criteria.'}
          </p>
          {videos.length === 0 && (
            <button
              onClick={() => onNavigate('create')}
              className="px-5 py-2.5 bg-indigo-600 hover:bg-indigo-500 text-white rounded-xl text-xs font-semibold transition-colors"
            >
              Create First Video
            </button>
          )}
        </div>
      ) : (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredVideos.map((video) => (
            <div
              key={video.videoId}
              id={`video-card-${video.videoId}`}
              onClick={() => video.status === 'completed' && onPlayVideo(video)}
              className="group bg-zinc-900/70 border border-zinc-800 rounded-2xl overflow-hidden hover:border-zinc-700 transition-all flex flex-col justify-between shadow-lg hover:shadow-indigo-950/20"
            >
              {/* Thumbnail Container */}
              <div className="relative aspect-video bg-zinc-950 flex items-center justify-center overflow-hidden cursor-pointer">
                {video.thumbnailUrl || video.videoUrl ? (
                  <img
                    src={video.thumbnailUrl || 'https://images.unsplash.com/photo-1519501025264-65ba15a82390?auto=format&fit=crop&w=800&q=80'}
                    alt={video.prompt}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                ) : (
                  <div className="text-zinc-700">
                    <Film className="w-10 h-10" />
                  </div>
                )}

                {/* State overlays */}
                {video.status === 'completed' && (
                  <div className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity backdrop-blur-xs">
                    <div className="w-12 h-12 rounded-full bg-indigo-600 text-white flex items-center justify-center shadow-lg">
                      <Play className="w-5 h-5 fill-white ml-0.5" />
                    </div>
                  </div>
                )}

                {(video.status === 'processing' || video.status === 'queued') && (
                  <div className="absolute inset-0 bg-black/75 flex flex-col items-center justify-center p-4">
                    <Loader2 className="w-6 h-6 text-indigo-400 animate-spin mb-2" />
                    <span className="text-xs text-indigo-200 font-semibold">
                      {video.status === 'queued' ? 'Queued...' : `Processing (${video.progress || 35}%)`}
                    </span>
                  </div>
                )}

                {video.status === 'failed' && (
                  <div className="absolute inset-0 bg-rose-950/80 flex flex-col items-center justify-center p-3 text-center">
                    <AlertCircle className="w-6 h-6 text-rose-400 mb-1" />
                    <span className="text-xs text-rose-200 font-semibold">Generation Failed</span>
                    <p className="text-[10px] text-rose-300 mt-1 max-w-[200px] truncate">{video.error}</p>
                  </div>
                )}

                <div className="absolute top-2.5 left-2.5 flex items-center gap-1.5">
                  <span className="px-2 py-0.5 text-[10px] font-mono rounded bg-black/70 text-white border border-white/10 backdrop-blur-xs font-semibold">
                    {video.aspectRatio}
                  </span>
                  <span className="px-2 py-0.5 text-[10px] rounded bg-indigo-950/80 text-indigo-300 border border-indigo-500/30">
                    {video.style}
                  </span>
                </div>

                <div className="absolute bottom-2.5 right-2.5">
                  <span className="px-2 py-0.5 text-[10px] font-mono rounded bg-black/70 text-zinc-300 backdrop-blur-xs">
                    {video.duration}s
                  </span>
                </div>
              </div>

              {/* Details & Actions Footer */}
              <div className="p-4 flex-1 flex flex-col justify-between">
                <div>
                  <p className="text-xs font-medium text-zinc-200 line-clamp-2 leading-relaxed">
                    "{video.prompt}"
                  </p>
                  <div className="mt-2 flex items-center gap-3 text-[11px] text-zinc-500">
                    <span className="flex items-center gap-1">
                      <Clock className="w-3 h-3" />
                      {new Date(video.createdAt).toLocaleDateString()}
                    </span>
                    <span>•</span>
                    <span className="font-mono">{video.creditsUsed} credits</span>
                  </div>
                </div>

                <div className="mt-4 pt-3 border-t border-zinc-800 flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    {video.status === 'completed' && video.videoUrl && (
                      <button
                        onClick={(e) => handleDownload(e, video)}
                        className="p-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-zinc-300 hover:text-white transition-colors"
                        title="Download MP4"
                      >
                        <Download className="w-3.5 h-3.5" />
                      </button>
                    )}

                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        onRegenerateVideo(video);
                      }}
                      className="p-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-zinc-300 hover:text-white transition-colors"
                      title="Regenerate with these parameters"
                    >
                      <RotateCcw className="w-3.5 h-3.5" />
                    </button>
                  </div>

                  <button
                    onClick={(e) => handleDelete(e, video.videoId)}
                    disabled={deletingId === video.videoId}
                    className="p-1.5 rounded-lg text-zinc-500 hover:text-rose-400 hover:bg-rose-950/40 transition-colors"
                    title="Delete Video"
                  >
                    {deletingId === video.videoId ? (
                      <Loader2 className="w-3.5 h-3.5 animate-spin" />
                    ) : (
                      <Trash2 className="w-3.5 h-3.5" />
                    )}
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
