import React, { useState, useEffect } from 'react';
import { useAuth } from '../context/AuthContext';
import { UserProfile, VideoRecord, PlanType } from '../types';
import {
  getAllUsersAdmin,
  getAllVideosAdmin,
  updateUserCreditsAdmin,
  updateUserPlanAdmin,
} from '../lib/firebase';
import {
  ShieldAlert,
  Users,
  Film,
  Coins,
  Activity,
  Search,
  Plus,
  Edit2,
  Check,
  RotateCcw,
  Play,
  Trash2,
  Loader2,
  AlertCircle,
} from 'lucide-react';

interface AdminViewProps {
  onPlayVideo: (video: VideoRecord) => void;
}

export const AdminView: React.FC<AdminViewProps> = ({ onPlayVideo }) => {
  const { user, profile, isAdmin } = useAuth();
  const [usersList, setUsersList] = useState<UserProfile[]>([]);
  const [videosList, setVideosList] = useState<VideoRecord[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<'overview' | 'users' | 'videos'>('overview');

  // Credit adjustment states
  const [selectedUserId, setSelectedUserId] = useState<string | null>(null);
  const [creditAdjustment, setCreditAdjustment] = useState<number>(50);
  const [isUpdating, setIsUpdating] = useState(false);
  const [statusMessage, setStatusMessage] = useState<string | null>(null);

  useEffect(() => {
    loadAdminData();
  }, []);

  const loadAdminData = async () => {
    setIsLoading(true);
    try {
      const [users, videos] = await Promise.all([
        getAllUsersAdmin(),
        getAllVideosAdmin(),
      ]);
      setUsersList(users);
      setVideosList(videos);
    } catch (err) {
      console.error('Failed to load admin data:', err);
    } finally {
      setIsLoading(false);
    }
  };

  const handleAddCredits = async (userId: string) => {
    setIsUpdating(true);
    try {
      await updateUserCreditsAdmin(userId, creditAdjustment);
      setStatusMessage(`Added ${creditAdjustment} credits to user.`);
      await loadAdminData();
      setTimeout(() => setStatusMessage(null), 3000);
    } catch (err: any) {
      console.error(err);
      setStatusMessage('Error updating credits.');
    } finally {
      setIsUpdating(false);
    }
  };

  const handleChangePlan = async (userId: string, newPlan: PlanType) => {
    setIsUpdating(true);
    try {
      await updateUserPlanAdmin(userId, newPlan);
      setStatusMessage(`Updated user plan to ${newPlan}.`);
      await loadAdminData();
      setTimeout(() => setStatusMessage(null), 3000);
    } catch (err: any) {
      console.error(err);
      setStatusMessage('Error updating plan.');
    } finally {
      setIsUpdating(false);
    }
  };

  // Compute stats
  const totalCreditsUsed = videosList.reduce((sum, v) => sum + (v.creditsUsed || 0), 0);
  const activeJobsCount = videosList.filter(
    (v) => v.status === 'queued' || v.status === 'processing'
  ).length;

  if (!isAdmin && user) {
    return (
      <div className="p-12 text-center max-w-lg mx-auto space-y-4">
        <ShieldAlert className="w-12 h-12 text-rose-500 mx-auto" />
        <h2 className="text-xl font-bold text-white">Admin Authorization Required</h2>
        <p className="text-xs text-zinc-400">
          Your current account (<code className="text-zinc-200">{user.email}</code>) does not have administrator privileges.
          To access the admin dashboard, set <code className="text-zinc-200">role: "admin"</code> in your Firestore user record or sign in with an admin credential.
        </p>
      </div>
    );
  }

  return (
    <div id="admin-dashboard-page" className="p-4 sm:p-6 lg:p-8 max-w-7xl mx-auto space-y-8">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 mb-1">
            <span className="text-xs uppercase font-mono tracking-wider text-rose-400">Restricted Area</span>
            <span className="text-[10px] uppercase font-bold px-2 py-0.5 rounded bg-rose-950/80 text-rose-300 border border-rose-800">
              Admin Console
            </span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-bold text-white tracking-tight">
            System Administration
          </h1>
          <p className="text-xs sm:text-sm text-zinc-400 mt-1">
            Real-time telemetry, user management, plan overrides, and cluster job queues.
          </p>
        </div>

        <button
          onClick={loadAdminData}
          disabled={isLoading}
          className="px-3.5 py-2 bg-zinc-800 hover:bg-zinc-700 text-zinc-200 rounded-xl text-xs font-medium flex items-center gap-2 transition-colors self-start sm:self-auto"
        >
          <RotateCcw className={`w-3.5 h-3.5 ${isLoading ? 'animate-spin' : ''}`} />
          <span>Refresh Data</span>
        </button>
      </div>

      {statusMessage && (
        <div className="p-3 rounded-xl bg-indigo-950/80 border border-indigo-700 text-indigo-200 text-xs flex items-center gap-2 animate-in fade-in">
          <Check className="w-4 h-4 text-emerald-400" />
          <span>{statusMessage}</span>
        </div>
      )}

      {/* 4 System Metric Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="p-5 rounded-2xl bg-zinc-900/60 border border-zinc-800">
          <div className="flex items-center justify-between text-zinc-400 mb-3">
            <span className="text-xs font-medium">Total Registered Users</span>
            <div className="w-8 h-8 rounded-xl bg-blue-500/10 text-blue-400 flex items-center justify-center">
              <Users className="w-4 h-4" />
            </div>
          </div>
          <div className="text-3xl font-black text-white font-mono">{usersList.length}</div>
          <p className="text-[11px] text-zinc-500 mt-2">Active accounts in Firestore</p>
        </div>

        <div className="p-5 rounded-2xl bg-zinc-900/60 border border-zinc-800">
          <div className="flex items-center justify-between text-zinc-400 mb-3">
            <span className="text-xs font-medium">Total Videos Generated</span>
            <div className="w-8 h-8 rounded-xl bg-indigo-500/10 text-indigo-400 flex items-center justify-center">
              <Film className="w-4 h-4" />
            </div>
          </div>
          <div className="text-3xl font-black text-white font-mono">{videosList.length}</div>
          <p className="text-[11px] text-zinc-500 mt-2">Historical renders logged</p>
        </div>

        <div className="p-5 rounded-2xl bg-zinc-900/60 border border-zinc-800">
          <div className="flex items-center justify-between text-zinc-400 mb-3">
            <span className="text-xs font-medium">Credits Consumed</span>
            <div className="w-8 h-8 rounded-xl bg-amber-500/10 text-amber-400 flex items-center justify-center">
              <Coins className="w-4 h-4" />
            </div>
          </div>
          <div className="text-3xl font-black text-white font-mono">{totalCreditsUsed}</div>
          <p className="text-[11px] text-zinc-500 mt-2">Across all user generation jobs</p>
        </div>

        <div className="p-5 rounded-2xl bg-zinc-900/60 border border-zinc-800">
          <div className="flex items-center justify-between text-zinc-400 mb-3">
            <span className="text-xs font-medium">Active Pipeline Jobs</span>
            <div className="w-8 h-8 rounded-xl bg-emerald-500/10 text-emerald-400 flex items-center justify-center">
              <Activity className="w-4 h-4" />
            </div>
          </div>
          <div className="text-3xl font-black text-emerald-400 font-mono">{activeJobsCount}</div>
          <p className="text-[11px] text-zinc-500 mt-2">Currently queued or processing</p>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-2 border-b border-zinc-800 pb-2">
        <button
          onClick={() => setActiveTab('overview')}
          className={`px-4 py-2 rounded-xl text-xs font-semibold transition-colors ${
            activeTab === 'overview'
              ? 'bg-indigo-600 text-white'
              : 'text-zinc-400 hover:text-zinc-200'
          }`}
        >
          All Users & Credits ({usersList.length})
        </button>
        <button
          onClick={() => setActiveTab('videos')}
          className={`px-4 py-2 rounded-xl text-xs font-semibold transition-colors ${
            activeTab === 'videos'
              ? 'bg-indigo-600 text-white'
              : 'text-zinc-400 hover:text-zinc-200'
          }`}
        >
          All Videos Queue ({videosList.length})
        </button>
      </div>

      {/* User Management Table */}
      {activeTab === 'overview' && (
        <div className="bg-zinc-900 border border-zinc-800 rounded-2xl overflow-hidden shadow-xl">
          <div className="p-4 border-b border-zinc-800 flex items-center justify-between">
            <h3 className="text-sm font-bold text-white">Users Directory & Credit Allocator</h3>
            <span className="text-xs text-zinc-500">Instant updates stored in Firestore</span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-zinc-300">
              <thead className="bg-zinc-950/60 text-zinc-500 font-mono uppercase text-[10px] border-b border-zinc-800">
                <tr>
                  <th className="p-3.5">User</th>
                  <th className="p-3.5">Plan</th>
                  <th className="p-3.5">Credits</th>
                  <th className="p-3.5">Role</th>
                  <th className="p-3.5">Manage Credits</th>
                  <th className="p-3.5">Change Plan</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-zinc-800/80">
                {usersList.map((usr) => (
                  <tr key={usr.uid} className="hover:bg-zinc-850/40 transition-colors">
                    <td className="p-3.5">
                      <div className="font-semibold text-white">{usr.name || 'Anonymous User'}</div>
                      <div className="text-[11px] text-zinc-500 font-mono truncate max-w-xs">
                        {usr.email}
                      </div>
                    </td>

                    <td className="p-3.5">
                      <span className="px-2 py-0.5 rounded text-[10px] font-bold uppercase bg-zinc-800 text-zinc-200 border border-zinc-700">
                        {usr.plan}
                      </span>
                    </td>

                    <td className="p-3.5 font-mono font-bold text-amber-400">
                      {usr.credits} cr
                    </td>

                    <td className="p-3.5">
                      <span
                        className={`px-2 py-0.5 rounded text-[10px] font-bold uppercase ${
                          usr.role === 'admin'
                            ? 'bg-rose-950/60 text-rose-400 border border-rose-800'
                            : 'bg-zinc-800 text-zinc-400'
                        }`}
                      >
                        {usr.role || 'user'}
                      </span>
                    </td>

                    <td className="p-3.5">
                      <div className="flex items-center gap-1.5">
                        <button
                          onClick={() => handleAddCredits(usr.uid)}
                          disabled={isUpdating}
                          className="px-2.5 py-1 bg-amber-500/20 hover:bg-amber-500/30 text-amber-300 border border-amber-500/30 rounded-lg text-[11px] font-semibold transition-colors flex items-center gap-1"
                        >
                          <Plus className="w-3 h-3" />
                          <span>+50 Credits</span>
                        </button>
                      </div>
                    </td>

                    <td className="p-3.5">
                      <select
                        value={usr.plan}
                        onChange={(e) => handleChangePlan(usr.uid, e.target.value as PlanType)}
                        className="bg-zinc-950 border border-zinc-700 rounded-lg px-2 py-1 text-xs text-white focus:outline-none focus:border-indigo-500"
                      >
                        <option value="free">Free</option>
                        <option value="starter">Starter</option>
                        <option value="pro">Pro</option>
                        <option value="business">Business</option>
                      </select>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Video Log Table */}
      {activeTab === 'videos' && (
        <div className="bg-zinc-900 border border-zinc-800 rounded-2xl overflow-hidden shadow-xl">
          <div className="p-4 border-b border-zinc-800 flex items-center justify-between">
            <h3 className="text-sm font-bold text-white">Global Video Generation Pipeline</h3>
            <span className="text-xs text-zinc-500">Live job tracker</span>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-zinc-300">
              <thead className="bg-zinc-950/60 text-zinc-500 font-mono uppercase text-[10px] border-b border-zinc-800">
                <tr>
                  <th className="p-3.5">Video / Prompt</th>
                  <th className="p-3.5">Format</th>
                  <th className="p-3.5">Style</th>
                  <th className="p-3.5">Status</th>
                  <th className="p-3.5">Credits</th>
                  <th className="p-3.5">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-zinc-800/80">
                {videosList.map((vid) => (
                  <tr key={vid.videoId} className="hover:bg-zinc-850/40 transition-colors">
                    <td className="p-3.5 max-w-sm">
                      <div className="font-semibold text-white line-clamp-1">{vid.prompt}</div>
                      <div className="text-[10px] text-zinc-500 font-mono mt-0.5">
                        {vid.userEmail || vid.userId}
                      </div>
                    </td>

                    <td className="p-3.5 font-mono">
                      {vid.duration}s • {vid.aspectRatio}
                    </td>

                    <td className="p-3.5">{vid.style}</td>

                    <td className="p-3.5">
                      <span
                        className={`px-2 py-0.5 rounded text-[10px] font-bold capitalize ${
                          vid.status === 'completed'
                            ? 'bg-emerald-950/60 text-emerald-400 border border-emerald-800'
                            : vid.status === 'processing'
                            ? 'bg-indigo-950/60 text-indigo-400 border border-indigo-800'
                            : vid.status === 'queued'
                            ? 'bg-amber-950/60 text-amber-400 border border-amber-800'
                            : 'bg-rose-950/60 text-rose-400 border border-rose-800'
                        }`}
                      >
                        {vid.status}
                      </span>
                    </td>

                    <td className="p-3.5 font-mono">{vid.creditsUsed} cr</td>

                    <td className="p-3.5">
                      {vid.status === 'completed' && vid.videoUrl && (
                        <button
                          onClick={() => onPlayVideo(vid)}
                          className="px-2.5 py-1 bg-indigo-600 hover:bg-indigo-500 text-white rounded-lg text-xs font-semibold flex items-center gap-1 transition-colors"
                        >
                          <Play className="w-3 h-3 fill-white" />
                          <span>Play</span>
                        </button>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};
