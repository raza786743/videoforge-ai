export type PlanType = 'free' | 'starter' | 'pro' | 'business';

export interface UserProfile {
  uid: string;
  name: string;
  email: string;
  photo?: string;
  plan: PlanType;
  credits: number;
  free_trial_used: boolean;
  createdAt: number;
  updatedAt?: number;
  isAdmin?: boolean;
  disabled?: boolean;
}

export type AspectRatio = '9:16' | '16:9' | '1:1';
export type VideoDuration = 5 | 10 | 15 | 30;
export type VideoStyle =
  | 'Cinematic'
  | 'Realistic'
  | 'Anime'
  | '3D Animation'
  | 'Documentary'
  | 'Cartoon'
  | 'Product Advertisement';

export type JobStatus = 'queued' | 'processing' | 'completed' | 'failed';

export interface CaptionCue {
  id: string;
  start: number;
  end: number;
  text: string;
}

export interface VideoRecord {
  videoId: string;
  userId: string;
  userEmail?: string;
  prompt: string;
  duration: VideoDuration;
  aspectRatio: AspectRatio;
  style: VideoStyle;
  status: JobStatus;
  progress?: number;
  videoUrl?: string;
  thumbnailUrl?: string;
  imageUrl?: string;
  creditsUsed: number;
  error?: string;
  createdAt: number;
  captions?: CaptionCue[];
  voiceover?: {
    voice: string;
    language: string;
    text: string;
  };
  backgroundMusic?: string;
}

export interface ScriptScene {
  sceneNumber: number;
  title: string;
  visualPrompt: string;
  durationSeconds: number;
  voiceoverText: string;
}

export interface GeneratedScript {
  topic: string;
  hook: string;
  scenes: ScriptScene[];
  voiceoverScript: string;
  ending: string;
  suggestedStyle: string;
}

export interface PricingPlan {
  id: PlanType;
  name: string;
  priceMonthly: number;
  credits: number;
  resolution: string;
  watermark: boolean;
  features: string[];
  recommended?: boolean;
  badge?: string;
}

export type AppView =
  | 'landing'
  | 'dashboard'
  | 'create'
  | 'image-to-video'
  | 'script'
  | 'videos'
  | 'templates'
  | 'pricing'
  | 'admin'
  | 'settings';

export interface CaptionDisplayOptions {
  enabled: boolean;
  fontSize: 'small' | 'medium' | 'large';
  position: 'top' | 'center' | 'bottom';
  style: 'cinematic' | 'reels' | 'minimal' | 'banner';
}
